// src/shared/constants.ts
var CANVAS_PAGE_JSON_MAX_BYTES = 5 * 1024 * 1024;
var MAX_ARCHIVED_PAGE_BYTES = CANVAS_PAGE_JSON_MAX_BYTES * 8 + 64 * 1024;
var CLASSIC_ZIP_ENTRY_LIMIT = 65535;
var COURSE_CORE_ENTRY_COUNT = 7;
var COMBINED_CORE_ENTRY_COUNT = 4;
var MAX_ARCHIVE_RESOURCES = CLASSIC_ZIP_ENTRY_LIMIT - COURSE_CORE_ENTRY_COUNT;
var EXTENSION_CHANNEL = "gradpack/extension/v1";
var RUNNER_CHANNEL = "gradpack/runner/v1";

// src/shared/messages.ts
var RUNNER_TERMINAL_MESSAGES = Object.freeze({
  active: "Another GradPack operation is already active in this tab.",
  cancelled: "Packing was cancelled.",
  complete: "Your GradPack archives were downloaded.",
  noArchives: "No course archives were downloaded.",
  connection: "Open a signed-in Frankfurt School Canvas tab and try again.",
  navigation: "The Canvas tab navigated or closed. Reopen it and try again.",
  response: "Canvas returned an unavailable or invalid response.",
  safety: "GradPack stopped because a safety check failed.",
  session: "Your Canvas session ended. Sign in and try again.",
  size: "This course does not fit the 250 MB safety policy.",
  tab: "The connected Canvas tab is no longer available. Reopen it and try again.",
  unexpected: "GradPack stopped because of an unexpected local error.",
  unlisted: "The selected course is no longer available."
});
var record = (value) => {
  if (typeof value !== "object" || value === null || Array.isArray(value) || Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null) {
    throw new TypeError("Expected an object message");
  }
  for (const key of Reflect.ownKeys(value)) {
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (!descriptor || !("value" in descriptor)) {
      throw new TypeError("Unexpected message fields");
    }
  }
  return value;
};
var exactKeys = (value, allowed) => {
  const keys = Reflect.ownKeys(value);
  if (keys.length !== allowed.length || keys.some((key) => typeof key !== "string" || !allowed.includes(key))) {
    throw new TypeError("Unexpected message fields");
  }
};
var runId = (value) => {
  if (typeof value !== "string" || !/^run-[a-z0-9-]{8,64}$/.test(value)) {
    throw new TypeError("Invalid run identifier");
  }
  return value;
};
var nonNegativeInteger = (value) => {
  if (!Number.isSafeInteger(value) || Number(value) < 0) {
    throw new TypeError("Invalid count");
  }
  return Number(value);
};
var positiveInteger = (value, message) => {
  const result = nonNegativeInteger(value);
  if (result <= 0) throw new TypeError(message);
  return result;
};
var courseSummary = (value) => {
  const input = record(value);
  exactKeys(input, ["id", "name", "courseCode", "workflowState", "concluded"]);
  const id = positiveInteger(input.id, "Invalid course ID");
  if (typeof input.name !== "string" || typeof input.courseCode !== "string" || typeof input.workflowState !== "string" || typeof input.concluded !== "boolean") {
    throw new TypeError("Invalid course summary");
  }
  return {
    id,
    name: input.name.slice(0, 500),
    courseCode: input.courseCode.slice(0, 200),
    workflowState: input.workflowState.slice(0, 100),
    concluded: input.concluded
  };
};
var denseArray = (value, max) => {
  if (!Array.isArray(value) || Object.getPrototypeOf(value) !== Array.prototype) {
    throw new TypeError("Invalid array");
  }
  const length = Object.getOwnPropertyDescriptor(value, "length")?.value;
  if (length === void 0 || !Number.isSafeInteger(length) || length < 0 || length > max) {
    throw new TypeError("Invalid array");
  }
  const keys = Reflect.ownKeys(value);
  if (keys.some(
    (key) => typeof key !== "string" || key !== "length" && !/^(?:0|[1-9]\d*)$/u.test(key)
  )) {
    throw new TypeError("Invalid array");
  }
  const result = [];
  for (let index = 0; index < length; index += 1) {
    const descriptor = Object.getOwnPropertyDescriptor(value, String(index));
    if (!descriptor || !("value" in descriptor))
      throw new TypeError("Invalid array");
    result.push(descriptor.value);
  }
  return result;
};
var courseArray = (value) => denseArray(value, 1e4).map(courseSummary);
var courseIds = (value) => {
  const values = denseArray(value, 1e4);
  if (values.length === 0)
    throw new TypeError("At least one course is required");
  const ids = values.map(
    (candidate) => positiveInteger(candidate, "Invalid course ID")
  );
  if (new Set(ids).size !== ids.length)
    throw new TypeError("Duplicate course ID");
  return ids;
};
var packaging = (value) => {
  if (value !== "combined" && value !== "per-course") {
    throw new TypeError("Invalid packaging mode");
  }
  return value;
};
var fallbackReason = (value) => {
  if (value !== null && value !== "combined-size-exceeded" && value !== "combined-resource-limit-exceeded" && value !== "unknown-size-files" && value !== "multipart-course") {
    throw new TypeError("Invalid fallback reason");
  }
  return value;
};
var moduleDiscovery = (value) => {
  if (value !== "available" && value !== "disabled") {
    throw new TypeError("Invalid module discovery state");
  }
  return value;
};
var planSummary = (value) => {
  const input = record(value);
  exactKeys(input, [
    "courseId",
    "moduleDiscovery",
    "advertisedBytes",
    "unknownSizeCount",
    "resourceCount",
    "folderPathFallbackCount",
    "archivePartCount"
  ]);
  return {
    courseId: positiveInteger(input.courseId, "Invalid course ID"),
    moduleDiscovery: moduleDiscovery(input.moduleDiscovery),
    advertisedBytes: nonNegativeInteger(input.advertisedBytes),
    unknownSizeCount: nonNegativeInteger(input.unknownSizeCount),
    resourceCount: nonNegativeInteger(input.resourceCount),
    folderPathFallbackCount: nonNegativeInteger(input.folderPathFallbackCount),
    archivePartCount: positiveInteger(
      input.archivePartCount,
      "Invalid archive part count"
    )
  };
};
var coursePlanFailureCategory = (value) => {
  if (value !== "size-limit" && value !== "canvas-unavailable" && value !== "safety-validation" && value !== "unexpected-local") {
    throw new TypeError("Invalid course plan failure category");
  }
  return value;
};
var coursePlanFailure = (value) => {
  const input = record(value);
  exactKeys(input, ["courseId", "category"]);
  return {
    courseId: positiveInteger(input.courseId, "Invalid course ID"),
    category: coursePlanFailureCategory(input.category)
  };
};
var planEvent = (input, id) => {
  exactKeys(input, [
    "channel",
    "type",
    "runId",
    "requestedCourseCount",
    "selected",
    "skipped",
    "advertisedBytes",
    "unknownSizeCount",
    "resourceCount",
    "totalPlannedParts",
    "expectedArchiveCount",
    "requestedPackaging",
    "effectivePackaging",
    "fallbackReason"
  ]);
  const requestedCourseCount = positiveInteger(
    input.requestedCourseCount,
    "Invalid requested course count"
  );
  const selected = denseArray(input.selected, 1e4).map(planSummary);
  const skipped = denseArray(input.skipped, 1e4).map(coursePlanFailure);
  const selectedIds = selected.map((item) => item.courseId);
  const skippedIds = skipped.map((item) => item.courseId);
  if (selected.length + skipped.length !== requestedCourseCount || selected.length + skipped.length === 0 || new Set(selectedIds).size !== selectedIds.length || new Set(skippedIds).size !== skippedIds.length || selectedIds.some((courseId) => skippedIds.includes(courseId))) {
    throw new TypeError("Invalid plan courses");
  }
  const advertisedBytes = nonNegativeInteger(input.advertisedBytes);
  const unknownSizeCount = nonNegativeInteger(input.unknownSizeCount);
  const resourceCount = nonNegativeInteger(input.resourceCount);
  const totalPlannedParts = nonNegativeInteger(input.totalPlannedParts);
  const expectedArchiveCount = nonNegativeInteger(input.expectedArchiveCount);
  if (unknownSizeCount > resourceCount || selected.some(
    (item) => item.resourceCount > MAX_ARCHIVE_RESOURCES || item.unknownSizeCount > item.resourceCount || item.folderPathFallbackCount > item.resourceCount
  )) {
    throw new TypeError("Invalid plan counts");
  }
  if (selected.reduce((total, item) => total + item.advertisedBytes, 0) !== advertisedBytes || selected.reduce((total, item) => total + item.unknownSizeCount, 0) !== unknownSizeCount || selected.reduce((total, item) => total + item.resourceCount, 0) !== resourceCount) {
    throw new TypeError("Invalid plan totals");
  }
  const selectedPartCount = selected.reduce(
    (total, item) => total + item.archivePartCount,
    0
  );
  if (!Number.isSafeInteger(selectedPartCount) || selectedPartCount !== totalPlannedParts) {
    throw new TypeError("Invalid plan part totals");
  }
  const requestedPackaging = packaging(input.requestedPackaging);
  const effectivePackaging = packaging(input.effectivePackaging);
  const reason = fallbackReason(input.fallbackReason);
  const hasMultipartCourse = selected.some(
    ({ archivePartCount }) => archivePartCount > 1
  );
  const requiredArchiveCount = effectivePackaging === "per-course" ? totalPlannedParts : selected.length > 0 ? 1 : 0;
  if (expectedArchiveCount !== requiredArchiveCount) {
    throw new TypeError("Invalid expected archive count");
  }
  const combinedEntryCount = COMBINED_CORE_ENTRY_COUNT + COURSE_CORE_ENTRY_COUNT * selected.length + resourceCount;
  if (effectivePackaging === "combined" && (resourceCount > MAX_ARCHIVE_RESOURCES || !Number.isSafeInteger(combinedEntryCount) || combinedEntryCount > CLASSIC_ZIP_ENTRY_LIMIT)) {
    throw new TypeError("Invalid plan");
  }
  if (requestedPackaging === effectivePackaging && reason !== null || requestedPackaging !== effectivePackaging && reason === null || effectivePackaging === "combined" && reason !== null || reason === "multipart-course" && (requestedPackaging !== "combined" || effectivePackaging !== "per-course" || !hasMultipartCourse) || requestedPackaging === "combined" && hasMultipartCourse && reason !== "multipart-course" || reason === "unknown-size-files" && unknownSizeCount === 0 || requestedPackaging === "combined" && unknownSizeCount > 0 && !hasMultipartCourse && reason !== "unknown-size-files") {
    throw new TypeError("Invalid packaging fallback");
  }
  return {
    channel: RUNNER_CHANNEL,
    type: "PLAN_READY",
    runId: id,
    requestedCourseCount,
    selected,
    skipped,
    advertisedBytes,
    unknownSizeCount,
    resourceCount,
    totalPlannedParts,
    expectedArchiveCount,
    requestedPackaging,
    effectivePackaging,
    fallbackReason: reason
  };
};
var discoveryProgress = (input, id) => {
  exactKeys(input, [
    "channel",
    "type",
    "runId",
    "completed",
    "total",
    "currentCourseId"
  ]);
  const completed = nonNegativeInteger(input.completed);
  const total = positiveInteger(input.total, "Invalid course count");
  if (completed > total) throw new TypeError("Invalid discovery progress");
  return {
    channel: RUNNER_CHANNEL,
    type: "DISCOVERY_PROGRESS",
    runId: id,
    completed,
    total,
    currentCourseId: positiveInteger(
      input.currentCourseId,
      "Invalid course ID"
    )
  };
};
var aggregateProgress = (input, id) => {
  exactKeys(input, [
    "channel",
    "type",
    "runId",
    "stage",
    "currentCourseId",
    "currentCourseIndex",
    "totalCourses",
    "completedCourses",
    "currentPartIndex",
    "totalParts",
    "totalArchiveParts",
    "completedParts",
    "failedParts",
    "completed",
    "total",
    "failed"
  ]);
  const stage = input.stage;
  if (typeof stage !== "string" || !["discovery", "download", "sanitize", "package"].includes(stage)) {
    throw new TypeError("Unsupported runner event");
  }
  const currentCourseId = positiveInteger(
    input.currentCourseId,
    "Invalid course ID"
  );
  const currentCourseIndex = nonNegativeInteger(input.currentCourseIndex);
  const totalCourses = positiveInteger(
    input.totalCourses,
    "Invalid course count"
  );
  const completedCourses = nonNegativeInteger(input.completedCourses);
  const currentPartIndex = positiveInteger(
    input.currentPartIndex,
    "Invalid current part index"
  );
  const totalParts = positiveInteger(input.totalParts, "Invalid part count");
  const totalArchiveParts = positiveInteger(
    input.totalArchiveParts,
    "Invalid total archive part count"
  );
  const completedParts = nonNegativeInteger(input.completedParts);
  const failedParts = nonNegativeInteger(input.failedParts);
  const completed = nonNegativeInteger(input.completed);
  const total = nonNegativeInteger(input.total);
  const failed = nonNegativeInteger(input.failed);
  if (currentCourseIndex >= totalCourses || completedCourses > currentCourseIndex || currentPartIndex > totalParts || completedParts + failedParts > totalArchiveParts || !Number.isSafeInteger(completedParts + failedParts) || total > MAX_ARCHIVE_RESOURCES || completed > total || failed > completed) {
    throw new TypeError("Invalid progress counts");
  }
  const value = {
    stage,
    currentCourseId,
    currentCourseIndex,
    totalCourses,
    completedCourses,
    currentPartIndex,
    totalParts,
    totalArchiveParts,
    completedParts,
    failedParts,
    completed,
    total,
    failed
  };
  return { channel: RUNNER_CHANNEL, type: "PROGRESS", runId: id, ...value };
};
var terminalMessage = (value, allowed) => {
  if (typeof value !== "string" || !allowed.includes(value)) {
    throw new TypeError("Unsupported runner event");
  }
  return value;
};
function parseExtensionCommand(value) {
  const input = record(value);
  if (input.channel !== EXTENSION_CHANNEL)
    throw new TypeError("Invalid channel");
  const id = runId(input.runId);
  if (input.type === "LIST_COURSES" || input.type === "CANCEL" || input.type === "CONFIRM_PLAN") {
    exactKeys(input, ["channel", "type", "runId"]);
    return { channel: EXTENSION_CHANNEL, type: input.type, runId: id };
  }
  if (input.type === "START_RUN") {
    exactKeys(input, ["channel", "type", "runId", "courseIds", "packaging"]);
    return {
      channel: EXTENSION_CHANNEL,
      type: "START_RUN",
      runId: id,
      courseIds: courseIds(input.courseIds),
      packaging: packaging(input.packaging)
    };
  }
  throw new TypeError("Unsupported command");
}
function parseRunnerEvent(value) {
  const input = record(value);
  if (input.channel !== RUNNER_CHANNEL) throw new TypeError("Invalid channel");
  const id = runId(input.runId);
  if (input.type === "COURSES" && Array.isArray(input.courses)) {
    exactKeys(input, ["channel", "type", "runId", "courses"]);
    return {
      channel: RUNNER_CHANNEL,
      type: "COURSES",
      runId: id,
      courses: courseArray(input.courses)
    };
  }
  if (input.type === "PLAN_READY") return planEvent(input, id);
  if (input.type === "DISCOVERY_PROGRESS") {
    return discoveryProgress(input, id);
  }
  if (input.type === "PROGRESS") return aggregateProgress(input, id);
  if (input.type === "COMPLETE") {
    exactKeys(input, [
      "channel",
      "type",
      "runId",
      "message",
      "packaging",
      "completedCourses",
      "completedCourseIds",
      "failedCourses",
      "outputCount",
      "completedParts",
      "failedParts",
      "success",
      "failed",
      "unavailable",
      "unsupported",
      "external"
    ]);
    const message = terminalMessage(input.message, [
      RUNNER_TERMINAL_MESSAGES.complete,
      RUNNER_TERMINAL_MESSAGES.noArchives
    ]);
    const packagingMode = packaging(input.packaging);
    const completedCourses = nonNegativeInteger(input.completedCourses);
    const completedCourseIds = denseArray(input.completedCourseIds, 1e4).map(
      (value2) => positiveInteger(value2, "Invalid completed course ID")
    );
    const failedCourses = nonNegativeInteger(input.failedCourses);
    const outputCount = nonNegativeInteger(input.outputCount);
    const completedParts = nonNegativeInteger(input.completedParts);
    const failedParts = nonNegativeInteger(input.failedParts);
    const zeroOutput = completedCourses === 0;
    const validZeroOutput = zeroOutput && message === RUNNER_TERMINAL_MESSAGES.noArchives && packagingMode === "per-course" && completedCourseIds.length === 0 && failedCourses > 0 && outputCount === 0 && completedParts === 0 && failedParts > 0;
    if (zeroOutput && !validZeroOutput || !zeroOutput && (message !== RUNNER_TERMINAL_MESSAGES.complete || completedCourseIds.length !== completedCourses || new Set(completedCourseIds).size !== completedCourseIds.length || completedParts < completedCourses || failedParts < failedCourses || outputCount === 0 || packagingMode === "combined" && outputCount !== 1 || packagingMode === "per-course" && outputCount !== completedParts)) {
      throw new TypeError("Invalid terminal course counts");
    }
    const counts = {
      success: nonNegativeInteger(input.success),
      failed: nonNegativeInteger(input.failed),
      unavailable: nonNegativeInteger(input.unavailable),
      unsupported: nonNegativeInteger(input.unsupported),
      external: nonNegativeInteger(input.external)
    };
    const total = Object.values(counts).reduce((sum, count) => sum + count, 0);
    const maximumTotal = completedParts * MAX_ARCHIVE_RESOURCES;
    if (!Number.isSafeInteger(maximumTotal) || !Number.isSafeInteger(total) || total > maximumTotal) {
      throw new TypeError("Invalid terminal counts");
    }
    if (validZeroOutput && total !== 0) {
      throw new TypeError("Invalid terminal counts");
    }
    return {
      channel: RUNNER_CHANNEL,
      type: "COMPLETE",
      runId: id,
      message,
      packaging: packagingMode,
      completedCourses,
      completedCourseIds,
      failedCourses,
      outputCount,
      completedParts,
      failedParts,
      ...counts
    };
  }
  if (input.type === "CANCELLED" || input.type === "FAILED") {
    exactKeys(input, ["channel", "type", "runId", "message"]);
    const message = terminalMessage(
      input.message,
      input.type === "CANCELLED" ? [
        RUNNER_TERMINAL_MESSAGES.cancelled,
        RUNNER_TERMINAL_MESSAGES.navigation
      ] : [
        RUNNER_TERMINAL_MESSAGES.active,
        RUNNER_TERMINAL_MESSAGES.response,
        RUNNER_TERMINAL_MESSAGES.safety,
        RUNNER_TERMINAL_MESSAGES.session,
        RUNNER_TERMINAL_MESSAGES.size,
        RUNNER_TERMINAL_MESSAGES.unexpected,
        RUNNER_TERMINAL_MESSAGES.unlisted
      ]
    );
    return { channel: RUNNER_CHANNEL, type: input.type, runId: id, message };
  }
  throw new TypeError("Unsupported runner event");
}

// src/sidepanel/state.ts
var initialState = {
  name: "connect",
  message: "Connect to a signed-in Canvas tab to begin.",
  busy: false,
  retry: null
};
var blocked = (message) => ({ name: "blocked", message });
var reduceState = (state2, event) => {
  if (event.type === "CONNECTING") {
    if (state2.name === "connect") return { ...state2, busy: true };
    if (state2.name === "complete" || state2.name === "blocked") {
      return {
        name: "connect",
        message: "Connect to a signed-in Canvas tab to begin.",
        busy: true,
        retry: null
      };
    }
  }
  if (event.type === "COURSES" && state2.name === "connect") {
    if (state2.retry !== null) {
      const availableById = new Map(
        event.courses.map((course) => [course.id, course])
      );
      const selectedIds = state2.retry.courseIds.filter(
        (courseId) => availableById.has(courseId)
      );
      return selectedIds.length > 0 ? {
        name: "configure",
        courses: event.courses,
        selectedIds,
        packaging: state2.retry.packaging,
        busy: false,
        discoveryProgress: null
      } : blocked("The unfinished courses are no longer available.");
    }
    return event.courses.length > 0 ? { name: "choose", courses: event.courses, selectedIds: [] } : blocked("No accessible Canvas courses were found.");
  }
  if (event.type === "SELECT" && state2.name === "choose") {
    if (!state2.courses.some((course) => course.id === event.courseId))
      return blocked("The selected course is no longer available.");
    const selectedIds = state2.selectedIds.includes(event.courseId) ? state2.selectedIds.filter((id) => id !== event.courseId) : [...state2.selectedIds, event.courseId];
    return { ...state2, selectedIds };
  }
  if (event.type === "SELECT_ALL" && state2.name === "choose") {
    const allSelected = state2.courses.length > 0 && state2.courses.every((course) => state2.selectedIds.includes(course.id));
    return {
      ...state2,
      selectedIds: allSelected ? [] : state2.courses.map((course) => course.id)
    };
  }
  if (event.type === "CONFIGURE" && state2.name === "choose") {
    return state2.selectedIds.length > 0 ? {
      name: "configure",
      courses: state2.courses,
      selectedIds: state2.selectedIds,
      packaging: "per-course",
      busy: false,
      discoveryProgress: null
    } : state2;
  }
  if (event.type === "SET_PACKAGING" && state2.name === "configure") {
    return { ...state2, packaging: event.packaging };
  }
  if (event.type === "DISCOVERING" && state2.name === "configure") {
    return { ...state2, busy: true, discoveryProgress: null };
  }
  if (event.type === "DISCOVERY_PROGRESS" && state2.name === "configure") {
    return state2.busy ? { ...state2, discoveryProgress: event.progress } : state2;
  }
  if (event.type === "PLAN_READY" && state2.name === "configure") {
    return {
      name: "review",
      courses: state2.courses,
      selectedIds: state2.selectedIds,
      plan: event.plan
    };
  }
  if (event.type === "CONFIRM" && state2.name === "review") {
    const firstCourse = state2.plan.selected[0];
    if (firstCourse === void 0) return state2;
    return {
      name: "packing",
      courses: state2.courses,
      selectedIds: state2.selectedIds,
      packaging: state2.plan.effectivePackaging,
      requestedPackaging: state2.plan.requestedPackaging,
      plan: state2.plan,
      progress: {
        stage: "discovery",
        currentCourseId: firstCourse.courseId,
        currentCourseIndex: 0,
        totalCourses: state2.plan.selected.length,
        completedCourses: 0,
        currentPartIndex: 1,
        totalParts: firstCourse.archivePartCount,
        totalArchiveParts: state2.plan.totalPlannedParts,
        completedParts: 0,
        failedParts: 0,
        completed: 0,
        total: firstCourse.resourceCount,
        failed: 0
      }
    };
  }
  if (event.type === "PROGRESS" && state2.name === "packing") {
    return { ...state2, progress: event.progress };
  }
  if (event.type === "COMPLETE" && state2.name === "packing") {
    const unresolvedIds = /* @__PURE__ */ new Set([
      ...state2.plan.skipped.map(({ courseId }) => courseId),
      ...state2.plan.selected.filter(({ courseId }) => !event.completedCourseIds.includes(courseId)).map(({ courseId }) => courseId)
    ]);
    return {
      name: "complete",
      courses: state2.courses,
      requestedPackaging: state2.requestedPackaging,
      plan: state2.plan,
      retryCourseIds: state2.selectedIds.filter(
        (courseId) => unresolvedIds.has(courseId)
      ),
      packaging: event.packaging,
      completedCourses: event.completedCourses,
      completedCourseIds: event.completedCourseIds,
      failedCourses: event.failedCourses,
      outputCount: event.outputCount,
      completedParts: event.completedParts,
      failedParts: event.failedParts,
      counts: event.counts
    };
  }
  if (event.type === "RETRY") {
    if (state2.name === "review" && state2.plan.selected.length === 0 && state2.plan.skipped.length > 0) {
      return {
        name: "connect",
        message: "Reconnect to retry unfinished courses.",
        busy: false,
        retry: {
          courseIds: state2.selectedIds.filter(
            (courseId) => state2.plan.skipped.some((failure) => failure.courseId === courseId)
          ),
          packaging: state2.plan.requestedPackaging
        }
      };
    }
    if (state2.name === "complete" && state2.retryCourseIds.length > 0) {
      return {
        name: "connect",
        message: "Reconnect to retry unfinished courses.",
        busy: false,
        retry: {
          courseIds: state2.retryCourseIds,
          packaging: state2.requestedPackaging
        }
      };
    }
  }
  if (event.type === "FAILED") {
    if (state2.name === "connect" || state2.name === "choose" || state2.name === "configure" || state2.name === "review" || state2.name === "packing")
      return blocked(event.message);
  }
  if (event.type === "TAB_LOST" && state2.name !== "complete" && state2.name !== "blocked") {
    return blocked(event.message);
  }
  return state2;
};

// src/sidepanel/main.ts
var appElement = document.querySelector("#app");
if (!appElement) throw new Error("GradPack root is missing");
var app = appElement;
var state = initialState;
var activeRunId = "";
var activeTabId = null;
var terminalReceived = false;
var cancelRequested = false;
var button = (label, action, options = {}) => {
  const element = document.createElement("button");
  element.type = "button";
  element.textContent = label;
  element.disabled = options.disabled === true;
  if (options.busy) element.setAttribute("aria-busy", "true");
  element.addEventListener("click", action);
  return element;
};
var paragraph = (text, className) => {
  const element = document.createElement("p");
  element.textContent = text;
  if (className) element.className = className;
  return element;
};
var courseLabel = (course) => {
  const details = [
    course.courseCode,
    course.concluded ? "concluded" : course.workflowState
  ].filter((value) => value.trim().length > 0).join(" \xB7 ");
  return details ? `${course.name} \u2014 ${details}` : course.name;
};
var trustCard = () => {
  const section = document.createElement("section");
  section.className = "trust-card";
  const heading = document.createElement("h2");
  heading.textContent = "Your courses stay with you";
  const trust = paragraph(
    "GradPack works only with Frankfurt School Canvas and uses the session already open in your browser. Everything is processed locally\u2014there is no telemetry, backend, or cloud upload. Your archives are saved only to your computer."
  );
  const responsibleUse = paragraph(
    "Please keep downloaded course materials for your own use and do not redistribute them.",
    "responsible-use"
  );
  const label = document.createElement("strong");
  label.textContent = "For personal study: ";
  responsibleUse.prepend(label);
  section.append(heading, trust, responsibleUse);
  return section;
};
var notices = () => {
  const section = document.createElement("section");
  section.className = "notices";
  const heading = document.createElement("h2");
  heading.textContent = "Before you pack";
  const list = document.createElement("ul");
  for (const text of [
    "Select one or more courses. Combined archives fall back to separate ZIPs when the 250 MB or resource safety limit would be exceeded.",
    "Keep this Canvas tab open and signed in until the ZIP downloads finish.",
    "Only currently accessible material is retrieved. Some resources may be unavailable, fail, remain external, or be unsupported."
  ]) {
    const item = document.createElement("li");
    item.textContent = text;
    list.append(item);
  }
  section.append(heading, list);
  return section;
};
var progressText = (progress) => `${progress.stage}: course ${progress.currentCourseIndex + 1} of ${progress.totalCourses}, part ${progress.currentPartIndex} of ${progress.totalParts}; ${progress.completed} of ${progress.total}; ${progress.failed} failed`;
var packagingLabel = (packaging2) => packaging2 === "combined" ? "one combined ZIP" : "one ZIP per course";
var COURSE_PLAN_FAILURE_MESSAGES = Object.freeze({
  "size-limit": "This course exceeds the 250 MiB safety limit.",
  "canvas-unavailable": "Canvas did not provide usable course metadata.",
  "safety-validation": "Course metadata did not pass GradPack's safety checks.",
  "unexpected-local": "A local course operation could not be completed."
});
var MODULES_DISABLED_NOTICE = "Module navigation is unavailable; GradPack will archive accessible pages and files instead.";
var courseForId = (courses, courseId) => courses.find((course) => course.id === courseId);
var courseList = (className, entries) => {
  const list = document.createElement("ul");
  list.className = className;
  for (const { course, detail } of entries) {
    const item = document.createElement("li");
    item.textContent = detail ? `${courseLabel(course)} \u2014 ${detail}` : courseLabel(course);
    list.append(item);
  }
  return list;
};
var render = (focus = null) => {
  app.replaceChildren();
  const heading = document.createElement("h1");
  heading.tabIndex = -1;
  const body = document.createElement("section");
  if (state.name === "connect") {
    heading.textContent = "Connect to Canvas";
    body.append(
      paragraph(state.message),
      notices(),
      button(state.busy ? "Connecting\u2026" : "Connect", () => void connect(), {
        disabled: state.busy,
        busy: state.busy
      })
    );
  } else if (state.name === "choose") {
    heading.textContent = "Choose courses";
    const fieldset = document.createElement("fieldset");
    const legend = document.createElement("legend");
    legend.textContent = "Accessible courses";
    fieldset.append(legend);
    const selectedIds = state.selectedIds;
    const allSelected = state.courses.every(
      (course) => selectedIds.includes(course.id)
    );
    const partiallySelected = state.selectedIds.length > 0 && !allSelected;
    const selectAllLabel = document.createElement("label");
    selectAllLabel.className = "select-all";
    const selectAll = document.createElement("input");
    selectAll.type = "checkbox";
    selectAll.name = "course-all";
    selectAll.checked = allSelected;
    selectAll.indeterminate = partiallySelected;
    selectAll.addEventListener("change", () => update({ type: "SELECT_ALL" }));
    selectAllLabel.append(
      selectAll,
      document.createTextNode("Select all courses")
    );
    fieldset.append(selectAllLabel);
    for (const course of state.courses) {
      const label = document.createElement("label");
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.name = "course";
      checkbox.value = String(course.id);
      checkbox.checked = state.selectedIds.includes(course.id);
      checkbox.addEventListener(
        "change",
        () => update({ type: "SELECT", courseId: course.id })
      );
      label.append(checkbox, document.createTextNode(courseLabel(course)));
      fieldset.append(label);
    }
    body.append(
      paragraph("Select one or more accessible courses."),
      trustCard(),
      fieldset,
      paragraph(
        `${state.selectedIds.length} of ${state.courses.length} courses selected.`,
        "selection-count"
      ),
      button("Continue", () => update({ type: "CONFIGURE" }), {
        disabled: state.selectedIds.length === 0
      })
    );
  } else if (state.name === "configure") {
    heading.textContent = "Configure archives";
    const fieldset = document.createElement("fieldset");
    const legend = document.createElement("legend");
    legend.textContent = "Packaging";
    fieldset.append(legend);
    for (const [value, labelText] of [
      ["per-course", "One ZIP per course"],
      ["combined", "One combined ZIP"]
    ]) {
      const label = document.createElement("label");
      const radio = document.createElement("input");
      radio.type = "radio";
      radio.name = "packaging";
      radio.value = value;
      radio.checked = state.packaging === value;
      radio.disabled = state.busy || cancelRequested;
      radio.addEventListener(
        "change",
        () => update({ type: "SET_PACKAGING", packaging: value })
      );
      label.append(radio, document.createTextNode(labelText));
      fieldset.append(label);
    }
    const discoveryStatus = state.busy ? paragraph(
      state.discoveryProgress ? `Checking course ${state.discoveryProgress.completed} of ${state.discoveryProgress.total}` : `Preparing to check ${state.selectedIds.length} course(s)`,
      "discovery-progress"
    ) : null;
    if (discoveryStatus) {
      discoveryStatus.setAttribute("role", "status");
      discoveryStatus.setAttribute("aria-live", "polite");
    }
    body.append(
      paragraph(`${state.selectedIds.length} course(s) selected.`),
      trustCard(),
      fieldset,
      notices(),
      ...discoveryStatus ? [discoveryStatus] : [],
      button(
        state.busy ? "Discovering\u2026" : "Discover selected courses",
        () => void startRun(),
        { disabled: state.busy || cancelRequested, busy: state.busy }
      ),
      button(
        cancelRequested ? "Cancelling\u2026" : "Cancel",
        () => void cancelRun(),
        { disabled: cancelRequested, busy: cancelRequested }
      )
    );
  } else if (state.name === "review") {
    const review = state;
    heading.textContent = "Review plan";
    const readyCourses = review.plan.selected.flatMap((summary) => {
      const course = courseForId(review.courses, summary.courseId);
      const details = [
        summary.moduleDiscovery === "disabled" ? MODULES_DISABLED_NOTICE : null,
        summary.folderPathFallbackCount > 0 ? `${summary.folderPathFallbackCount} file(s) will be saved in files/unfiled because Canvas folder placement was unavailable.` : null,
        summary.archivePartCount > 1 ? `${summary.archivePartCount} ZIP parts will be downloaded.` : null
      ].filter((value) => value !== null).join(" ");
      return course ? [
        {
          course,
          ...details ? { detail: details } : {}
        }
      ] : [];
    });
    const skippedCourses = review.plan.skipped.map((failure) => {
      const course = courseForId(review.courses, failure.courseId);
      return course ? {
        course,
        detail: COURSE_PLAN_FAILURE_MESSAGES[failure.category]
      } : null;
    }).filter(
      (entry) => entry !== null
    );
    body.append(
      paragraph(
        `${readyCourses.length} courses ready; ${skippedCourses.length} skipped.`,
        "plan-summary"
      ),
      ...readyCourses.length > 0 ? [
        paragraph("Ready courses", "list-heading"),
        courseList("ready-courses", readyCourses)
      ] : [],
      ...skippedCourses.length > 0 ? [
        paragraph("Skipped courses", "list-heading"),
        courseList("skipped-courses", skippedCourses)
      ] : [],
      paragraph(
        `Requested packaging: ${packagingLabel(state.plan.requestedPackaging)}.`
      ),
      paragraph(
        `Effective packaging: ${packagingLabel(state.plan.effectivePackaging)}.`
      ),
      paragraph(
        `Advertised material: ${state.plan.advertisedBytes} bytes across ${state.plan.resourceCount} resource(s).`
      ),
      paragraph(
        `Expected downloads: ${state.plan.expectedArchiveCount} ZIP archive(s).`,
        "archive-count"
      ),
      ...state.plan.unknownSizeCount > 0 ? [
        paragraph(
          `Unknown-size files: ${state.plan.unknownSizeCount}. GradPack will stream them under the hard 250 MiB per-course cap.`,
          "unknown-size-notice"
        )
      ] : [],
      state.plan.fallbackReason === "multipart-course" ? paragraph(
        "The requested combined archive will be changed to separate ZIP parts because at least one course requires multiple bounded archives.",
        "fallback-notice"
      ) : state.plan.fallbackReason === "unknown-size-files" ? paragraph(
        "The requested combined archive will be changed to separate course ZIPs because unknown-size files must be streamed under the hard 250 MiB per-course cap.",
        "fallback-notice"
      ) : state.plan.fallbackReason ? paragraph(
        "The requested combined archive will fall back to separate course ZIPs because the combined safety limit would be exceeded.",
        "fallback-notice"
      ) : paragraph(
        readyCourses.length > 0 ? "Discovery is complete. Confirm to begin local retrieval." : "No course is ready for retrieval. Retry the skipped courses."
      ),
      ...readyCourses.length > 0 ? [button("Continue with ready courses", () => void confirmPlan())] : [button("Retry skipped courses", () => void retryUnfinished())],
      button(
        cancelRequested ? "Cancelling\u2026" : "Cancel",
        () => void cancelRun(),
        { disabled: cancelRequested, busy: cancelRequested }
      )
    );
  } else if (state.name === "packing") {
    heading.textContent = "Packing courses";
    const status = paragraph(progressText(state.progress), "progress");
    status.setAttribute("role", "status");
    status.setAttribute("aria-live", "polite");
    body.setAttribute("aria-busy", "true");
    body.append(
      status,
      paragraph(`Output: ${packagingLabel(state.packaging)}.`),
      paragraph("Keep the connected Canvas tab open and signed in."),
      button(
        cancelRequested ? "Cancelling\u2026" : "Cancel",
        () => void cancelRun(),
        { disabled: cancelRequested, busy: cancelRequested }
      )
    );
  } else if (state.name === "complete") {
    const complete = state;
    const downloaded = complete.outputCount > 0;
    heading.textContent = downloaded ? "Archives downloaded" : "No archives downloaded";
    const unfinished = complete.retryCourseIds.map((courseId) => {
      const course = courseForId(complete.courses, courseId);
      if (!course) return null;
      const planningFailure = complete.plan.skipped.find(
        (failure) => failure.courseId === courseId
      );
      return {
        course,
        detail: planningFailure ? COURSE_PLAN_FAILURE_MESSAGES[planningFailure.category] : "Archive creation did not complete."
      };
    }).filter(
      (entry) => entry !== null
    );
    body.append(
      paragraph(
        downloaded ? "Your GradPack archives were downloaded." : "No course archives were downloaded."
      ),
      paragraph(
        `${state.outputCount} archive(s) downloaded; ${state.completedCourses} course(s) completed; ${state.failedCourses} course(s) failed; ${state.completedParts} part(s) completed; ${state.failedParts} part(s) failed.`,
        "archive-summary"
      ),
      paragraph(
        `${state.counts.success} successful; ${state.counts.failed} failed; ${state.counts.unavailable} unavailable; ${state.counts.unsupported} unsupported; ${state.counts.external} external.`,
        "outcome-summary"
      ),
      ...downloaded ? [
        paragraph(
          "Review manifest.json in each ZIP for the resource outcome list."
        )
      ] : [],
      ...unfinished.length > 0 ? [
        paragraph(
          `${unfinished.length} unfinished course(s) can be retried.`,
          "unfinished-summary"
        ),
        courseList("unfinished-courses", unfinished),
        button("Retry unfinished courses", () => void retryUnfinished())
      ] : [],
      button("Start again", () => void connect())
    );
  } else {
    heading.textContent = "GradPack stopped";
    body.append(
      paragraph(state.message),
      button("Try again", () => void connect())
    );
  }
  app.append(heading, body);
  const focusTarget = focus?.type === "course-all" ? app.querySelector('input[name="course-all"]') : focus?.type === "course" ? [
    ...app.querySelectorAll('input[name="course"]')
  ].find((checkbox) => checkbox.value === String(focus.courseId)) : null;
  (focusTarget ?? heading).focus();
};
var update = (event) => {
  const previous = state;
  const next = reduceState(state, event);
  if (next === previous) return;
  state = next;
  if (previous.name === "packing" && next.name === "packing") {
    const status = app.querySelector(".progress");
    if (status) {
      status.textContent = progressText(next.progress);
      return;
    }
  }
  const focus = previous.name === "choose" && next.name === "choose" ? event.type === "SELECT_ALL" ? { type: "course-all" } : event.type === "SELECT" ? { type: "course", courseId: event.courseId } : null : null;
  render(focus);
};
var exactConnection = (value) => {
  if (typeof value !== "object" || value === null || Array.isArray(value))
    throw new TypeError("Invalid connection response");
  const keys = Reflect.ownKeys(value);
  if (keys.length !== 1 || typeof keys[0] !== "string")
    throw new TypeError("Invalid connection response");
  const record2 = value;
  if (keys[0] === "tabId" && Number.isSafeInteger(record2.tabId) && Number(record2.tabId) >= 0)
    return { tabId: Number(record2.tabId) };
  if (keys[0] === "error" && typeof record2.error === "string")
    return { error: record2.error };
  throw new TypeError("Invalid connection response");
};
async function connect() {
  const runId2 = `run-${crypto.randomUUID()}`;
  activeRunId = runId2;
  activeTabId = null;
  terminalReceived = false;
  cancelRequested = false;
  update({ type: "CONNECTING" });
  try {
    const result = exactConnection(
      await chrome.runtime.sendMessage("GRADPACK_ENSURE_RUNNER")
    );
    if (activeRunId !== runId2) return;
    if ("error" in result) {
      update({ type: "FAILED", message: RUNNER_TERMINAL_MESSAGES.connection });
      return;
    }
    activeTabId = result.tabId;
    await chrome.tabs.sendMessage(
      activeTabId,
      parseExtensionCommand({
        channel: EXTENSION_CHANNEL,
        type: "LIST_COURSES",
        runId: runId2
      })
    );
  } catch {
    if (activeRunId === runId2)
      update({ type: "FAILED", message: RUNNER_TERMINAL_MESSAGES.connection });
  }
}
async function startRun() {
  const tabId = activeTabId;
  const runId2 = activeRunId;
  if (tabId === null || state.name !== "configure" || state.busy) return;
  cancelRequested = false;
  const courseIds2 = [...state.selectedIds];
  const packaging2 = state.packaging;
  update({ type: "DISCOVERING" });
  try {
    await chrome.tabs.sendMessage(
      tabId,
      parseExtensionCommand({
        channel: EXTENSION_CHANNEL,
        type: "START_RUN",
        runId: runId2,
        courseIds: courseIds2,
        packaging: packaging2
      })
    );
  } catch {
    if (activeRunId === runId2 && !terminalReceived) {
      terminalReceived = true;
      update({ type: "FAILED", message: RUNNER_TERMINAL_MESSAGES.tab });
    }
  }
}
async function confirmPlan() {
  const tabId = activeTabId;
  const runId2 = activeRunId;
  if (tabId === null || state.name !== "review" || state.plan.selected.length === 0 || cancelRequested)
    return;
  cancelRequested = false;
  update({ type: "CONFIRM" });
  try {
    await chrome.tabs.sendMessage(
      tabId,
      parseExtensionCommand({
        channel: EXTENSION_CHANNEL,
        type: "CONFIRM_PLAN",
        runId: runId2
      })
    );
  } catch {
    if (activeRunId === runId2 && !terminalReceived) {
      terminalReceived = true;
      update({ type: "FAILED", message: RUNNER_TERMINAL_MESSAGES.tab });
    }
  }
}
async function cancelRun() {
  const tabId = activeTabId;
  const runId2 = activeRunId;
  if (tabId === null || terminalReceived || cancelRequested || state.name !== "configure" && state.name !== "review" && state.name !== "packing")
    return;
  cancelRequested = true;
  render();
  try {
    await chrome.tabs.sendMessage(
      tabId,
      parseExtensionCommand({
        channel: EXTENSION_CHANNEL,
        type: "CANCEL",
        runId: runId2
      })
    );
  } catch {
    if (activeRunId === runId2 && activeTabId === tabId && !terminalReceived) {
      terminalReceived = true;
      update({ type: "FAILED", message: RUNNER_TERMINAL_MESSAGES.tab });
    }
  }
}
async function retryUnfinished() {
  const retryable = state.name === "review" && state.plan.selected.length === 0 && state.plan.skipped.length > 0 || state.name === "complete" && state.retryCourseIds.length > 0;
  if (!retryable) return;
  if (state.name === "review") await cancelRun();
  update({ type: "RETRY" });
  if (state.name === "connect") await connect();
}
chrome.runtime.onMessage.addListener((raw, sender) => {
  if (sender.id !== chrome.runtime.id || activeTabId === null || sender.tab?.id !== activeTabId)
    return;
  let event;
  try {
    event = parseRunnerEvent(raw);
  } catch {
    return;
  }
  if (event.runId !== activeRunId || terminalReceived) return;
  if (event.type === "COURSES") {
    const retrying = state.name === "connect" && state.retry !== null;
    update({ type: "COURSES", courses: event.courses });
    if (retrying && state.name === "configure") void startRun();
  } else if (event.type === "DISCOVERY_PROGRESS") {
    if (state.name !== "configure" || !state.busy || event.total !== state.selectedIds.length || event.completed === 0 || state.selectedIds[event.completed - 1] !== event.currentCourseId) {
      return;
    }
    update({ type: "DISCOVERY_PROGRESS", progress: event });
  } else if (event.type === "PLAN_READY") {
    if (state.name !== "configure" || !state.busy) return;
    const plannedIds = [
      ...event.selected.map(({ courseId }) => courseId),
      ...event.skipped.map(({ courseId }) => courseId)
    ];
    if (event.requestedCourseCount !== state.selectedIds.length || event.requestedPackaging !== state.packaging || plannedIds.length !== state.selectedIds.length || new Set(plannedIds).size !== plannedIds.length || !state.selectedIds.every((courseId) => plannedIds.includes(courseId))) {
      return;
    }
    update({ type: "PLAN_READY", plan: event });
  } else if (event.type === "PROGRESS") {
    if (state.name !== "packing") return;
    const selectedCourse = state.plan.selected[event.currentCourseIndex];
    if (event.totalCourses !== state.plan.selected.length || selectedCourse?.courseId !== event.currentCourseId || event.total > selectedCourse.resourceCount || event.totalParts !== selectedCourse.archivePartCount || event.totalArchiveParts !== state.plan.totalPlannedParts) {
      return;
    }
    update({ type: "PROGRESS", progress: event });
  } else if (event.type === "COMPLETE") {
    if (state.name !== "packing") return;
    const counts = {
      success: event.success,
      failed: event.failed,
      unavailable: event.unavailable,
      unsupported: event.unsupported,
      external: event.external
    };
    const total = Object.values(counts).reduce((sum, count) => sum + count, 0);
    const resolvedCourses = event.completedCourses + event.failedCourses;
    const selectedById = new Map(
      state.plan.selected.map((selected) => [selected.courseId, selected])
    );
    const completedAreSelected = event.completedCourseIds.every(
      (courseId) => selectedById.has(courseId)
    );
    const expectedOutcomeTotal = event.completedCourseIds.reduce(
      (sum, courseId) => sum + (selectedById.get(courseId)?.resourceCount ?? 0),
      0
    );
    const expectedPackaging = event.failedCourses > 0 ? "per-course" : state.plan.effectivePackaging;
    if (!Number.isSafeInteger(resolvedCourses) || event.packaging !== expectedPackaging || resolvedCourses !== state.plan.selected.length || event.failedCourses !== state.plan.selected.length - event.completedCourseIds.length || !completedAreSelected || !Number.isSafeInteger(expectedOutcomeTotal) || total < expectedOutcomeTotal || total > state.plan.resourceCount || event.packaging === "per-course" && event.outputCount !== event.completedParts) {
      return;
    }
    const previous = state;
    update({
      type: "COMPLETE",
      packaging: event.packaging,
      completedCourses: event.completedCourses,
      completedCourseIds: event.completedCourseIds,
      failedCourses: event.failedCourses,
      outputCount: event.outputCount,
      completedParts: event.completedParts,
      failedParts: event.failedParts,
      counts
    });
    terminalReceived = state !== previous;
  } else {
    const previous = state;
    update({ type: "FAILED", message: event.message });
    terminalReceived = state !== previous;
  }
});
var stopForConnectedTab = (tabId) => {
  if (activeTabId !== tabId || terminalReceived || state.name === "complete" || state.name === "blocked")
    return;
  terminalReceived = true;
  cancelRequested = false;
  activeTabId = null;
  update({ type: "TAB_LOST", message: RUNNER_TERMINAL_MESSAGES.tab });
};
chrome.tabs.onRemoved.addListener((tabId) => stopForConnectedTab(tabId));
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === "loading" || changeInfo.url !== void 0) {
    stopForConnectedTab(tabId);
  }
});
render();
