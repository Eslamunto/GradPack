"use strict";
(() => {
  // node_modules/.pnpm/fflate@0.8.3/node_modules/fflate/esm/browser.js
  var u8 = Uint8Array;
  var u16 = Uint16Array;
  var i32 = Int32Array;
  var fleb = new u8([
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    1,
    1,
    1,
    2,
    2,
    2,
    2,
    3,
    3,
    3,
    3,
    4,
    4,
    4,
    4,
    5,
    5,
    5,
    5,
    0,
    /* unused */
    0,
    0,
    /* impossible */
    0
  ]);
  var fdeb = new u8([
    0,
    0,
    0,
    0,
    1,
    1,
    2,
    2,
    3,
    3,
    4,
    4,
    5,
    5,
    6,
    6,
    7,
    7,
    8,
    8,
    9,
    9,
    10,
    10,
    11,
    11,
    12,
    12,
    13,
    13,
    /* unused */
    0,
    0
  ]);
  var clim = new u8([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]);
  var freb = function(eb, start) {
    var b = new u16(31);
    for (var i2 = 0; i2 < 31; ++i2) {
      b[i2] = start += 1 << eb[i2 - 1];
    }
    var r = new i32(b[30]);
    for (var i2 = 1; i2 < 30; ++i2) {
      for (var j = b[i2]; j < b[i2 + 1]; ++j) {
        r[j] = j - b[i2] << 5 | i2;
      }
    }
    return { b, r };
  };
  var _a = freb(fleb, 2);
  var fl = _a.b;
  var revfl = _a.r;
  fl[28] = 258, revfl[258] = 28;
  var _b = freb(fdeb, 0);
  var fd = _b.b;
  var revfd = _b.r;
  var rev = new u16(32768);
  for (i = 0; i < 32768; ++i) {
    x = (i & 43690) >> 1 | (i & 21845) << 1;
    x = (x & 52428) >> 2 | (x & 13107) << 2;
    x = (x & 61680) >> 4 | (x & 3855) << 4;
    rev[i] = ((x & 65280) >> 8 | (x & 255) << 8) >> 1;
  }
  var x;
  var i;
  var hMap = (function(cd, mb, r) {
    var s = cd.length;
    var i2 = 0;
    var l = new u16(mb);
    for (; i2 < s; ++i2) {
      if (cd[i2])
        ++l[cd[i2] - 1];
    }
    var le = new u16(mb);
    for (i2 = 1; i2 < mb; ++i2) {
      le[i2] = le[i2 - 1] + l[i2 - 1] << 1;
    }
    var co;
    if (r) {
      co = new u16(1 << mb);
      var rvb = 15 - mb;
      for (i2 = 0; i2 < s; ++i2) {
        if (cd[i2]) {
          var sv = i2 << 4 | cd[i2];
          var r_1 = mb - cd[i2];
          var v = le[cd[i2] - 1]++ << r_1;
          for (var m = v | (1 << r_1) - 1; v <= m; ++v) {
            co[rev[v] >> rvb] = sv;
          }
        }
      }
    } else {
      co = new u16(s);
      for (i2 = 0; i2 < s; ++i2) {
        if (cd[i2]) {
          co[i2] = rev[le[cd[i2] - 1]++] >> 15 - cd[i2];
        }
      }
    }
    return co;
  });
  var flt = new u8(288);
  for (i = 0; i < 144; ++i)
    flt[i] = 8;
  var i;
  for (i = 144; i < 256; ++i)
    flt[i] = 9;
  var i;
  for (i = 256; i < 280; ++i)
    flt[i] = 7;
  var i;
  for (i = 280; i < 288; ++i)
    flt[i] = 8;
  var i;
  var fdt = new u8(32);
  for (i = 0; i < 32; ++i)
    fdt[i] = 5;
  var i;
  var flm = /* @__PURE__ */ hMap(flt, 9, 0);
  var flrm = /* @__PURE__ */ hMap(flt, 9, 1);
  var fdm = /* @__PURE__ */ hMap(fdt, 5, 0);
  var fdrm = /* @__PURE__ */ hMap(fdt, 5, 1);
  var max = function(a) {
    var m = a[0];
    for (var i2 = 1; i2 < a.length; ++i2) {
      if (a[i2] > m)
        m = a[i2];
    }
    return m;
  };
  var bits = function(d, p, m) {
    var o = p / 8 | 0;
    return (d[o] | d[o + 1] << 8) >> (p & 7) & m;
  };
  var bits16 = function(d, p) {
    var o = p / 8 | 0;
    return (d[o] | d[o + 1] << 8 | d[o + 2] << 16) >> (p & 7);
  };
  var shft = function(p) {
    return (p + 7) / 8 | 0;
  };
  var slc = function(v, s, e) {
    if (s == null || s < 0)
      s = 0;
    if (e == null || e > v.length)
      e = v.length;
    return new u8(v.subarray(s, e));
  };
  var ec = [
    "unexpected EOF",
    "invalid block type",
    "invalid length/literal",
    "invalid distance",
    "stream finished",
    "no stream handler",
    ,
    // determined by compression function
    "no callback",
    "invalid UTF-8 data",
    "extra field too long",
    "date not in range 1980-2099",
    "filename too long",
    "stream finishing",
    "invalid zip data"
    // determined by unknown compression method
  ];
  var err = function(ind, msg, nt) {
    var e = new Error(msg || ec[ind]);
    e.code = ind;
    if (Error.captureStackTrace)
      Error.captureStackTrace(e, err);
    if (!nt)
      throw e;
    return e;
  };
  var inflt = function(dat, st, buf, dict) {
    var sl = dat.length, dl = dict ? dict.length : 0;
    if (!sl || st.f && !st.l)
      return buf || new u8(0);
    var noBuf = !buf;
    var resize = noBuf || st.i != 2;
    var noSt = st.i;
    if (noBuf)
      buf = new u8(sl * 3);
    var cbuf = function(l2) {
      var bl = buf.length;
      if (l2 > bl) {
        var nbuf = new u8(Math.max(bl * 2, l2));
        nbuf.set(buf);
        buf = nbuf;
      }
    };
    var final = st.f || 0, pos = st.p || 0, bt = st.b || 0, lm = st.l, dm = st.d, lbt = st.m, dbt = st.n;
    var tbts = sl * 8;
    do {
      if (!lm) {
        final = bits(dat, pos, 1);
        var type = bits(dat, pos + 1, 3);
        pos += 3;
        if (!type) {
          var s = shft(pos) + 4, l = dat[s - 4] | dat[s - 3] << 8, t = s + l;
          if (t > sl) {
            if (noSt)
              err(0);
            break;
          }
          if (resize)
            cbuf(bt + l);
          buf.set(dat.subarray(s, t), bt);
          st.b = bt += l, st.p = pos = t * 8, st.f = final;
          continue;
        } else if (type == 1)
          lm = flrm, dm = fdrm, lbt = 9, dbt = 5;
        else if (type == 2) {
          var hLit = bits(dat, pos, 31) + 257, hcLen = bits(dat, pos + 10, 15) + 4;
          var tl = hLit + bits(dat, pos + 5, 31) + 1;
          pos += 14;
          var ldt = new u8(tl);
          var clt = new u8(19);
          for (var i2 = 0; i2 < hcLen; ++i2) {
            clt[clim[i2]] = bits(dat, pos + i2 * 3, 7);
          }
          pos += hcLen * 3;
          var clb = max(clt), clbmsk = (1 << clb) - 1;
          var clm = hMap(clt, clb, 1);
          for (var i2 = 0; i2 < tl; ) {
            var r = clm[bits(dat, pos, clbmsk)];
            pos += r & 15;
            var s = r >> 4;
            if (s < 16) {
              ldt[i2++] = s;
            } else {
              var c = 0, n = 0;
              if (s == 16)
                n = 3 + bits(dat, pos, 3), pos += 2, c = ldt[i2 - 1];
              else if (s == 17)
                n = 3 + bits(dat, pos, 7), pos += 3;
              else if (s == 18)
                n = 11 + bits(dat, pos, 127), pos += 7;
              while (n--)
                ldt[i2++] = c;
            }
          }
          var lt = ldt.subarray(0, hLit), dt = ldt.subarray(hLit);
          lbt = max(lt);
          dbt = max(dt);
          lm = hMap(lt, lbt, 1);
          dm = hMap(dt, dbt, 1);
        } else
          err(1);
        if (pos > tbts) {
          if (noSt)
            err(0);
          break;
        }
      }
      if (resize)
        cbuf(bt + 131072);
      var lms = (1 << lbt) - 1, dms = (1 << dbt) - 1;
      var lpos = pos;
      for (; ; lpos = pos) {
        var c = lm[bits16(dat, pos) & lms], sym = c >> 4;
        pos += c & 15;
        if (pos > tbts) {
          if (noSt)
            err(0);
          break;
        }
        if (!c)
          err(2);
        if (sym < 256)
          buf[bt++] = sym;
        else if (sym == 256) {
          lpos = pos, lm = null;
          break;
        } else {
          var add = sym - 254;
          if (sym > 264) {
            var i2 = sym - 257, b = fleb[i2];
            add = bits(dat, pos, (1 << b) - 1) + fl[i2];
            pos += b;
          }
          var d = dm[bits16(dat, pos) & dms], dsym = d >> 4;
          if (!d)
            err(3);
          pos += d & 15;
          var dt = fd[dsym];
          if (dsym > 3) {
            var b = fdeb[dsym];
            dt += bits16(dat, pos) & (1 << b) - 1, pos += b;
          }
          if (pos > tbts) {
            if (noSt)
              err(0);
            break;
          }
          if (resize)
            cbuf(bt + 131072);
          var end = bt + add;
          if (bt < dt) {
            var shift = dl - dt, dend = Math.min(dt, end);
            if (shift + bt < 0)
              err(3);
            for (; bt < dend; ++bt)
              buf[bt] = dict[shift + bt];
          }
          for (; bt < end; ++bt)
            buf[bt] = buf[bt - dt];
        }
      }
      st.l = lm, st.p = lpos, st.b = bt, st.f = final;
      if (lm)
        final = 1, st.m = lbt, st.d = dm, st.n = dbt;
    } while (!final);
    return bt != buf.length && noBuf ? slc(buf, 0, bt) : buf.subarray(0, bt);
  };
  var wbits = function(d, p, v) {
    v <<= p & 7;
    var o = p / 8 | 0;
    d[o] |= v;
    d[o + 1] |= v >> 8;
  };
  var wbits16 = function(d, p, v) {
    v <<= p & 7;
    var o = p / 8 | 0;
    d[o] |= v;
    d[o + 1] |= v >> 8;
    d[o + 2] |= v >> 16;
  };
  var hTree = function(d, mb) {
    var t = [];
    for (var i2 = 0; i2 < d.length; ++i2) {
      if (d[i2])
        t.push({ s: i2, f: d[i2] });
    }
    var s = t.length;
    var t2 = t.slice();
    if (!s)
      return { t: et, l: 0 };
    if (s == 1) {
      var v = new u8(t[0].s + 1);
      v[t[0].s] = 1;
      return { t: v, l: 1 };
    }
    t.sort(function(a, b) {
      return a.f - b.f;
    });
    t.push({ s: -1, f: 25001 });
    var l = t[0], r = t[1], i0 = 0, i1 = 1, i22 = 2;
    t[0] = { s: -1, f: l.f + r.f, l, r };
    while (i1 != s - 1) {
      l = t[t[i0].f < t[i22].f ? i0++ : i22++];
      r = t[i0 != i1 && t[i0].f < t[i22].f ? i0++ : i22++];
      t[i1++] = { s: -1, f: l.f + r.f, l, r };
    }
    var maxSym = t2[0].s;
    for (var i2 = 1; i2 < s; ++i2) {
      if (t2[i2].s > maxSym)
        maxSym = t2[i2].s;
    }
    var tr = new u16(maxSym + 1);
    var mbt = ln(t[i1 - 1], tr, 0);
    if (mbt > mb) {
      var i2 = 0, dt = 0;
      var lft = mbt - mb, cst = 1 << lft;
      t2.sort(function(a, b) {
        return tr[b.s] - tr[a.s] || a.f - b.f;
      });
      for (; i2 < s; ++i2) {
        var i2_1 = t2[i2].s;
        if (tr[i2_1] > mb) {
          dt += cst - (1 << mbt - tr[i2_1]);
          tr[i2_1] = mb;
        } else
          break;
      }
      dt >>= lft;
      while (dt > 0) {
        var i2_2 = t2[i2].s;
        if (tr[i2_2] < mb)
          dt -= 1 << mb - tr[i2_2]++ - 1;
        else
          ++i2;
      }
      for (; i2 >= 0 && dt; --i2) {
        var i2_3 = t2[i2].s;
        if (tr[i2_3] == mb) {
          --tr[i2_3];
          ++dt;
        }
      }
      mbt = mb;
    }
    return { t: new u8(tr), l: mbt };
  };
  var ln = function(n, l, d) {
    return n.s == -1 ? Math.max(ln(n.l, l, d + 1), ln(n.r, l, d + 1)) : l[n.s] = d;
  };
  var lc = function(c) {
    var s = c.length;
    while (s && !c[--s])
      ;
    var cl = new u16(++s);
    var cli = 0, cln = c[0], cls = 1;
    var w = function(v) {
      cl[cli++] = v;
    };
    for (var i2 = 1; i2 <= s; ++i2) {
      if (c[i2] == cln && i2 != s)
        ++cls;
      else {
        if (!cln && cls > 2) {
          for (; cls > 138; cls -= 138)
            w(32754);
          if (cls > 2) {
            w(cls > 10 ? cls - 11 << 5 | 28690 : cls - 3 << 5 | 12305);
            cls = 0;
          }
        } else if (cls > 3) {
          w(cln), --cls;
          for (; cls > 6; cls -= 6)
            w(8304);
          if (cls > 2)
            w(cls - 3 << 5 | 8208), cls = 0;
        }
        while (cls--)
          w(cln);
        cls = 1;
        cln = c[i2];
      }
    }
    return { c: cl.subarray(0, cli), n: s };
  };
  var clen = function(cf, cl) {
    var l = 0;
    for (var i2 = 0; i2 < cl.length; ++i2)
      l += cf[i2] * cl[i2];
    return l;
  };
  var wfblk = function(out, pos, dat) {
    var s = dat.length;
    var o = shft(pos + 2);
    out[o] = s & 255;
    out[o + 1] = s >> 8;
    out[o + 2] = out[o] ^ 255;
    out[o + 3] = out[o + 1] ^ 255;
    for (var i2 = 0; i2 < s; ++i2)
      out[o + i2 + 4] = dat[i2];
    return (o + 4 + s) * 8;
  };
  var wblk = function(dat, out, final, syms, lf, df, eb, li, bs, bl, p) {
    wbits(out, p++, final);
    ++lf[256];
    var _a2 = hTree(lf, 15), dlt = _a2.t, mlb = _a2.l;
    var _b2 = hTree(df, 15), ddt = _b2.t, mdb = _b2.l;
    var _c = lc(dlt), lclt = _c.c, nlc = _c.n;
    var _d = lc(ddt), lcdt = _d.c, ndc = _d.n;
    var lcfreq = new u16(19);
    for (var i2 = 0; i2 < lclt.length; ++i2)
      ++lcfreq[lclt[i2] & 31];
    for (var i2 = 0; i2 < lcdt.length; ++i2)
      ++lcfreq[lcdt[i2] & 31];
    var _e = hTree(lcfreq, 7), lct = _e.t, mlcb = _e.l;
    var nlcc = 19;
    for (; nlcc > 4 && !lct[clim[nlcc - 1]]; --nlcc)
      ;
    var flen = bl + 5 << 3;
    var ftlen = clen(lf, flt) + clen(df, fdt) + eb;
    var dtlen = clen(lf, dlt) + clen(df, ddt) + eb + 14 + 3 * nlcc + clen(lcfreq, lct) + 2 * lcfreq[16] + 3 * lcfreq[17] + 7 * lcfreq[18];
    if (bs >= 0 && flen <= ftlen && flen <= dtlen)
      return wfblk(out, p, dat.subarray(bs, bs + bl));
    var lm, ll, dm, dl;
    wbits(out, p, 1 + (dtlen < ftlen)), p += 2;
    if (dtlen < ftlen) {
      lm = hMap(dlt, mlb, 0), ll = dlt, dm = hMap(ddt, mdb, 0), dl = ddt;
      var llm = hMap(lct, mlcb, 0);
      wbits(out, p, nlc - 257);
      wbits(out, p + 5, ndc - 1);
      wbits(out, p + 10, nlcc - 4);
      p += 14;
      for (var i2 = 0; i2 < nlcc; ++i2)
        wbits(out, p + 3 * i2, lct[clim[i2]]);
      p += 3 * nlcc;
      var lcts = [lclt, lcdt];
      for (var it = 0; it < 2; ++it) {
        var clct = lcts[it];
        for (var i2 = 0; i2 < clct.length; ++i2) {
          var len = clct[i2] & 31;
          wbits(out, p, llm[len]), p += lct[len];
          if (len > 15)
            wbits(out, p, clct[i2] >> 5 & 127), p += clct[i2] >> 12;
        }
      }
    } else {
      lm = flm, ll = flt, dm = fdm, dl = fdt;
    }
    for (var i2 = 0; i2 < li; ++i2) {
      var sym = syms[i2];
      if (sym > 255) {
        var len = sym >> 18 & 31;
        wbits16(out, p, lm[len + 257]), p += ll[len + 257];
        if (len > 7)
          wbits(out, p, sym >> 23 & 31), p += fleb[len];
        var dst = sym & 31;
        wbits16(out, p, dm[dst]), p += dl[dst];
        if (dst > 3)
          wbits16(out, p, sym >> 5 & 8191), p += fdeb[dst];
      } else {
        wbits16(out, p, lm[sym]), p += ll[sym];
      }
    }
    wbits16(out, p, lm[256]);
    return p + ll[256];
  };
  var deo = /* @__PURE__ */ new i32([65540, 131080, 131088, 131104, 262176, 1048704, 1048832, 2114560, 2117632]);
  var et = /* @__PURE__ */ new u8(0);
  var dflt = function(dat, lvl, plvl, pre, post2, st) {
    var s = st.z || dat.length;
    var o = new u8(pre + s + 5 * (1 + Math.ceil(s / 7e3)) + post2);
    var w = o.subarray(pre, o.length - post2);
    var lst = st.l;
    var pos = (st.r || 0) & 7;
    if (lvl) {
      if (pos)
        w[0] = st.r >> 3;
      var opt = deo[lvl - 1];
      var n = opt >> 13, c = opt & 8191;
      var msk_1 = (1 << plvl) - 1;
      var prev = st.p || new u16(32768), head = st.h || new u16(msk_1 + 1);
      var bs1_1 = Math.ceil(plvl / 3), bs2_1 = 2 * bs1_1;
      var hsh = function(i3) {
        return (dat[i3] ^ dat[i3 + 1] << bs1_1 ^ dat[i3 + 2] << bs2_1) & msk_1;
      };
      var syms = new i32(25e3);
      var lf = new u16(288), df = new u16(32);
      var lc_1 = 0, eb = 0, i2 = st.i || 0, li = 0, wi = st.w || 0, bs = 0;
      for (; i2 + 2 < s; ++i2) {
        var hv = hsh(i2);
        var imod = i2 & 32767, pimod = head[hv];
        prev[imod] = pimod;
        head[hv] = imod;
        if (wi <= i2) {
          var rem = s - i2;
          if ((lc_1 > 7e3 || li > 24576) && (rem > 423 || !lst)) {
            pos = wblk(dat, w, 0, syms, lf, df, eb, li, bs, i2 - bs, pos);
            li = lc_1 = eb = 0, bs = i2;
            for (var j = 0; j < 286; ++j)
              lf[j] = 0;
            for (var j = 0; j < 30; ++j)
              df[j] = 0;
          }
          var l = 2, d = 0, ch_1 = c, dif = imod - pimod & 32767;
          if (rem > 2 && hv == hsh(i2 - dif)) {
            var maxn = Math.min(n, rem) - 1;
            var maxd = Math.min(32767, i2);
            var ml = Math.min(258, rem);
            while (dif <= maxd && --ch_1 && imod != pimod) {
              if (dat[i2 + l] == dat[i2 + l - dif]) {
                var nl = 0;
                for (; nl < ml && dat[i2 + nl] == dat[i2 + nl - dif]; ++nl)
                  ;
                if (nl > l) {
                  l = nl, d = dif;
                  if (nl > maxn)
                    break;
                  var mmd = Math.min(dif, nl - 2);
                  var md = 0;
                  for (var j = 0; j < mmd; ++j) {
                    var ti = i2 - dif + j & 32767;
                    var pti = prev[ti];
                    var cd = ti - pti & 32767;
                    if (cd > md)
                      md = cd, pimod = ti;
                  }
                }
              }
              imod = pimod, pimod = prev[imod];
              dif += imod - pimod & 32767;
            }
          }
          if (d) {
            syms[li++] = 268435456 | revfl[l] << 18 | revfd[d];
            var lin = revfl[l] & 31, din = revfd[d] & 31;
            eb += fleb[lin] + fdeb[din];
            ++lf[257 + lin];
            ++df[din];
            wi = i2 + l;
            ++lc_1;
          } else {
            syms[li++] = dat[i2];
            ++lf[dat[i2]];
          }
        }
      }
      for (i2 = Math.max(i2, wi); i2 < s; ++i2) {
        syms[li++] = dat[i2];
        ++lf[dat[i2]];
      }
      pos = wblk(dat, w, lst, syms, lf, df, eb, li, bs, i2 - bs, pos);
      if (!lst) {
        st.r = pos & 7 | w[pos / 8 | 0] << 3;
        pos -= 7;
        st.h = head, st.p = prev, st.i = i2, st.w = wi;
      }
    } else {
      for (var i2 = st.w || 0; i2 < s + lst; i2 += 65535) {
        var e = i2 + 65535;
        if (e >= s) {
          w[pos / 8 | 0] = lst;
          e = s;
        }
        pos = wfblk(w, pos + 1, dat.subarray(i2, e));
      }
      st.i = s;
    }
    return slc(o, 0, pre + shft(pos) + post2);
  };
  var crct = /* @__PURE__ */ (function() {
    var t = new Int32Array(256);
    for (var i2 = 0; i2 < 256; ++i2) {
      var c = i2, k = 9;
      while (--k)
        c = (c & 1 && -306674912) ^ c >>> 1;
      t[i2] = c;
    }
    return t;
  })();
  var crc = function() {
    var c = -1;
    return {
      p: function(d) {
        var cr = c;
        for (var i2 = 0; i2 < d.length; ++i2)
          cr = crct[cr & 255 ^ d[i2]] ^ cr >>> 8;
        c = cr;
      },
      d: function() {
        return ~c;
      }
    };
  };
  var dopt = function(dat, opt, pre, post2, st) {
    if (!st) {
      st = { l: 1 };
      if (opt.dictionary) {
        var dict = opt.dictionary.subarray(-32768);
        var newDat = new u8(dict.length + dat.length);
        newDat.set(dict);
        newDat.set(dat, dict.length);
        dat = newDat;
        st.w = dict.length;
      }
    }
    return dflt(dat, opt.level == null ? 6 : opt.level, opt.mem == null ? st.l ? Math.ceil(Math.max(8, Math.min(13, Math.log(dat.length))) * 1.5) : 20 : 12 + opt.mem, pre, post2, st);
  };
  var mrg = function(a, b) {
    var o = {};
    for (var k in a)
      o[k] = a[k];
    for (var k in b)
      o[k] = b[k];
    return o;
  };
  var b2 = function(d, b) {
    return d[b] | d[b + 1] << 8;
  };
  var b4 = function(d, b) {
    return (d[b] | d[b + 1] << 8 | d[b + 2] << 16 | d[b + 3] << 24) >>> 0;
  };
  var b8 = function(d, b) {
    return b4(d, b) + b4(d, b + 4) * 4294967296;
  };
  var wbytes = function(d, b, v) {
    for (; v; ++b)
      d[b] = v, v >>>= 8;
  };
  function deflateSync(data, opts) {
    return dopt(data, opts || {}, 0, 0);
  }
  function inflateSync(data, opts) {
    return inflt(data, { i: 2 }, opts && opts.out, opts && opts.dictionary);
  }
  var fltn = function(d, p, t, o) {
    for (var k in d) {
      var val = d[k], n = p + k, op = o;
      if (Array.isArray(val))
        op = mrg(o, val[1]), val = val[0];
      if (ArrayBuffer.isView(val))
        t[n] = [val, op];
      else {
        t[n += "/"] = [new u8(0), op];
        fltn(val, n, t, o);
      }
    }
  };
  var te = typeof TextEncoder != "undefined" && /* @__PURE__ */ new TextEncoder();
  var td = typeof TextDecoder != "undefined" && /* @__PURE__ */ new TextDecoder();
  var tds = 0;
  try {
    td.decode(et, { stream: true });
    tds = 1;
  } catch (e) {
  }
  var dutf8 = function(d) {
    for (var r = "", i2 = 0; ; ) {
      var c = d[i2++];
      var eb = (c > 127) + (c > 223) + (c > 239);
      if (i2 + eb > d.length)
        return { s: r, r: slc(d, i2 - 1) };
      if (!eb)
        r += String.fromCharCode(c);
      else if (eb == 3) {
        c = ((c & 15) << 18 | (d[i2++] & 63) << 12 | (d[i2++] & 63) << 6 | d[i2++] & 63) - 65536, r += String.fromCharCode(55296 | c >> 10, 56320 | c & 1023);
      } else if (eb & 1)
        r += String.fromCharCode((c & 31) << 6 | d[i2++] & 63);
      else
        r += String.fromCharCode((c & 15) << 12 | (d[i2++] & 63) << 6 | d[i2++] & 63);
    }
  };
  function strToU8(str, latin1) {
    if (latin1) {
      var ar_1 = new u8(str.length);
      for (var i2 = 0; i2 < str.length; ++i2)
        ar_1[i2] = str.charCodeAt(i2);
      return ar_1;
    }
    if (te)
      return te.encode(str);
    var l = str.length;
    var ar = new u8(str.length + (str.length >> 1));
    var ai = 0;
    var w = function(v) {
      ar[ai++] = v;
    };
    for (var i2 = 0; i2 < l; ++i2) {
      if (ai + 5 > ar.length) {
        var n = new u8(ai + 8 + (l - i2 << 1));
        n.set(ar);
        ar = n;
      }
      var c = str.charCodeAt(i2);
      if (c < 128 || latin1)
        w(c);
      else if (c < 2048)
        w(192 | c >> 6), w(128 | c & 63);
      else if (c > 55295 && c < 57344)
        c = 65536 + (c & 1023 << 10) | str.charCodeAt(++i2) & 1023, w(240 | c >> 18), w(128 | c >> 12 & 63), w(128 | c >> 6 & 63), w(128 | c & 63);
      else
        w(224 | c >> 12), w(128 | c >> 6 & 63), w(128 | c & 63);
    }
    return slc(ar, 0, ai);
  }
  function strFromU8(dat, latin1) {
    if (latin1) {
      var r = "";
      for (var i2 = 0; i2 < dat.length; i2 += 16384)
        r += String.fromCharCode.apply(null, dat.subarray(i2, i2 + 16384));
      return r;
    } else if (td) {
      return td.decode(dat);
    } else {
      var _a2 = dutf8(dat), s = _a2.s, r = _a2.r;
      if (r.length)
        err(8);
      return s;
    }
  }
  var slzh = function(d, b) {
    return b + 30 + b2(d, b + 26) + b2(d, b + 28);
  };
  var zh = function(d, b, z) {
    var fnl = b2(d, b + 28), efl = b2(d, b + 30), fn = strFromU8(d.subarray(b + 46, b + 46 + fnl), !(b2(d, b + 8) & 2048)), es = b + 46 + fnl;
    var _a2 = z64hs(d, es, efl, z, b4(d, b + 20), b4(d, b + 24), b4(d, b + 42)), sc = _a2[0], su = _a2[1], off = _a2[2];
    return [b2(d, b + 10), sc, su, fn, es + efl + b2(d, b + 32), off];
  };
  var z64hs = function(d, b, l, z, sc, su, off) {
    var nsc = sc == 4294967295, nsu = su == 4294967295, noff = off == 4294967295, e = b + l;
    var nf = nsc + nsu + noff;
    if (z && nf) {
      for (; b + 4 < e; b += 4 + b2(d, b + 2)) {
        if (b2(d, b) == 1) {
          return [
            nsc ? b8(d, b + 4 + 8 * nsu) : sc,
            nsu ? b8(d, b + 4) : su,
            noff ? b8(d, b + 4 + 8 * (nsu + nsc)) : off,
            1
          ];
        }
      }
      if (z < 2)
        err(13);
    }
    return [sc, su, off, 0];
  };
  var exfl = function(ex) {
    var le = 0;
    if (ex) {
      for (var k in ex) {
        var l = ex[k].length;
        if (l > 65535)
          err(9);
        le += l + 4;
      }
    }
    return le;
  };
  var wzh = function(d, b, f, fn, u, c, ce, co) {
    var fl2 = fn.length, ex = f.extra, col = co && co.length;
    var exl = exfl(ex);
    wbytes(d, b, ce != null ? 33639248 : 67324752), b += 4;
    if (ce != null)
      d[b++] = 20, d[b++] = f.os;
    d[b] = 20, b += 2;
    d[b++] = f.flag << 1 | (c < 0 && 8), d[b++] = u && 8;
    d[b++] = f.compression & 255, d[b++] = f.compression >> 8;
    var dt = new Date(f.mtime == null ? Date.now() : f.mtime), y = dt.getFullYear() - 1980;
    if (y < 0 || y > 119)
      err(10);
    wbytes(d, b, y << 25 | dt.getMonth() + 1 << 21 | dt.getDate() << 16 | dt.getHours() << 11 | dt.getMinutes() << 5 | dt.getSeconds() >> 1), b += 4;
    if (c != -1) {
      wbytes(d, b, f.crc);
      wbytes(d, b + 4, c < 0 ? -c - 2 : c);
      wbytes(d, b + 8, f.size);
    }
    wbytes(d, b + 12, fl2);
    wbytes(d, b + 14, exl), b += 16;
    if (ce != null) {
      wbytes(d, b, col);
      wbytes(d, b + 6, f.attrs);
      wbytes(d, b + 10, ce), b += 14;
    }
    d.set(fn, b);
    b += fl2;
    if (exl) {
      for (var k in ex) {
        var exf = ex[k], l = exf.length;
        wbytes(d, b, +k);
        wbytes(d, b + 2, l);
        d.set(exf, b + 4), b += 4 + l;
      }
    }
    if (col)
      d.set(co, b), b += col;
    return b;
  };
  var wzf = function(o, b, c, d, e) {
    wbytes(o, b, 101010256);
    wbytes(o, b + 8, c);
    wbytes(o, b + 10, c);
    wbytes(o, b + 12, d);
    wbytes(o, b + 16, e);
  };
  function zipSync(data, opts) {
    if (!opts)
      opts = {};
    var r = {};
    var files = [];
    fltn(data, "", r, opts);
    var o = 0;
    var tot = 0;
    for (var fn in r) {
      var _a2 = r[fn], file = _a2[0], p = _a2[1];
      var compression = p.level == 0 ? 0 : 8;
      var f = strToU8(fn), s = f.length;
      var com = p.comment, m = com && strToU8(com), ms = m && m.length;
      var exl = exfl(p.extra);
      if (s > 65535)
        err(11);
      var d = compression ? deflateSync(file, p) : file, l = d.length;
      var c = crc();
      c.p(file);
      files.push(mrg(p, {
        size: file.length,
        crc: c.d(),
        c: d,
        f,
        m,
        u: s != fn.length || m && com.length != ms,
        o,
        compression
      }));
      o += 30 + s + exl + l;
      tot += 76 + 2 * (s + exl) + (ms || 0) + l;
    }
    var out = new u8(tot + 22), oe = o, cdl = tot - o;
    for (var i2 = 0; i2 < files.length; ++i2) {
      var f = files[i2];
      wzh(out, f.o, f, f.f, f.u, f.c.length);
      var badd = 30 + f.f.length + exfl(f.extra);
      out.set(f.c, f.o + badd);
      wzh(out, o, f, f.f, f.u, f.c.length, f.o, f.m), o += 16 + badd + (f.m ? f.m.length : 0);
    }
    wzf(out, o, files.length, cdl, oe);
    return out;
  }
  function unzipSync(data, opts) {
    var files = {};
    var e = data.length - 22;
    for (; b4(data, e) != 101010256; --e) {
      if (!e || data.length - e > 65558)
        err(13);
    }
    ;
    var c = b2(data, e + 8);
    if (!c)
      return {};
    var o = b4(data, e + 16);
    var z = b4(data, e - 20) == 117853008;
    if (z) {
      var ze = b4(data, e - 12);
      z = b4(data, ze) == 101075792;
      if (z) {
        c = b4(data, ze + 32);
        o = b4(data, ze + 48);
      }
    }
    var fltr = opts && opts.filter;
    for (var i2 = 0; i2 < c; ++i2) {
      var _a2 = zh(data, o, z), c_2 = _a2[0], sc = _a2[1], su = _a2[2], fn = _a2[3], no = _a2[4], off = _a2[5], b = slzh(data, off);
      o = no;
      if (!fltr || fltr({
        name: fn,
        size: sc,
        originalSize: su,
        compression: c_2
      })) {
        if (!c_2)
          files[fn] = slc(data, b, b + sc);
        else if (c_2 == 8)
          files[fn] = inflateSync(data.subarray(b, b + sc), { out: new u8(su) });
        else
          err(14, "unknown compression type " + c_2);
      }
    }
    return files;
  }

  // src/archive/paths.ts
  var RESERVED = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\..*)?$/i;
  var UNSAFE_CHARACTERS = /[\p{Cc}\p{Cf}\p{Cs}<>:"/\\|?#*]/gu;
  var MAX_SEGMENT_LENGTH = 100;
  var MAX_PATH_LENGTH = 240;
  var characters = (value) => Array.from(value);
  var truncate = (value, length) => characters(value).slice(0, length).join("");
  var digest = (value) => {
    let hash = 2166136261;
    for (const character of value) {
      hash ^= character.codePointAt(0) ?? 0;
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
  };
  function safeSegment(input) {
    if (typeof input !== "string") throw new TypeError("Invalid archive segment");
    let value = input.normalize("NFC").replace(UNSAFE_CHARACTERS, "_").replace(/^\.+$/, "_").replace(/[. ]+$/g, "").trim();
    if (!value) value = "untitled";
    if (RESERVED.test(value)) value = `_${value}`;
    return truncate(value, MAX_SEGMENT_LENGTH);
  }
  function addDigestToLastSegment(value, pathDigest) {
    const dot = value.lastIndexOf(".");
    const hasExtension = dot > 0 && value.length - dot <= 16;
    const extension = hasExtension ? value.slice(dot) : "";
    const stem = hasExtension ? value.slice(0, dot) : value;
    const suffix = `~${pathDigest}`;
    return `${truncate(stem, MAX_SEGMENT_LENGTH - suffix.length - extension.length)}${suffix}${extension}`;
  }
  function safeArchivePath(...segments) {
    const normalized = (segments.length > 0 ? segments : [""]).map(safeSegment);
    const direct = normalized.join("/");
    if (direct.length <= MAX_PATH_LENGTH) return direct;
    const pathDigest = digest(direct);
    const last = addDigestToLastSegment(normalized.at(-1), pathDigest);
    if (normalized.length === 1) return truncate(last, MAX_PATH_LENGTH);
    const bounded = [normalized[0]];
    for (const segment of normalized.slice(1, -1)) {
      if ([...bounded, segment, last].join("/").length > MAX_PATH_LENGTH) break;
      bounded.push(segment);
    }
    if (bounded.length < normalized.length - 1) {
      const omission = `_~${pathDigest}`;
      if ([...bounded, omission, last].join("/").length <= MAX_PATH_LENGTH) {
        bounded.push(omission);
      }
    }
    bounded.push(last);
    const path = bounded.join("/");
    if (path.length > MAX_PATH_LENGTH) {
      throw new TypeError("Unsafe archive path");
    }
    return path;
  }
  function canonicalArchivePath(path) {
    if (typeof path !== "string") throw new TypeError("Invalid archive path");
    return path.normalize("NFKC").toLowerCase().replace(/\u03c2/g, "\u03C3").replace(/\u00df/g, "ss");
  }
  function isCanonicalArchivePath(path) {
    if (typeof path !== "string" || path.length === 0 || path.length > MAX_PATH_LENGTH || path !== path.normalize("NFC")) {
      return false;
    }
    const segments = path.split("/");
    if (segments.some(
      (segment) => segment.length === 0 || characters(segment).length > MAX_SEGMENT_LENGTH
    )) {
      return false;
    }
    try {
      return safeArchivePath(...segments) === path;
    } catch {
      return false;
    }
  }
  function assertArchivePathSet(resources) {
    const paths = /* @__PURE__ */ new Set();
    for (const resource of resources) {
      const { kind, archivePath } = resource;
      if (kind === "external" || kind === "unsupported") {
        if (archivePath !== null) throw new TypeError("Invalid archive path set");
        continue;
      }
      if (!isCanonicalArchivePath(archivePath) || kind === "file" && !archivePath.startsWith("files/") || kind === "page" && !archivePath.startsWith("pages/")) {
        throw new TypeError("Invalid archive path set");
      }
      const canonical = canonicalArchivePath(archivePath);
      if (paths.has(canonical)) throw new TypeError("Conflicting archive path");
      paths.add(canonical);
    }
    for (const path of paths) {
      let separator = path.indexOf("/");
      while (separator !== -1) {
        if (paths.has(path.slice(0, separator))) {
          throw new TypeError("Conflicting archive path");
        }
        separator = path.indexOf("/", separator + 1);
      }
    }
  }

  // src/shared/constants.ts
  var CANVAS_ORIGIN = "https://frankfurtschool.instructure.com";
  var CANVAS_PAGE_JSON_MAX_BYTES = 5 * 1024 * 1024;
  var MAX_ARCHIVED_PAGE_BYTES = CANVAS_PAGE_JSON_MAX_BYTES * 8 + 64 * 1024;
  var MAX_ARCHIVE_BYTES = 262144e3;
  var CLASSIC_ZIP_ENTRY_LIMIT = 65535;
  var COURSE_CORE_ENTRY_COUNT = 7;
  var COMBINED_CORE_ENTRY_COUNT = 4;
  var MAX_ARCHIVE_RESOURCES = CLASSIC_ZIP_ENTRY_LIMIT - COURSE_CORE_ENTRY_COUNT;
  var MAX_CONCURRENCY = 2;
  var MAX_RETRIES = 2;
  var EXTENSION_CHANNEL = "gradpack/extension/v1";
  var RUNNER_CHANNEL = "gradpack/runner/v1";

  // src/archive/manifest.ts
  var GRADPACK_VERSION = "0.1.0-alpha.7";
  var CANVAS_HOST = "frankfurtschool.instructure.com";
  var CANVAS_ORIGIN2 = `https://${CANVAS_HOST}`;
  var MAX_ARCHIVE_RESOURCES2 = MAX_ARCHIVE_RESOURCES;
  var MAX_ZIP_PAYLOAD_ENTRIES = MAX_ARCHIVE_RESOURCES;
  var MAX_TEXT_LENGTH = 4096;
  var CANONICAL_ISO = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/u;
  var CONTROL = /[\p{Cc}\p{Cf}\p{Cs}]/u;
  var ENCODED_CONTROL = /%(?:0[0-9a-f]|1[0-9a-f]|7f)/iu;
  var FAILURE_CATEGORIES = /* @__PURE__ */ new Set([
    "access-denied",
    "individual-size-limit",
    "network-exhausted",
    "not-found",
    "page-too-large",
    "transient-exhausted"
  ]);
  var RESOURCE_KINDS = /* @__PURE__ */ new Set([
    "file",
    "page",
    "external",
    "unsupported"
  ]);
  var OUTCOME_STATUSES = /* @__PURE__ */ new Set([
    "success",
    "failed",
    "unavailable",
    "unsupported",
    "external"
  ]);
  var ArchiveSafetyError = class extends TypeError {
    name = "ArchiveSafetyError";
  };
  var isPlainRecord = (value) => {
    if (typeof value !== "object" || value === null || Array.isArray(value)) {
      return false;
    }
    let prototype;
    try {
      prototype = Object.getPrototypeOf(value);
    } catch {
      return false;
    }
    return prototype === Object.prototype || prototype === null;
  };
  var ownKeys = (value) => {
    try {
      return Reflect.ownKeys(value);
    } catch {
      throw new TypeError("Invalid archive data");
    }
  };
  var exactRecord = (value, expectedKeys) => {
    if (!isPlainRecord(value)) throw new TypeError("Invalid archive data");
    const keys = ownKeys(value);
    if (keys.length !== expectedKeys.length || keys.some((key) => typeof key !== "string" || !expectedKeys.includes(key))) {
      throw new TypeError("Invalid archive data");
    }
    const snapshot = /* @__PURE__ */ Object.create(null);
    for (const key of expectedKeys) {
      let descriptor;
      try {
        descriptor = Object.getOwnPropertyDescriptor(value, key);
      } catch {
        throw new TypeError("Invalid archive data");
      }
      if (!descriptor || !("value" in descriptor)) {
        throw new TypeError("Invalid archive data");
      }
      snapshot[key] = descriptor.value;
    }
    return snapshot;
  };
  var valueOf = (record2, key) => {
    return record2[key];
  };
  var exactArray = (value) => {
    if (!Array.isArray(value) || Object.getPrototypeOf(value) !== Array.prototype) {
      throw new TypeError("Invalid archive data");
    }
    const keys = ownKeys(value);
    if (keys.some(
      (key) => typeof key !== "string" || key !== "length" && !/^(?:0|[1-9]\d*)$/u.test(key)
    )) {
      throw new TypeError("Invalid archive data");
    }
    const lengthDescriptor = Object.getOwnPropertyDescriptor(value, "length");
    if (!lengthDescriptor || !("value" in lengthDescriptor)) {
      throw new TypeError("Invalid archive data");
    }
    const length = lengthDescriptor.value;
    if (typeof length !== "number" || !Number.isSafeInteger(length) || length < 0) {
      throw new TypeError("Invalid archive data");
    }
    const output = [];
    for (let index = 0; index < length; index += 1) {
      const descriptor = Object.getOwnPropertyDescriptor(value, String(index));
      if (!descriptor || !("value" in descriptor)) {
        throw new TypeError("Invalid archive data");
      }
      output.push(descriptor.value);
    }
    return output;
  };
  var text = (value, allowEmpty = false) => {
    if (typeof value !== "string" || value.length > MAX_TEXT_LENGTH || !allowEmpty && value.length === 0 || CONTROL.test(value)) {
      throw new TypeError("Invalid archive data");
    }
    return value;
  };
  var safeInteger = (value, minimum = 0) => {
    if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum) {
      throw new TypeError("Invalid archive data");
    }
    return value;
  };
  var nullableBytes = (value) => value === null ? null : safeInteger(value);
  var canonicalTimestamp = (value) => {
    if (typeof value !== "string" || !CANONICAL_ISO.test(value)) {
      throw new TypeError("Invalid archive timestamp");
    }
    try {
      if (new Date(value).toISOString() !== value) {
        throw new TypeError("Invalid archive timestamp");
      }
    } catch {
      throw new TypeError("Invalid archive timestamp");
    }
    return value;
  };
  var validateSourceUrl = (value, kind, sourceId, courseId, advertisedBytes) => {
    if (value === null) {
      if (kind === "file" || kind === "external") {
        throw new TypeError("Invalid archive data");
      }
      return null;
    }
    if (typeof value !== "string" || value !== value.trim() || CONTROL.test(value) || ENCODED_CONTROL.test(value)) {
      throw new TypeError("Invalid archive data");
    }
    let url;
    try {
      url = new URL(value);
    } catch {
      throw new TypeError("Invalid archive data");
    }
    if (url.protocol !== "https:" || url.username !== "" || url.password !== "" || kind === "file" && url.hash !== "") {
      throw new TypeError("Invalid archive data");
    }
    if (kind === "file") {
      if (advertisedBytes === null && (!/^[1-9]\d*$/u.test(sourceId) || !Number.isSafeInteger(Number(sourceId)))) {
        throw new TypeError("Invalid archive data");
      }
      const expectedPath = advertisedBytes === null ? `/courses/${courseId}/files/${sourceId}/download` : `/files/${sourceId}/download`;
      if (url.origin !== CANVAS_ORIGIN2 || url.pathname !== expectedPath || advertisedBytes === null && url.search !== "") {
        throw new TypeError("Invalid archive data");
      }
    }
    if (kind === "page" || kind === "unsupported") {
      throw new TypeError("Invalid archive data");
    }
    return value;
  };
  var resourceKeys = [
    "key",
    "kind",
    "title",
    "sourceId",
    "archivePath",
    "advertisedBytes",
    "sourceUrl"
  ];
  var validateResource = (value, courseId) => {
    const record2 = exactRecord(value, resourceKeys);
    const key = text(valueOf(record2, "key"));
    const rawKind = valueOf(record2, "kind");
    if (typeof rawKind !== "string" || !RESOURCE_KINDS.has(rawKind)) {
      throw new TypeError("Invalid archive data");
    }
    const kind = rawKind;
    const title = text(valueOf(record2, "title"), true);
    const sourceId = text(valueOf(record2, "sourceId"));
    const rawArchivePath = valueOf(record2, "archivePath");
    const archivePath = rawArchivePath === null ? null : isCanonicalArchivePath(rawArchivePath) ? rawArchivePath : (() => {
      throw new TypeError("Invalid archive data");
    })();
    const advertisedBytes = nullableBytes(valueOf(record2, "advertisedBytes"));
    const sourceUrl = validateSourceUrl(
      valueOf(record2, "sourceUrl"),
      kind,
      sourceId,
      courseId,
      advertisedBytes
    );
    if (kind === "file" && (archivePath === null || !archivePath.startsWith("files/")) || kind === "page" && (archivePath === null || !archivePath.startsWith("pages/") || advertisedBytes !== 0) || (kind === "external" || kind === "unsupported") && (archivePath !== null || advertisedBytes !== 0)) {
      throw new TypeError("Invalid archive data");
    }
    return {
      key,
      kind,
      title,
      sourceId,
      archivePath,
      advertisedBytes,
      sourceUrl
    };
  };
  var outcomeKeys = [
    ...resourceKeys,
    "status",
    "actualBytes",
    "failureCategory"
  ];
  var validateOutcome = (value, courseId) => {
    const record2 = exactRecord(value, outcomeKeys);
    const resource = validateResource(
      Object.fromEntries(resourceKeys.map((key) => [key, valueOf(record2, key)])),
      courseId
    );
    const rawStatus = valueOf(record2, "status");
    if (typeof rawStatus !== "string" || !OUTCOME_STATUSES.has(rawStatus)) {
      throw new TypeError("Invalid archive data");
    }
    const status2 = rawStatus;
    const actualBytes = nullableBytes(valueOf(record2, "actualBytes"));
    const rawFailure = valueOf(record2, "failureCategory");
    const failureCategory = rawFailure === null ? null : typeof rawFailure === "string" && FAILURE_CATEGORIES.has(rawFailure) ? rawFailure : (() => {
      throw new TypeError("Invalid archive data");
    })();
    if (status2 === "success" && (resource.kind !== "file" && resource.kind !== "page" || resource.archivePath === null || actualBytes === null || failureCategory !== null) || (status2 === "failed" || status2 === "unavailable") && (resource.kind !== "file" && resource.kind !== "page" || actualBytes !== null || failureCategory === null) || status2 === "external" && (resource.kind !== "external" || actualBytes !== 0 || failureCategory !== null) || status2 === "unsupported" && (resource.kind !== "unsupported" || actualBytes !== 0 || failureCategory !== null) || failureCategory === "individual-size-limit" && resource.kind !== "file" || failureCategory === "page-too-large" && resource.kind !== "page") {
      throw new TypeError("Invalid archive data");
    }
    return { ...resource, status: status2, actualBytes, failureCategory };
  };
  var addSafe = (left, right) => {
    if (right > Number.MAX_SAFE_INTEGER - left) {
      throw new TypeError("Archive byte total overflow");
    }
    return left + right;
  };
  var validateCourse = (value) => {
    const record2 = exactRecord(value, [
      "id",
      "name",
      "courseCode",
      "workflowState",
      "concluded"
    ]);
    const concluded = valueOf(record2, "concluded");
    if (typeof concluded !== "boolean")
      throw new TypeError("Invalid archive data");
    return {
      id: safeInteger(valueOf(record2, "id"), 1),
      name: text(valueOf(record2, "name"), true),
      courseCode: text(valueOf(record2, "courseCode"), true),
      workflowState: text(valueOf(record2, "workflowState"), true),
      concluded
    };
  };
  var validateModules = (value) => exactArray(value).map((rawModule) => {
    const module = exactRecord(rawModule, ["id", "name", "position", "items"]);
    const items = exactArray(valueOf(module, "items")).map((rawItem) => {
      const item = exactRecord(rawItem, [
        "id",
        "title",
        "position",
        "indent",
        "resourceKey",
        "type"
      ]);
      const resourceKey = valueOf(item, "resourceKey");
      if (resourceKey !== null && typeof resourceKey !== "string") {
        throw new TypeError("Invalid archive data");
      }
      return {
        id: safeInteger(valueOf(item, "id"), 1),
        title: text(valueOf(item, "title"), true),
        position: safeInteger(valueOf(item, "position")),
        indent: (() => {
          const indent = safeInteger(valueOf(item, "indent"));
          if (indent > 5) throw new TypeError("Invalid archive data");
          return indent;
        })(),
        resourceKey: resourceKey === null ? null : text(resourceKey),
        type: text(valueOf(item, "type"), true)
      };
    });
    return {
      id: safeInteger(valueOf(module, "id"), 1),
      name: text(valueOf(module, "name"), true),
      position: safeInteger(valueOf(module, "position")),
      items
    };
  });
  var moduleDiscovery = (value) => {
    if (value !== "available" && value !== "disabled") {
      throw new TypeError("Invalid archive data");
    }
    return value;
  };
  var validatePlan = (value) => {
    const record2 = exactRecord(value, [
      "course",
      "moduleDiscovery",
      "modules",
      "resources",
      "folderPathFallbackKeys",
      "advertisedBytes"
    ]);
    const rawResources = exactArray(valueOf(record2, "resources"));
    if (rawResources.length > MAX_ARCHIVE_RESOURCES2) {
      throw new ArchiveSafetyError("Archive resource limit exceeded");
    }
    const course = validateCourse(valueOf(record2, "course"));
    const resources = rawResources.map(
      (resource) => validateResource(resource, course.id)
    );
    const keys = /* @__PURE__ */ new Set();
    let advertisedBytes = 0;
    for (const resource of resources) {
      if (keys.has(resource.key))
        throw new TypeError("Duplicate planned resource");
      keys.add(resource.key);
      advertisedBytes = addSafe(advertisedBytes, resource.advertisedBytes ?? 0);
    }
    assertArchivePathSet(resources);
    const folderPathFallbackKeys = exactArray(
      valueOf(record2, "folderPathFallbackKeys")
    ).map((key) => text(key));
    if (new Set(folderPathFallbackKeys).size !== folderPathFallbackKeys.length) {
      throw new TypeError("Invalid folder fallback keys");
    }
    for (const key of folderPathFallbackKeys) {
      const resource = resources.find((candidate) => candidate.key === key);
      if (resource?.kind !== "file" || resource.archivePath === null || !resource.archivePath.startsWith("files/unfiled/")) {
        throw new TypeError("Invalid folder fallback keys");
      }
    }
    const declared = safeInteger(valueOf(record2, "advertisedBytes"));
    if (declared !== advertisedBytes) {
      throw new TypeError("Invalid advertised byte total");
    }
    const modules = validateModules(valueOf(record2, "modules"));
    const discovery = moduleDiscovery(valueOf(record2, "moduleDiscovery"));
    if (discovery === "disabled" && modules.length !== 0) {
      throw new TypeError("Disabled module discovery cannot include modules");
    }
    for (const module of modules) {
      for (const item of module.items) {
        if (item.resourceKey !== null && !keys.has(item.resourceKey)) {
          throw new TypeError("Unknown module resource");
        }
      }
    }
    return {
      course,
      moduleDiscovery: discovery,
      modules,
      resources,
      folderPathFallbackKeys,
      advertisedBytes: declared
    };
  };
  var defaultPartPlan = (plan) => ({
    index: 1,
    total: 1,
    resourceKeys: plan.resources.map(({ key }) => key),
    resourceParts: plan.resources.map(({ key }) => ({
      resourceKey: key,
      partIndex: 1
    }))
  });
  var validatePartPlan = (value, plan) => {
    const record2 = exactRecord(value, [
      "index",
      "total",
      "resourceKeys",
      "resourceParts"
    ]);
    const index = safeInteger(valueOf(record2, "index"), 1);
    const total = safeInteger(valueOf(record2, "total"), 1);
    if (index > total) throw new TypeError("Invalid archive part");
    const resourceKeys2 = exactArray(valueOf(record2, "resourceKeys")).map(
      (key) => text(key)
    );
    const resourceParts = exactArray(valueOf(record2, "resourceParts")).map(
      (assignment) => {
        const assignmentRecord = exactRecord(assignment, [
          "resourceKey",
          "partIndex"
        ]);
        const partIndex = safeInteger(valueOf(assignmentRecord, "partIndex"), 1);
        if (partIndex > total) throw new TypeError("Invalid archive part");
        return {
          resourceKey: text(valueOf(assignmentRecord, "resourceKey")),
          partIndex
        };
      }
    );
    if (resourceParts.length !== plan.resources.length || resourceParts.some(
      (assignment, assignmentIndex) => assignment.resourceKey !== plan.resources[assignmentIndex]?.key
    )) {
      throw new TypeError("Invalid archive part assignments");
    }
    const expectedKeys = resourceParts.filter((assignment) => assignment.partIndex === index).map((assignment) => assignment.resourceKey);
    if (resourceKeys2.length !== expectedKeys.length || resourceKeys2.some((key, keyIndex) => key !== expectedKeys[keyIndex])) {
      throw new TypeError("Invalid archive part resources");
    }
    if (plan.resources.length > 0 && Array.from({ length: total }, (_, partIndex) => partIndex + 1).some(
      (partIndex) => !resourceParts.some((assignment) => assignment.partIndex === partIndex)
    )) {
      throw new TypeError("Empty archive part assignment");
    }
    resourceParts.forEach(Object.freeze);
    Object.freeze(resourceKeys2);
    Object.freeze(resourceParts);
    return Object.freeze({ index, total, resourceKeys: resourceKeys2, resourceParts });
  };
  var sameResource = (planned, outcome) => planned.key === outcome.key && planned.kind === outcome.kind && planned.title === outcome.title && planned.sourceId === outcome.sourceId && planned.archivePath === outcome.archivePath && planned.advertisedBytes === outcome.advertisedBytes && planned.sourceUrl === outcome.sourceUrl;
  var freezePlan = (plan) => {
    Object.freeze(plan.course);
    for (const module of plan.modules) {
      for (const item of module.items) Object.freeze(item);
      Object.freeze(module.items);
      Object.freeze(module);
    }
    Object.freeze(plan.modules);
    for (const resource of plan.resources) Object.freeze(resource);
    Object.freeze(plan.resources);
    Object.freeze(plan.folderPathFallbackKeys);
    return Object.freeze(plan);
  };
  var freezeOutcomes = (outcomes) => {
    for (const outcome of outcomes) Object.freeze(outcome);
    return Object.freeze(outcomes);
  };
  var freezeManifest = (manifest) => {
    for (const resource of manifest.resources) Object.freeze(resource);
    for (const resource of manifest.resourceCatalog) Object.freeze(resource);
    Object.freeze(manifest.resources);
    Object.freeze(manifest.resourceCatalog);
    Object.freeze(manifest.totals);
    Object.freeze(manifest.courseTotals);
    Object.freeze(manifest.part);
    Object.freeze(manifest.course);
    return Object.freeze(manifest);
  };
  function snapshotArchiveData(plan, outcomes, createdAt, partPlan) {
    const validatedPlan = validatePlan(plan);
    const validatedPartPlan = validatePartPlan(
      partPlan ?? defaultPartPlan(validatedPlan),
      validatedPlan
    );
    const rawOutcomes = exactArray(outcomes);
    if (rawOutcomes.length > MAX_ARCHIVE_RESOURCES2) {
      throw new ArchiveSafetyError("Archive resource limit exceeded");
    }
    const validatedOutcomes = rawOutcomes.map(
      (outcome) => validateOutcome(outcome, validatedPlan.course.id)
    );
    if (validatedOutcomes.length !== validatedPartPlan.resourceKeys.length) {
      throw new TypeError("Incomplete resource outcomes");
    }
    const byKey = /* @__PURE__ */ new Map();
    for (const outcome of validatedOutcomes) {
      if (byKey.has(outcome.key))
        throw new TypeError("Duplicate resource outcome");
      byKey.set(outcome.key, outcome);
    }
    const resourcesByKey = new Map(
      validatedPlan.resources.map((resource) => [resource.key, resource])
    );
    const orderedOutcomes = validatedPartPlan.resourceKeys.map((key) => {
      const planned = resourcesByKey.get(key);
      const outcome = byKey.get(key);
      if (!planned || !outcome || !sameResource(planned, outcome)) {
        throw new TypeError("Mismatched resource outcome");
      }
      return outcome;
    });
    const snapshot = {
      plan: freezePlan(validatedPlan),
      partPlan: validatedPartPlan,
      outcomes: freezeOutcomes(orderedOutcomes),
      createdAt: canonicalTimestamp(createdAt)
    };
    return Object.freeze(snapshot);
  }
  function buildManifestFromSnapshot(snapshot) {
    const validatedPlan = snapshot.plan;
    const validatedPartPlan = snapshot.partPlan;
    const validatedOutcomes = snapshot.outcomes;
    const totals = {
      success: 0,
      failed: 0,
      unavailable: 0,
      unsupported: 0,
      external: 0,
      advertisedBytes: 0,
      archivedBytes: 0
    };
    const resources = validatedOutcomes.map((outcome) => {
      totals[outcome.status] += 1;
      totals.advertisedBytes = addSafe(
        totals.advertisedBytes,
        outcome.advertisedBytes ?? 0
      );
      if (outcome.status === "success") {
        totals.archivedBytes = addSafe(
          totals.archivedBytes,
          outcome.actualBytes
        );
      }
      const { key, kind, title, sourceId, archivePath, advertisedBytes } = outcome;
      return {
        key,
        kind,
        title,
        sourceId,
        archivePath,
        advertisedBytes,
        status: outcome.status,
        actualBytes: outcome.actualBytes,
        failureCategory: outcome.failureCategory
      };
    });
    const partByKey = new Map(
      validatedPartPlan.resourceParts.map(({ resourceKey, partIndex }) => [
        resourceKey,
        partIndex
      ])
    );
    const fallbackKeys = new Set(validatedPlan.folderPathFallbackKeys);
    const resourceCatalog = validatedPlan.resources.map((resource) => ({
      key: resource.key,
      kind: resource.kind,
      title: resource.title,
      partIndex: partByKey.get(resource.key),
      folderPathFallback: fallbackKeys.has(resource.key)
    }));
    return freezeManifest({
      schemaVersion: 1,
      gradPackVersion: GRADPACK_VERSION,
      createdAt: snapshot.createdAt,
      canvasHost: CANVAS_HOST,
      course: {
        id: validatedPlan.course.id,
        name: validatedPlan.course.name,
        courseCode: validatedPlan.course.courseCode
      },
      moduleDiscovery: validatedPlan.moduleDiscovery,
      part: {
        index: validatedPartPlan.index,
        total: validatedPartPlan.total
      },
      courseTotals: {
        advertisedBytes: validatedPlan.advertisedBytes,
        resourceCount: validatedPlan.resources.length,
        unknownSizeCount: validatedPlan.resources.filter(
          (resource) => resource.kind === "file" && resource.advertisedBytes === null
        ).length,
        folderPathFallbackCount: validatedPlan.folderPathFallbackKeys.length
      },
      totals,
      resourceCatalog,
      resources
    });
  }
  function normalizeArchiveManifest(value) {
    const record2 = exactRecord(value, [
      "schemaVersion",
      "gradPackVersion",
      "createdAt",
      "canvasHost",
      "course",
      "moduleDiscovery",
      "part",
      "courseTotals",
      "totals",
      "resourceCatalog",
      "resources"
    ]);
    if (valueOf(record2, "schemaVersion") !== 1 || valueOf(record2, "gradPackVersion") !== GRADPACK_VERSION || valueOf(record2, "canvasHost") !== CANVAS_HOST) {
      throw new TypeError("Invalid archive manifest");
    }
    const courseRecord = exactRecord(valueOf(record2, "course"), [
      "id",
      "name",
      "courseCode"
    ]);
    const course = {
      id: safeInteger(valueOf(courseRecord, "id"), 1),
      name: text(valueOf(courseRecord, "name"), true),
      courseCode: text(valueOf(courseRecord, "courseCode"), true)
    };
    const partRecord = exactRecord(valueOf(record2, "part"), ["index", "total"]);
    const part = {
      index: safeInteger(valueOf(partRecord, "index"), 1),
      total: safeInteger(valueOf(partRecord, "total"), 1)
    };
    if (part.index > part.total) throw new TypeError("Invalid archive part");
    const courseTotalsRecord = exactRecord(valueOf(record2, "courseTotals"), [
      "advertisedBytes",
      "resourceCount",
      "unknownSizeCount",
      "folderPathFallbackCount"
    ]);
    const courseTotals = {
      advertisedBytes: safeInteger(
        valueOf(courseTotalsRecord, "advertisedBytes")
      ),
      resourceCount: safeInteger(valueOf(courseTotalsRecord, "resourceCount")),
      unknownSizeCount: safeInteger(
        valueOf(courseTotalsRecord, "unknownSizeCount")
      ),
      folderPathFallbackCount: safeInteger(
        valueOf(courseTotalsRecord, "folderPathFallbackCount")
      )
    };
    if (courseTotals.resourceCount > MAX_ARCHIVE_RESOURCES2) {
      throw new ArchiveSafetyError("Archive resource limit exceeded");
    }
    if (courseTotals.unknownSizeCount > courseTotals.resourceCount || courseTotals.folderPathFallbackCount > courseTotals.resourceCount) {
      throw new TypeError("Invalid course totals");
    }
    const resourceCatalog = exactArray(valueOf(record2, "resourceCatalog")).map(
      (value2) => {
        const catalogRecord = exactRecord(value2, [
          "key",
          "kind",
          "title",
          "partIndex",
          "folderPathFallback"
        ]);
        const kind = valueOf(catalogRecord, "kind");
        const partIndex = safeInteger(valueOf(catalogRecord, "partIndex"), 1);
        const folderPathFallback = valueOf(catalogRecord, "folderPathFallback");
        if (!RESOURCE_KINDS.has(kind) || partIndex > part.total || typeof folderPathFallback !== "boolean") {
          throw new TypeError("Invalid resource catalog");
        }
        return {
          key: text(valueOf(catalogRecord, "key")),
          kind,
          title: text(valueOf(catalogRecord, "title"), true),
          partIndex,
          folderPathFallback
        };
      }
    );
    const catalogKeys = new Set(resourceCatalog.map(({ key }) => key));
    if (catalogKeys.size !== resourceCatalog.length || resourceCatalog.length !== courseTotals.resourceCount || resourceCatalog.filter(({ folderPathFallback }) => folderPathFallback).length !== courseTotals.folderPathFallbackCount || resourceCatalog.length > 0 && Array.from({ length: part.total }, (_, index) => index + 1).some(
      (index) => !resourceCatalog.some(({ partIndex }) => partIndex === index)
    )) {
      throw new TypeError("Invalid resource catalog");
    }
    const rawResources = exactArray(valueOf(record2, "resources"));
    if (rawResources.length > MAX_ARCHIVE_RESOURCES2) {
      throw new ArchiveSafetyError("Archive resource limit exceeded");
    }
    const resources = rawResources.map((value2) => {
      const resourceRecord = exactRecord(value2, [
        "key",
        "kind",
        "title",
        "sourceId",
        "archivePath",
        "advertisedBytes",
        "status",
        "actualBytes",
        "failureCategory"
      ]);
      const kind = valueOf(resourceRecord, "kind");
      const sourceId = valueOf(resourceRecord, "sourceId");
      const advertisedBytes = valueOf(resourceRecord, "advertisedBytes");
      return validateOutcome(
        {
          ...Object.fromEntries(
            [
              "key",
              "kind",
              "title",
              "sourceId",
              "archivePath",
              "advertisedBytes",
              "status",
              "actualBytes",
              "failureCategory"
            ].map((key) => [key, valueOf(resourceRecord, key)])
          ),
          sourceUrl: kind === "file" ? typeof sourceId !== "string" ? null : advertisedBytes === null ? `${CANVAS_ORIGIN2}/courses/${course.id}/files/${sourceId}/download` : `${CANVAS_ORIGIN2}/files/${sourceId}/download` : kind === "external" ? "https://reference.invalid/" : null
        },
        course.id
      );
    });
    assertArchivePathSet(resources);
    const catalogByKey = new Map(
      resourceCatalog.map((resource) => [resource.key, resource])
    );
    const expectedLocalKeys = resourceCatalog.filter(({ partIndex }) => partIndex === part.index).map(({ key }) => key);
    if (resources.length !== expectedLocalKeys.length || resources.some((resource, index) => {
      const catalog = catalogByKey.get(resource.key);
      return resource.key !== expectedLocalKeys[index] || catalog === void 0 || catalog.kind !== resource.kind || catalog.title !== resource.title || catalog.partIndex !== part.index || catalog.folderPathFallback && (resource.kind !== "file" || resource.archivePath === null || !resource.archivePath.startsWith("files/unfiled/"));
    })) {
      throw new TypeError("Invalid local part resources");
    }
    const totalsRecord = exactRecord(valueOf(record2, "totals"), [
      "success",
      "failed",
      "unavailable",
      "unsupported",
      "external",
      "advertisedBytes",
      "archivedBytes"
    ]);
    const totals = {
      success: safeInteger(valueOf(totalsRecord, "success")),
      failed: safeInteger(valueOf(totalsRecord, "failed")),
      unavailable: safeInteger(valueOf(totalsRecord, "unavailable")),
      unsupported: safeInteger(valueOf(totalsRecord, "unsupported")),
      external: safeInteger(valueOf(totalsRecord, "external")),
      advertisedBytes: safeInteger(valueOf(totalsRecord, "advertisedBytes")),
      archivedBytes: safeInteger(valueOf(totalsRecord, "archivedBytes"))
    };
    const calculated = {
      success: 0,
      failed: 0,
      unavailable: 0,
      unsupported: 0,
      external: 0,
      advertisedBytes: 0,
      archivedBytes: 0
    };
    const keys = /* @__PURE__ */ new Set();
    for (const resource of resources) {
      if (keys.has(resource.key))
        throw new TypeError("Duplicate manifest resource");
      keys.add(resource.key);
      calculated[resource.status] += 1;
      calculated.advertisedBytes = addSafe(
        calculated.advertisedBytes,
        resource.advertisedBytes ?? 0
      );
      if (resource.status === "success") {
        calculated.archivedBytes = addSafe(
          calculated.archivedBytes,
          resource.actualBytes
        );
      }
    }
    if (totals.archivedBytes > MAX_ARCHIVE_BYTES || totals.advertisedBytes > courseTotals.advertisedBytes || Object.keys(calculated).some(
      (key) => calculated[key] !== totals[key]
    )) {
      throw new TypeError("Invalid manifest totals");
    }
    return freezeManifest({
      schemaVersion: 1,
      gradPackVersion: GRADPACK_VERSION,
      createdAt: canonicalTimestamp(valueOf(record2, "createdAt")),
      canvasHost: CANVAS_HOST,
      course,
      moduleDiscovery: moduleDiscovery(valueOf(record2, "moduleDiscovery")),
      part,
      courseTotals,
      totals,
      resourceCatalog,
      resources: resources.map((resource) => ({
        key: resource.key,
        kind: resource.kind,
        title: resource.title,
        sourceId: resource.sourceId,
        archivePath: resource.archivePath,
        advertisedBytes: resource.advertisedBytes,
        status: resource.status,
        actualBytes: resource.actualBytes,
        failureCategory: resource.failureCategory
      }))
    });
  }

  // src/archive/style.ts
  var ARCHIVE_CSS = `:root {
  color-scheme: light;
  --gradpack-rail: #273746;
  --gradpack-accent: #a32035;
  --gradpack-text: #2d3b45;
  --gradpack-muted: #63717b;
  --gradpack-border: #c7cdd1;
  font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  line-height: 1.5;
  color: var(--gradpack-text);
  background: #fff;
}
* { box-sizing: border-box; }
body { margin: 0; }
a { color: var(--gradpack-accent); text-underline-offset: 0.18em; }
a:hover { color: #781728; }
:focus-visible { outline: 3px solid #2563eb; outline-offset: 3px; }
.skip-link { position: fixed; left: 0.75rem; top: -5rem; z-index: 10; padding: 0.6rem 0.9rem; background: #fff; }
.skip-link:focus { top: 0.75rem; }
.archive-layout { min-height: 100vh; display: grid; grid-template-columns: 5rem 14rem minmax(0, 1fr); }
.global-rail { padding: 1rem 0.4rem; background: var(--gradpack-rail); color: #fff; display: flex; flex-direction: column; gap: 0.35rem; text-align: center; }
.global-rail a { padding: 0.75rem 0.25rem; color: #fff; border-left: 4px solid transparent; text-decoration: none; font-size: 0.78rem; }
.global-rail a[aria-current="page"] { border-left-color: #fff; background: #1e2c38; font-weight: 700; }
.gradpack-mark { display: grid; place-items: center; width: 2.6rem; height: 2.6rem; margin: 0 auto 0.75rem; border-radius: 50%; background: #fff; color: var(--gradpack-accent); font-weight: 800; }
.course-navigation { padding: 1.4rem 1rem; border-right: 1px solid var(--gradpack-border); display: flex; flex-direction: column; gap: 0.2rem; }
.course-navigation strong { overflow-wrap: anywhere; }
.course-code { margin-bottom: 0.9rem; color: var(--gradpack-muted); font-size: 0.82rem; }
.course-navigation a { padding: 0.55rem 0.65rem; border-radius: 0.2rem; text-decoration: none; }
.course-navigation a[aria-current="page"] { color: var(--gradpack-accent); background: #f9ecef; font-weight: 700; }
.archive-workspace { min-width: 0; padding: 0 2rem; }
.combined-workspace { grid-column: 2 / -1; }
.breadcrumbs { display: flex; flex-wrap: wrap; gap: 0.5rem; align-items: center; min-height: 3.5rem; border-bottom: 1px solid var(--gradpack-border); color: var(--gradpack-muted); font-size: 0.9rem; }
main { width: min(70rem, 100%); padding: 2rem 0 4rem; }
h1, h2 { line-height: 1.2; }
h1 { margin: 0 0 1rem; font-size: clamp(1.75rem, 4vw, 2.35rem); font-weight: 500; }
h2 { margin: 0 0 0.75rem; }
.archive-header, .summary, .module, .all-resources, .responsibility-notice, .panel { margin: 0 0 1.25rem; padding: 1.25rem; border: 1px solid var(--gradpack-border); background: #fff; }
.module { padding: 0; }
.module > h2 { margin: 0; padding: 0.9rem 1rem; background: #f5f5f5; border-bottom: 1px solid var(--gradpack-border); font-size: 1rem; }
.module ol, .resource-list { margin: 0; padding: 0; list-style: none; }
.module li, .resource-list li, .all-resources li { padding: 0.75rem 1rem; border-top: 1px solid #e3e6e8; }
.module-indent-1 { padding-left: 2rem !important; }
.module-indent-2 { padding-left: 3rem !important; }
.module-indent-3 { padding-left: 4rem !important; }
.module-indent-4 { padding-left: 5rem !important; }
.module-indent-5 { padding-left: 6rem !important; }
.resource-status { display: inline-block; margin-left: 0.4rem; padding: 0.12rem 0.5rem; border-radius: 999px; color: #3f496d; background: #eceefa; font-size: 0.78rem; }
.archive-part { margin: 0 0 1rem; color: var(--gradpack-muted); font-size: 0.85rem; font-weight: 700; }
.resource-part { display: inline-block; margin-left: 0.4rem; color: var(--gradpack-muted); font-size: 0.82rem; }
.unfiled-notice { border-color: #d9c98d; background: #fffbee; }
.status-success { color: #17633a; background: #e8f5ed; }
.status-unavailable, .status-failed { color: #7a3d00; background: #fff1df; }
.metadata, .status-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(10rem, 1fr)); gap: 0.75rem; margin: 0; }
.course-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(16rem, 1fr)); gap: 1rem; }
.course-card h2 { font-size: 1.15rem; }
.metadata dd { margin: 0.2rem 0 0; overflow-wrap: anywhere; }
.metadata dt, .eyebrow { color: var(--gradpack-muted); font-size: 0.8rem; font-weight: 700; }
.eyebrow { margin: 0 0 0.35rem; letter-spacing: 0.08em; text-transform: uppercase; }
.responsibility-notice { border-color: #d9c98d; background: #fffbee; }
.archive-identity { padding: 1rem 0 2rem; border-top: 1px solid var(--gradpack-border); color: var(--gradpack-muted); font-size: 0.82rem; }

@media (max-width: 48rem) {
  .archive-layout { grid-template-columns: 1fr; }
  .global-rail, .course-navigation { flex-direction: row; flex-wrap: wrap; align-items: center; border: 0; border-bottom: 1px solid var(--gradpack-border); }
  .global-rail { text-align: left; }
  .global-rail a { border-left: 0; border-bottom: 3px solid transparent; }
  .global-rail a[aria-current="page"] { border-bottom-color: #fff; }
  .gradpack-mark { margin: 0 0.5rem 0 0; }
  .course-navigation strong, .course-code { width: 100%; }
  .archive-workspace { padding: 0 1rem; }
  .combined-workspace { grid-column: auto; }
  main { padding-top: 1.25rem; }
}
`;

  // src/archive/archive-links.ts
  var COURSE_HTML_PATHS = Object.freeze([
    "files.html",
    "index.html",
    "modules.html",
    "pages.html",
    "status.html"
  ]);
  var relativeArchiveHref = (fromPath, toPath) => {
    if (!isCanonicalArchivePath(fromPath) || !isCanonicalArchivePath(toPath)) {
      throw new TypeError("Invalid archive link path");
    }
    const from = fromPath.split("/").slice(0, -1);
    const to = toPath.split("/");
    let shared = 0;
    while (shared < from.length && from[shared] === to[shared]) shared += 1;
    return [
      ...from.slice(shared).map(() => ".."),
      ...to.slice(shared).map((segment) => encodeURIComponent(segment))
    ].join("/");
  };

  // src/archive/shell.ts
  var COURSES_HOME_LINK_CLASS = "courses-home-link";
  var escapeHtml = (value) => value.replace(/[&<>"']/gu, (character) => {
    const entities = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    };
    return entities[character] ?? character;
  });
  var navigation = [
    ["home", "Home", "index.html"],
    ["modules", "Modules", "modules.html"],
    ["pages", "Pages", "pages.html"],
    ["files", "Files", "files.html"],
    ["status", "Archive Status", "status.html"]
  ];
  var archiveLink = (from, to, label, current = false) => `<a href="${relativeArchiveHref(from, to)}"${current ? ' aria-current="page"' : ""}>${label}</a>`;
  var renderArchiveShell = (input) => {
    const active = input.pageKind === "saved-page" ? "pages" : input.pageKind;
    const courseNav = navigation.map(
      ([kind, label, path]) => archiveLink(input.pagePath, path, label, kind === active)
    ).join("");
    const coursesHref = input.combinedHomeHref ?? relativeArchiveHref(input.pagePath, "index.html");
    const title = escapeHtml(input.title);
    const courseName = escapeHtml(input.course.name);
    const code = escapeHtml(input.course.courseCode);
    return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title} \u2014 GradPack</title><link rel="stylesheet" href="${relativeArchiveHref(input.pagePath, "assets/archive.css")}"></head><body><a class="skip-link" href="#archive-main">Skip to content</a><div class="archive-layout"><nav class="global-rail" aria-label="Archive"><span class="gradpack-mark" aria-label="GradPack">GP</span>${archiveLink(input.pagePath, "index.html", "Archive", active === "home")}<a class="${COURSES_HOME_LINK_CLASS}" href="${escapeHtml(coursesHref)}">Courses</a>${archiveLink(input.pagePath, "status.html", "Status", active === "status")}</nav><nav class="course-navigation" aria-label="Course"><strong>${courseName}</strong><span class="course-code">${code}</span>${courseNav}</nav><div class="archive-workspace"><nav class="breadcrumbs" aria-label="Breadcrumb"><a class="${COURSES_HOME_LINK_CLASS}" href="${escapeHtml(coursesHref)}">Courses</a><span aria-hidden="true">\u203A</span><a href="${relativeArchiveHref(input.pagePath, "index.html")}">${courseName}</a><span aria-hidden="true">\u203A</span><span>${title}</span></nav><main id="archive-main" tabindex="-1">${input.contentHtml}</main><footer class="archive-identity">Local GradPack archive</footer></div></div></body></html>`;
  };

  // src/archive/build-zip.ts
  var CORE_PATHS = [
    "assets/archive.css",
    "files.html",
    "index.html",
    "manifest.json",
    "modules.html",
    "pages.html",
    "status.html"
  ];
  var CORE_CANONICAL = new Set(CORE_PATHS.map(canonicalArchivePath));
  var FIXED_ZIP_DATE = 10273;
  var FIXED_ZIP_TIME = 0;
  var ZIP_MTIME_SEED = "2000-01-01T12:00:00.000Z";
  var MAX_CLASSIC_ZIP_ENTRIES = CLASSIC_ZIP_ENTRY_LIMIT;
  var MAX_TEXT_BYTES = 16 * 1024 * 1024;
  var MAX_ZIP_NAME_LENGTH = 180;
  var HTML_NAMESPACE = "http://www.w3.org/1999/xhtml";
  var CONTROL2 = /[\p{Cc}\p{Cf}\p{Cs}]/u;
  var ENCODED_CONTROL2 = /%(?:0[0-9a-f]|1[0-9a-f]|7f)/iu;
  var INDEX_TAGS = /* @__PURE__ */ new Set([
    "a",
    "aside",
    "body",
    "dd",
    "div",
    "dl",
    "dt",
    "h1",
    "h2",
    "head",
    "header",
    "html",
    "li",
    "link",
    "main",
    "meta",
    "ol",
    "p",
    "section",
    "span",
    "title",
    "ul"
  ]);
  var INDEX_CLASSES = /* @__PURE__ */ new Set([
    "all-resources",
    "archive-header",
    "eyebrow",
    "metadata",
    "module",
    "resource-status",
    "responsibility-notice",
    "summary"
  ]);
  var INDEX_IDS = /* @__PURE__ */ new Set([
    "modules-title",
    "resources-title",
    "summary-title"
  ]);
  var SHELL_TAGS = /* @__PURE__ */ new Set([
    ...INDEX_TAGS,
    "abbr",
    "article",
    "b",
    "blockquote",
    "br",
    "caption",
    "cite",
    "code",
    "col",
    "colgroup",
    "del",
    "details",
    "dfn",
    "em",
    "figcaption",
    "figure",
    "footer",
    "hr",
    "h3",
    "h4",
    "h5",
    "h6",
    "i",
    "img",
    "kbd",
    "mark",
    "nav",
    "pre",
    "q",
    "s",
    "samp",
    "small",
    "strong",
    "sub",
    "summary",
    "sup",
    "table",
    "tbody",
    "td",
    "tfoot",
    "th",
    "thead",
    "time",
    "tr",
    "u",
    "var"
  ]);
  var SHELL_CLASSES = /* @__PURE__ */ new Set([
    ...INDEX_CLASSES,
    "archive-identity",
    "archive-layout",
    "archive-part",
    "archive-workspace",
    "breadcrumbs",
    "combined-workspace",
    "course-card",
    "course-code",
    "course-grid",
    COURSES_HOME_LINK_CLASS,
    "course-navigation",
    "global-rail",
    "gradpack-mark",
    "modules-unavailable",
    "panel",
    "resource-list",
    "resource-part",
    "saved-page-content",
    "skip-link",
    "status-external",
    "status-failed",
    "status-grid",
    "status-other-part",
    "status-success",
    "status-unavailable",
    "status-unsupported",
    "unfiled-notice"
  ]);
  var SHELL_ATTRIBUTES = /* @__PURE__ */ new Set([
    "abbr",
    "alt",
    "aria-current",
    "aria-hidden",
    "aria-label",
    "charset",
    "class",
    "colspan",
    "content",
    "datetime",
    "dir",
    "headers",
    "height",
    "href",
    "id",
    "lang",
    "name",
    "rel",
    "reversed",
    "rowspan",
    "scope",
    "span",
    "start",
    "tabindex",
    "title",
    "type",
    "value",
    "width"
  ]);
  var exactInput = (value) => {
    let prototype;
    try {
      prototype = typeof value === "object" && value !== null ? Object.getPrototypeOf(value) : null;
    } catch {
      throw new TypeError("Invalid archive input");
    }
    if (typeof value !== "object" || value === null || Array.isArray(value) || prototype !== Object.prototype && prototype !== null) {
      throw new TypeError("Invalid archive input");
    }
    let keys;
    try {
      keys = Reflect.ownKeys(value);
    } catch {
      throw new TypeError("Invalid archive input");
    }
    const expected = [
      "archiveRoot",
      "pages",
      "archiveCss",
      "manifest",
      "entries"
    ];
    if (keys.length !== expected.length || keys.some((key) => typeof key !== "string" || !expected.includes(key))) {
      throw new TypeError("Invalid archive input");
    }
    const snapshot = /* @__PURE__ */ Object.create(null);
    for (const key of expected) {
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (!descriptor || !("value" in descriptor)) {
        throw new TypeError("Invalid archive input");
      }
      snapshot[key] = descriptor.value;
    }
    return snapshot;
  };
  var ownValue = (value, key) => {
    return value[key];
  };
  var archiveText = (value) => {
    if (typeof value !== "string" || strToU8(value).byteLength > MAX_TEXT_BYTES) {
      throw new TypeError("Invalid archive text");
    }
    return value;
  };
  var safeExternalHref = (value) => {
    if (CONTROL2.test(value) || ENCODED_CONTROL2.test(value)) return false;
    let url;
    try {
      url = new URL(value);
    } catch {
      return false;
    }
    return url.protocol === "https:" && url.username === "" && url.password === "";
  };
  var safeMailtoHref = (value) => {
    if (CONTROL2.test(value) || ENCODED_CONTROL2.test(value)) return false;
    let url;
    try {
      url = new URL(value);
    } catch {
      return false;
    }
    return url.protocol === "mailto:" && url.username === "" && url.password === "" && /^mailto:[^/\s]/iu.test(value);
  };
  var safeExternalAnchorHref = (value) => safeExternalHref(value) || safeMailtoHref(value);
  var safeLocalHref = (value) => {
    let path;
    try {
      path = decodeURIComponent(value);
    } catch {
      return false;
    }
    return isCanonicalArchivePath(path) && (path.startsWith("files/") || path.startsWith("pages/")) && path.split("/").map(encodeURIComponent).join("/") === value;
  };
  var exactAttributes = (element, expected) => {
    const attributes = [...element.attributes];
    return attributes.length === Object.keys(expected).length && attributes.every(
      (attribute) => attribute.namespaceURI === null && Object.hasOwn(expected, attribute.name) && expected[attribute.name] === attribute.value
    );
  };
  var safeShellHref = (value) => {
    if (value === "#archive-main") return true;
    if (safeExternalAnchorHref(value)) return true;
    if (value.includes("\\") || value.includes(":") || value.includes("?") || value.includes("#") || value.startsWith("//"))
      return false;
    let url;
    try {
      url = new URL(value, "https://archive.invalid/index.html");
    } catch {
      return false;
    }
    let path;
    try {
      path = decodeURIComponent(url.pathname.slice(1));
    } catch {
      return false;
    }
    return url.origin === "https://archive.invalid" && isCanonicalArchivePath(path);
  };
  var validateShellIndex = (html2, document3, pagePath) => {
    if (document3.doctype?.name.toLowerCase() !== "html" || document3.documentElement.namespaceURI !== HTML_NAMESPACE || !exactAttributes(document3.documentElement, { lang: "en" }) || !exactAttributes(document3.head, {}) || !exactAttributes(document3.body, {}) || !document3.body.querySelector(":scope > .skip-link + .archive-layout") || document3.querySelector(
      "script, style, form, iframe, object, embed, input, button"
    ))
      throw new TypeError("Invalid archive index");
    const head = [...document3.head.children];
    const link = head[3];
    if (head.length !== 4 || head[0]?.localName !== "meta" || !exactAttributes(head[0], { charset: "utf-8" }) || head[1]?.localName !== "meta" || !exactAttributes(head[1], {
      name: "viewport",
      content: "width=device-width,initial-scale=1"
    }) || head[2]?.localName !== "title" || !exactAttributes(head[2], {}) || head[2].children.length !== 0 || link?.localName !== "link" || link.parentElement !== document3.head || document3.querySelectorAll("link").length !== 1 || !exactAttributes(link, {
      rel: "stylesheet",
      href: relativeArchiveHref(pagePath, "assets/archive.css")
    }) || document3.querySelectorAll("main").length !== 1 || document3.querySelectorAll("h1").length !== 1) {
      throw new TypeError("Invalid archive index");
    }
    for (const element of document3.querySelectorAll("*")) {
      if (element.namespaceURI !== HTML_NAMESPACE || !SHELL_TAGS.has(element.localName)) {
        throw new TypeError("Invalid archive index");
      }
      for (const attribute of [...element.attributes]) {
        if (attribute.namespaceURI !== null || attribute.name.startsWith("on") || !SHELL_ATTRIBUTES.has(attribute.name) && !/^aria-[a-z][a-z0-9-]*$/u.test(attribute.name))
          throw new TypeError(
            `Invalid archive index attribute ${element.localName}:${attribute.name}`
          );
      }
      const className = element.getAttribute("class");
      if (className !== null && className.split(/\s+/u).some(
        (name) => !SHELL_CLASSES.has(name) && !/^module-indent-[0-5]$/u.test(name)
      )) {
        throw new TypeError("Invalid archive index");
      }
      const id = element.getAttribute("id");
      if (id !== null && id !== "archive-main") {
        throw new TypeError("Invalid archive index");
      }
      if (element.localName !== "a" && element.localName !== "link" && element.hasAttribute("href")) {
        throw new TypeError("Invalid archive index");
      }
    }
    for (const anchor of document3.querySelectorAll("a[href]")) {
      const href = anchor.getAttribute("href");
      if (href === null || !safeShellHref(href))
        throw new TypeError("Invalid archive index");
      if (safeExternalAnchorHref(href) && anchor.getAttribute("rel") !== "noopener noreferrer") {
        throw new TypeError("Invalid archive index");
      }
    }
    const walker = document3.createTreeWalker(document3, NodeFilter.SHOW_COMMENT);
    if (walker.nextNode()) throw new TypeError("Invalid archive index");
    return `<!doctype html>${document3.documentElement.outerHTML}`;
  };
  var validateArchiveLinkTargets = (pagePath, html2, paths) => {
    const document3 = new DOMParser().parseFromString(html2, "text/html");
    const archivePrefix = "/archive/";
    const base = `https://archive.invalid${archivePrefix}${pagePath.split("/").map(encodeURIComponent).join("/")}`;
    for (const element of document3.querySelectorAll("a[href], link[href]")) {
      const href = element.getAttribute("href");
      if (href === null || href.startsWith("#") || safeExternalAnchorHref(href))
        continue;
      let url;
      let target;
      try {
        url = new URL(href, base);
        if (!url.pathname.startsWith(archivePrefix)) {
          throw new TypeError("Invalid archive link target");
        }
        target = decodeURIComponent(url.pathname.slice(archivePrefix.length));
      } catch {
        throw new TypeError("Invalid archive link target");
      }
      if (url.origin !== "https://archive.invalid" || !isCanonicalArchivePath(target) || !paths.has(target) || href !== relativeArchiveHref(pagePath, target)) {
        throw new TypeError("Invalid archive link target");
      }
    }
  };
  var validateArchiveHtml = (pagePath, value) => {
    if (!isCanonicalArchivePath(pagePath)) {
      throw new TypeError("Invalid archive page path");
    }
    const html2 = archiveText(value);
    const document3 = new DOMParser().parseFromString(html2, "text/html");
    if (document3.body.querySelector(".archive-layout")) {
      return validateShellIndex(html2, document3, pagePath);
    }
    const main = document3.body.firstElementChild;
    if (document3.doctype?.name.toLowerCase() !== "html" || document3.documentElement.namespaceURI !== HTML_NAMESPACE || !exactAttributes(document3.documentElement, { lang: "en" }) || !exactAttributes(document3.head, {}) || document3.body.children.length !== 1 || main?.localName !== "main" || !exactAttributes(document3.body, {}) || !exactAttributes(main, {})) {
      throw new TypeError("Invalid archive index");
    }
    const head = [...document3.head.children];
    if (head.length !== 4 || head[0]?.localName !== "meta" || !exactAttributes(head[0], { charset: "utf-8" }) || head[1]?.localName !== "meta" || !exactAttributes(head[1], {
      name: "viewport",
      content: "width=device-width,initial-scale=1"
    }) || head[2]?.localName !== "title" || !exactAttributes(head[2], {}) || head[2].children.length !== 0 || head[3]?.localName !== "link" || !exactAttributes(head[3], {
      rel: "stylesheet",
      href: relativeArchiveHref(pagePath, "assets/archive.css")
    })) {
      throw new TypeError("Invalid archive index");
    }
    const trustedStructure = /* @__PURE__ */ new Set([
      document3.documentElement,
      document3.head,
      document3.body,
      main,
      ...head
    ]);
    for (const element of document3.querySelectorAll("*")) {
      if (element.namespaceURI !== HTML_NAMESPACE || !INDEX_TAGS.has(element.localName)) {
        throw new TypeError("Invalid archive index");
      }
      if (["html", "head", "body", "main", "meta", "title", "link"].includes(
        element.localName
      )) {
        if (!trustedStructure.has(element)) {
          throw new TypeError("Invalid archive index");
        }
        continue;
      }
      if (element.localName === "a") continue;
      const attributes = [...element.attributes];
      if (attributes.some(
        (attribute) => attribute.namespaceURI !== null || !["aria-labelledby", "class", "id"].includes(attribute.name)
      )) {
        throw new TypeError("Invalid archive index");
      }
      const className = element.getAttribute("class");
      const id = element.getAttribute("id");
      const labelledBy = element.getAttribute("aria-labelledby");
      if (className !== null && !INDEX_CLASSES.has(className) || id !== null && !INDEX_IDS.has(id) || labelledBy !== null && !(INDEX_IDS.has(labelledBy) && (labelledBy === id || element.localName === "section" && id === null))) {
        throw new TypeError("Invalid archive index");
      }
    }
    for (const anchor of document3.querySelectorAll("a[href]")) {
      const href = anchor.getAttribute("href");
      if (href === null) throw new TypeError("Invalid archive index");
      const local = safeLocalHref(href);
      if (!local && !safeExternalHref(href)) {
        throw new TypeError("Invalid archive index");
      }
      const expected = local ? { href } : { href, rel: "noopener noreferrer" };
      if (!exactAttributes(anchor, expected)) {
        throw new TypeError("Invalid archive index");
      }
    }
    if (document3.querySelector("a:not([href])")) {
      throw new TypeError("Invalid archive index");
    }
    const walker = document3.createTreeWalker(document3, NodeFilter.SHOW_COMMENT);
    if (walker.nextNode()) throw new TypeError("Invalid archive index");
    return `<!doctype html>${document3.documentElement.outerHTML}`;
  };
  var validateArchiveCss = (value) => {
    const css = archiveText(value);
    if (css !== ARCHIVE_CSS) {
      throw new TypeError("Invalid archive stylesheet");
    }
    return css;
  };
  var collectGeneratedPages = (value) => {
    if (Object.getPrototypeOf(value) !== Map.prototype) {
      throw new TypeError("Invalid generated pages");
    }
    const pairs = [...Map.prototype.entries.call(value)];
    if (pairs.length !== COURSE_HTML_PATHS.length) {
      throw new TypeError("Invalid generated page set");
    }
    const pages = /* @__PURE__ */ new Map();
    for (const path of COURSE_HTML_PATHS) {
      const pair = pairs.find(([candidate]) => candidate === path);
      if (!pair) throw new TypeError("Invalid generated page set");
      pages.set(path, validateArchiveHtml(path, pair[1]));
    }
    return pages;
  };
  var typedArrayPrototype = Object.getPrototypeOf(
    Uint8Array.prototype
  );
  var typedArrayBufferGetter = Object.getOwnPropertyDescriptor(
    typedArrayPrototype,
    "buffer"
  )?.get;
  var typedArrayByteLengthGetter = Object.getOwnPropertyDescriptor(
    typedArrayPrototype,
    "byteLength"
  )?.get;
  var typedArrayTagGetter = Object.getOwnPropertyDescriptor(
    typedArrayPrototype,
    Symbol.toStringTag
  )?.get;
  var arrayBufferByteLengthGetter = Object.getOwnPropertyDescriptor(
    ArrayBuffer.prototype,
    "byteLength"
  )?.get;
  var sharedArrayBufferByteLengthGetter = typeof SharedArrayBuffer === "undefined" ? void 0 : Object.getOwnPropertyDescriptor(SharedArrayBuffer.prototype, "byteLength")?.get;
  var uint8ArraySet = Uint8Array.prototype.set;
  var IntrinsicDataView = DataView;
  var cloneBytes = (value) => {
    if (!typedArrayBufferGetter || !typedArrayByteLengthGetter || !typedArrayTagGetter || !arrayBufferByteLengthGetter) {
      throw new TypeError("Invalid archive bytes");
    }
    let buffer;
    let byteLength;
    let tag;
    try {
      buffer = Reflect.apply(
        typedArrayBufferGetter,
        value,
        []
      );
      byteLength = Reflect.apply(typedArrayByteLengthGetter, value, []);
      tag = Reflect.apply(typedArrayTagGetter, value, []);
    } catch {
      throw new TypeError("Invalid archive bytes");
    }
    if (tag !== "Uint8Array" || !Number.isSafeInteger(byteLength) || byteLength < 0) {
      throw new TypeError("Invalid archive bytes");
    }
    let arrayBufferLength;
    try {
      arrayBufferLength = Reflect.apply(
        arrayBufferByteLengthGetter,
        buffer,
        []
      );
    } catch {
      if (sharedArrayBufferByteLengthGetter) {
        try {
          Reflect.apply(sharedArrayBufferByteLengthGetter, buffer, []);
        } catch {
          throw new TypeError("Invalid archive bytes");
        }
      }
      throw new TypeError("Invalid archive bytes");
    }
    if (!Number.isSafeInteger(arrayBufferLength) || arrayBufferLength < byteLength) {
      throw new TypeError("Invalid archive bytes");
    }
    try {
      new IntrinsicDataView(buffer, 0, 0);
      const output = new Uint8Array(byteLength);
      Reflect.apply(uint8ArraySet, output, [value, 0]);
      return output;
    } catch {
      throw new TypeError("Invalid archive bytes");
    }
  };
  var compareText = (left, right) => left < right ? -1 : left > right ? 1 : 0;
  var validateContentPath = (path) => {
    if (!isCanonicalArchivePath(path) || CORE_CANONICAL.has(canonicalArchivePath(path)) || !path.startsWith("files/") && !path.startsWith("pages/")) {
      throw new TypeError("Invalid ZIP entry path");
    }
    return path;
  };
  var expectedPrefix = (resource) => resource.kind === "file" ? "files/" : "pages/";
  var collectPayloads = (rawEntries, manifest) => {
    if (Object.getPrototypeOf(rawEntries) !== Map.prototype) {
      throw new TypeError("Invalid archive entries");
    }
    const mapSizeGetter = Object.getOwnPropertyDescriptor(
      Map.prototype,
      "size"
    )?.get;
    let entryCount;
    try {
      entryCount = mapSizeGetter ? Reflect.apply(mapSizeGetter, rawEntries, []) : Number.NaN;
    } catch {
      throw new TypeError("Invalid archive entries");
    }
    if (entryCount > MAX_ZIP_PAYLOAD_ENTRIES) {
      throw new ArchiveSafetyError("ZIP payload entry limit exceeded");
    }
    let rawPairs;
    try {
      rawPairs = [
        ...Map.prototype.entries.call(
          rawEntries
        )
      ];
    } catch {
      throw new TypeError("Invalid archive entries");
    }
    const payloads = /* @__PURE__ */ new Map();
    for (const [rawPath, rawBytes] of rawPairs) {
      const path = validateContentPath(rawPath);
      payloads.set(path, cloneBytes(rawBytes));
    }
    assertArchivePathSet(
      [...payloads.keys()].map((path) => ({
        kind: path.startsWith("files/") ? "file" : "page",
        archivePath: path
      }))
    );
    const expected = /* @__PURE__ */ new Map();
    for (const resource of manifest.resources) {
      if (resource.status !== "success") continue;
      if (resource.archivePath === null || !resource.archivePath.startsWith(expectedPrefix(resource))) {
        throw new TypeError("Invalid successful resource path");
      }
      const canonical = canonicalArchivePath(resource.archivePath);
      expected.set(canonical, resource);
    }
    if (payloads.size !== expected.size) {
      throw new TypeError("ZIP payload set does not match manifest");
    }
    for (const [path, bytes] of payloads) {
      const resource = expected.get(canonicalArchivePath(path));
      if (!resource || resource.archivePath !== path || resource.actualBytes !== bytes.byteLength) {
        throw new TypeError("ZIP payload does not match manifest");
      }
    }
    return payloads;
  };
  var patchZipTimes = (bytes) => {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    let offset = 0;
    while (offset + 30 <= bytes.byteLength && view.getUint32(offset, true) === 67324752) {
      view.setUint16(offset + 10, FIXED_ZIP_TIME, true);
      view.setUint16(offset + 12, FIXED_ZIP_DATE, true);
      const compressedSize = view.getUint32(offset + 18, true);
      const nameLength = view.getUint16(offset + 26, true);
      const extraLength = view.getUint16(offset + 28, true);
      offset += 30 + nameLength + extraLength + compressedSize;
    }
    while (offset + 46 <= bytes.byteLength && view.getUint32(offset, true) === 33639248) {
      view.setUint16(offset + 12, FIXED_ZIP_TIME, true);
      view.setUint16(offset + 14, FIXED_ZIP_DATE, true);
      const nameLength = view.getUint16(offset + 28, true);
      const extraLength = view.getUint16(offset + 30, true);
      const commentLength = view.getUint16(offset + 32, true);
      offset += 46 + nameLength + extraLength + commentLength;
    }
    if (offset + 22 > bytes.byteLength || view.getUint32(offset, true) !== 101010256) {
      throw new TypeError("Invalid generated ZIP");
    }
    return bytes;
  };
  var buildDeterministicZip = (sources) => {
    if (sources.size > MAX_CLASSIC_ZIP_ENTRIES) {
      throw new TypeError("ZIP entry limit exceeded");
    }
    const zipEntries = /* @__PURE__ */ Object.create(null);
    for (const [path, bytes] of [...sources].sort(
      ([left], [right]) => compareText(left, right)
    )) {
      zipEntries[path] = [
        bytes,
        {
          level: 6,
          mtime: ZIP_MTIME_SEED,
          os: 3,
          attrs: 33188 * 65536
        }
      ];
    }
    return patchZipTimes(zipSync(zipEntries, { level: 6 }));
  };
  function buildCourseZip(input) {
    const record2 = exactInput(input);
    const rawArchiveRoot = ownValue(record2, "archiveRoot");
    const archiveRoot = rawArchiveRoot === null || isCanonicalArchivePath(rawArchiveRoot) && rawArchiveRoot.startsWith("courses/") ? rawArchiveRoot : (() => {
      throw new TypeError("Invalid archive root");
    })();
    const pages = collectGeneratedPages(ownValue(record2, "pages"));
    const archiveCss = validateArchiveCss(ownValue(record2, "archiveCss"));
    const manifest = normalizeArchiveManifest(ownValue(record2, "manifest"));
    const payloads = collectPayloads(ownValue(record2, "entries"), manifest);
    const sources = new Map([
      ["assets/archive.css", strToU8(archiveCss)],
      ["manifest.json", strToU8(`${JSON.stringify(manifest, null, 2)}
`)],
      ...[...pages].map(([path, html2]) => [path, strToU8(html2)]),
      ...[...payloads.entries()].sort(
        ([left], [right]) => compareText(left, right)
      )
    ]);
    const paths = new Set(sources.keys());
    const targetPaths = archiveRoot === null ? paths : /* @__PURE__ */ new Set([
      "index.html",
      ...[...paths].map((path) => `${archiveRoot}/${path}`)
    ]);
    const targetPagePath = (path) => archiveRoot === null ? path : `${archiveRoot}/${path}`;
    for (const [path, html2] of pages)
      validateArchiveLinkTargets(targetPagePath(path), html2, targetPaths);
    for (const resource of manifest.resources) {
      if (resource.kind === "page" && resource.status === "success" && resource.archivePath !== null) {
        const bytes = payloads.get(resource.archivePath);
        if (!bytes) throw new TypeError("Missing saved page");
        const html2 = validateArchiveHtml(
          resource.archivePath,
          new TextDecoder().decode(bytes)
        );
        validateArchiveLinkTargets(
          targetPagePath(resource.archivePath),
          html2,
          targetPaths
        );
      }
    }
    return buildDeterministicZip(sources);
  }
  var safeZipName = (value) => {
    if (typeof value !== "string" || value.length === 0 || value.length > MAX_ZIP_NAME_LENGTH || value.includes("/") || value.includes("\\") || !value.endsWith(".zip") || value !== value.normalize("NFKC") || !isCanonicalArchivePath(value)) {
      throw new TypeError("Invalid ZIP filename");
    }
    return value;
  };
  function downloadCourseZip(fileName, bytes) {
    const safeName = safeZipName(fileName);
    const snapshot = cloneBytes(bytes);
    const stableBuffer = new Uint8Array(snapshot).buffer;
    const blob = new Blob([stableBuffer], { type: "application/zip" });
    const url = URL.createObjectURL(blob);
    setTimeout(() => URL.revokeObjectURL(url), 0);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = safeName;
    anchor.click();
  }

  // src/archive/combined.ts
  var COURSE_CORE_PATHS = /* @__PURE__ */ new Set([
    "assets/archive.css",
    "files.html",
    "index.html",
    "manifest.json",
    "modules.html",
    "pages.html",
    "status.html"
  ]);
  var escapeHtml2 = (value) => value.replace(/[&<>'"]/gu, (character) => {
    const entities = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      "'": "&#39;",
      '"': "&quot;"
    };
    return entities[character] ?? character;
  });
  var encodedPath = (path) => path.split("/").map((segment) => encodeURIComponent(segment)).join("/");
  var rewriteCoursesHomeLinks = (pagePath, root, validatedHtml) => {
    const document3 = new DOMParser().parseFromString(validatedHtml, "text/html");
    const selector = `a.${COURSES_HOME_LINK_CLASS}`;
    const marked = [...document3.querySelectorAll(selector)];
    const globalLink = document3.querySelector(`nav.global-rail > ${selector}`);
    const breadcrumbLink = document3.querySelector(
      `nav.breadcrumbs > ${selector}`
    );
    const standaloneHref = relativeArchiveHref(pagePath, "index.html");
    if (marked.length !== 2 || globalLink === null || breadcrumbLink === null || globalLink === breadcrumbLink || marked.some(
      (link) => link !== globalLink && link !== breadcrumbLink || link.textContent !== "Courses" || link.getAttribute("href") !== standaloneHref
    )) {
      throw new TypeError("Invalid nested Courses links");
    }
    const standaloneAnchor = `<a class="${COURSES_HOME_LINK_CLASS}" href="${standaloneHref}">Courses</a>`;
    const fragments = validatedHtml.split(standaloneAnchor);
    if (fragments.length !== 3) {
      throw new TypeError("Invalid nested Courses links");
    }
    const combinedHref = relativeArchiveHref(`${root}/${pagePath}`, "index.html");
    const combinedAnchor = `<a class="${COURSES_HOME_LINK_CLASS}" href="${combinedHref}">Courses</a>`;
    return strToU8(fragments.join(combinedAnchor));
  };
  var combinedCourseRoot = (course) => safeArchivePath("courses", `${course.name}-${course.id}`);
  var document2 = (title, active, content) => `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml2(title)} \u2014 GradPack</title><link rel="stylesheet" href="assets/archive.css"></head><body><a class="skip-link" href="#archive-main">Skip to content</a><div class="archive-layout"><nav class="global-rail" aria-label="Archive"><span class="gradpack-mark" aria-label="GradPack">GP</span><a href="index.html">Archive</a><a href="index.html"${active === "courses" ? ' aria-current="page"' : ""}>Courses</a><a href="status.html"${active === "status" ? ' aria-current="page"' : ""}>Status</a></nav><div class="archive-workspace combined-workspace"><main id="archive-main" tabindex="-1">${content}</main><footer class="archive-identity">Local GradPack archive</footer></div></div></body></html>`;
  var rootIndex = (archives, roots, manifest) => {
    const cards = archives.map((archive, index) => {
      const root = roots[index];
      const inventory = archive.manifest.moduleDiscovery === "disabled" ? `Module navigation unavailable \xB7 ${archive.manifest.totals.success} saved resources` : `${archive.moduleCount} modules \xB7 ${archive.itemCount} module items \xB7 ${archive.manifest.totals.success} saved resources`;
      return `<article class="course-card panel"><p class="eyebrow">${escapeHtml2(archive.course.courseCode)}</p><h2><a href="${encodedPath(`${root}/index.html`)}">${escapeHtml2(archive.course.name)}</a></h2><p>${escapeHtml2(inventory)}</p><p><a href="${encodedPath(`${root}/status.html`)}">View archive status</a></p></article>`;
    }).join("");
    return document2(
      "GradPack archives",
      "courses",
      `<header class="archive-header"><p class="eyebrow">GradPack offline archive</p><h1>Your courses</h1><p>Browse ${manifest.courses.length} saved courses without Canvas.</p></header><section class="course-grid" aria-label="Saved courses">${cards}</section>`
    );
  };
  var rootStatus = (archives, roots, manifest) => document2(
    "Combined archive status",
    "status",
    `<h1>Combined archive status</h1><section class="status-grid"><div class="panel"><strong>${manifest.courses.length}</strong><br>Courses</div><div class="panel"><strong>${manifest.totals.success}</strong><br>Saved</div><div class="panel"><strong>${manifest.totals.failed}</strong><br>Failed</div><div class="panel"><strong>${manifest.totals.unavailable}</strong><br>Unavailable</div><div class="panel"><strong>${manifest.totals.unsupported}</strong><br>Unsupported</div><div class="panel"><strong>${manifest.totals.external}</strong><br>External</div></section><h2>Course status</h2><ul class="resource-list">${archives.map((archive, index) => `<li><a href="${encodedPath(`${roots[index]}/status.html`)}">${escapeHtml2(archive.course.name)} status</a></li>`).join("")}</ul><p><a href="manifest.json">View technical manifest</a></p><aside class="responsibility-notice"><h2>Course-material responsibility</h2><p>You are responsible for applicable copyright, licensing, confidentiality, and course-material restrictions.</p></aside>`
  );
  function buildCombinedZip(input) {
    if (input.archives.length === 0 || input.archiveCss !== ARCHIVE_CSS || typeof input.now !== "function" || typeof input.fileName !== "function") {
      throw new TypeError("Invalid combined archive input");
    }
    const roots = input.archives.map(({ course }) => combinedCourseRoot(course));
    if (new Set(roots).size !== roots.length) {
      throw new TypeError("Conflicting combined course paths");
    }
    const manifest = {
      schemaVersion: 1,
      kind: "combined",
      createdAt: input.now(),
      courses: input.archives.map(
        ({ course, fileName, manifest: courseManifest }) => ({
          courseId: course.id,
          fileName,
          manifest: courseManifest
        })
      ),
      totals: input.archives.reduce(
        (totals, archive) => ({
          success: totals.success + archive.manifest.totals.success,
          failed: totals.failed + archive.manifest.totals.failed,
          unavailable: totals.unavailable + archive.manifest.totals.unavailable,
          unsupported: totals.unsupported + archive.manifest.totals.unsupported,
          external: totals.external + archive.manifest.totals.external
        }),
        { success: 0, failed: 0, unavailable: 0, unsupported: 0, external: 0 }
      )
    };
    const sources = /* @__PURE__ */ new Map();
    sources.set("assets/archive.css", strToU8(input.archiveCss));
    sources.set(
      "index.html",
      strToU8(rootIndex(input.archives, roots, manifest))
    );
    sources.set(
      "manifest.json",
      strToU8(`${JSON.stringify(manifest, null, 2)}
`)
    );
    sources.set(
      "status.html",
      strToU8(rootStatus(input.archives, roots, manifest))
    );
    input.archives.forEach((archive, index) => {
      const root = roots[index];
      const entries2 = unzipSync(archive.zipBytes);
      const rewrittenHtml = /* @__PURE__ */ new Map();
      const nestedManifest = normalizeArchiveManifest(archive.manifest);
      const expectedManifest = `${JSON.stringify(nestedManifest, null, 2)}
`;
      if (!entries2["manifest.json"] || new TextDecoder().decode(entries2["manifest.json"]) !== expectedManifest || !entries2["assets/archive.css"] || new TextDecoder().decode(entries2["assets/archive.css"]) !== ARCHIVE_CSS) {
        throw new TypeError("Invalid nested course core");
      }
      const expectedPaths = new Set(COURSE_CORE_PATHS);
      for (const resource of nestedManifest.resources) {
        if (resource.status === "success" && resource.archivePath !== null) {
          expectedPaths.add(resource.archivePath);
        }
      }
      if (Object.keys(entries2).length !== expectedPaths.size || Object.keys(entries2).some((path) => !expectedPaths.has(path))) {
        throw new TypeError("Invalid nested course entry set");
      }
      for (const pagePath of COURSE_HTML_PATHS) {
        const bytes = entries2[pagePath];
        if (!bytes) throw new TypeError("Missing nested course page");
        const validated = validateArchiveHtml(
          pagePath,
          new TextDecoder().decode(bytes)
        );
        rewrittenHtml.set(
          pagePath,
          rewriteCoursesHomeLinks(pagePath, root, validated)
        );
      }
      for (const resource of nestedManifest.resources) {
        if (resource.kind === "page" && resource.status === "success" && resource.archivePath !== null) {
          const bytes = entries2[resource.archivePath];
          if (!bytes) throw new TypeError("Missing nested saved page");
          const validated = validateArchiveHtml(
            resource.archivePath,
            new TextDecoder().decode(bytes)
          );
          rewrittenHtml.set(
            resource.archivePath,
            rewriteCoursesHomeLinks(resource.archivePath, root, validated)
          );
        }
      }
      for (const [path, bytes] of Object.entries(entries2)) {
        if (!isCanonicalArchivePath(path)) {
          throw new TypeError("Invalid nested archive path");
        }
        const combinedPath = `${root}/${path}`;
        if (!isCanonicalArchivePath(combinedPath) || sources.has(combinedPath)) {
          throw new TypeError("Conflicting combined archive path");
        }
        sources.set(combinedPath, rewrittenHtml.get(path) ?? bytes);
      }
    });
    if (sources.size > MAX_CLASSIC_ZIP_ENTRIES) {
      throw new TypeError("Combined archive resource limit exceeded");
    }
    validateArchiveHtml(
      "index.html",
      new TextDecoder().decode(sources.get("index.html"))
    );
    validateArchiveHtml(
      "status.html",
      new TextDecoder().decode(sources.get("status.html"))
    );
    const combinedPaths = new Set(sources.keys());
    for (const [path, bytes] of sources) {
      if (path.endsWith(".html")) {
        validateArchiveLinkTargets(
          path,
          new TextDecoder().decode(bytes),
          combinedPaths
        );
      }
    }
    return { zipBytes: buildDeterministicZip(sources), manifest };
  }

  // src/canvas/endpoints.ts
  var positiveId = (value) => {
    if (!Number.isSafeInteger(value) || value <= 0)
      throw new TypeError("Invalid ID");
    return String(value);
  };
  function canvasEndpoint(endpoint) {
    const url = new URL(CANVAS_ORIGIN);
    switch (endpoint.type) {
      case "currentUser":
        url.pathname = "/api/v1/users/self/profile";
        return url;
      case "courses":
        if (endpoint.enrollmentState !== "active" && endpoint.enrollmentState !== "completed") {
          throw new TypeError("Invalid enrollment state");
        }
        url.pathname = "/api/v1/courses";
        url.searchParams.set("enrollment_state", endpoint.enrollmentState);
        url.searchParams.append("state[]", "available");
        url.searchParams.append("state[]", "completed");
        url.searchParams.append("include[]", "concluded");
        url.searchParams.set("per_page", "100");
        return url;
      case "courseModules":
        url.pathname = `/api/v1/courses/${positiveId(endpoint.courseId)}/modules`;
        url.searchParams.append("include[]", "items");
        url.searchParams.append("include[]", "content_details");
        url.searchParams.set("per_page", "100");
        return url;
      case "moduleItems":
        url.pathname = `/api/v1/courses/${positiveId(endpoint.courseId)}/modules/${positiveId(endpoint.moduleId)}/items`;
        url.searchParams.set("per_page", "100");
        return url;
      case "courseFiles":
        url.pathname = `/api/v1/courses/${positiveId(endpoint.courseId)}/files`;
        url.searchParams.set("per_page", "100");
        return url;
      case "courseFile":
        url.pathname = `/api/v1/courses/${positiveId(endpoint.courseId)}/files/${positiveId(endpoint.fileId)}`;
        return url;
      case "courseFolders":
        url.pathname = `/api/v1/courses/${positiveId(endpoint.courseId)}/folders`;
        url.searchParams.set("per_page", "100");
        return url;
      case "coursePages":
        url.pathname = `/api/v1/courses/${positiveId(endpoint.courseId)}/pages`;
        url.searchParams.set("per_page", "100");
        return url;
      case "coursePage":
        if (typeof endpoint.pageUrl !== "string" || !/^[a-zA-Z0-9_-]{1,255}$/.test(endpoint.pageUrl)) {
          throw new TypeError("Invalid page URL token");
        }
        url.pathname = `/api/v1/courses/${positiveId(endpoint.courseId)}/pages/${encodeURIComponent(endpoint.pageUrl)}`;
        return url;
      default:
        throw new TypeError("Unsupported endpoint");
    }
  }

  // src/canvas/pagination.ts
  function splitLinkHeader(header) {
    const entries2 = [];
    let start = 0;
    let inAngleBrackets = false;
    let inQuotes = false;
    for (let index = 0; index < header.length; index += 1) {
      const character = header[index];
      if (character === "<" && !inQuotes) inAngleBrackets = true;
      if (character === ">" && !inQuotes) inAngleBrackets = false;
      if (character === '"' && !inAngleBrackets) inQuotes = !inQuotes;
      if (character === "," && !inAngleBrackets && !inQuotes) {
        entries2.push(header.slice(start, index).trim());
        start = index + 1;
      }
    }
    entries2.push(header.slice(start).trim());
    return entries2.filter(Boolean);
  }
  function hasNextRelation(entry) {
    for (const parameter of entry.split(";").slice(1)) {
      const match = parameter.trim().match(/^rel\s*=\s*(?:"([^"]*)"|([^\s]+))$/i);
      const value = match?.[1] ?? match?.[2];
      if (value?.split(/\s+/).includes("next")) return true;
    }
    return false;
  }
  function parseNextLink(header) {
    if (!header) return null;
    const entries2 = splitLinkHeader(header).filter(hasNextRelation);
    if (entries2.length === 0) return null;
    if (entries2.length !== 1) {
      throw new TypeError("Rejected multiple next links");
    }
    const match = entries2[0]?.match(/^\s*<([^>]+)>/);
    if (!match?.[1]) throw new TypeError("Malformed pagination link");
    let url;
    try {
      url = new URL(match[1]);
    } catch {
      throw new TypeError("Malformed pagination link");
    }
    if (url.origin !== CANVAS_ORIGIN || !url.pathname.startsWith("/api/v1/") || url.username !== "" || url.password !== "" || url.hash !== "") {
      throw new TypeError("Rejected pagination URL");
    }
    return url;
  }
  var PAGINATION_PARAMETERS = /* @__PURE__ */ new Set(["page", "per_page", "bookmark"]);
  var sortedValues = (url, key) => url.searchParams.getAll(key).sort();
  var sameValues = (left, right) => left.length === right.length && left.every((value, index) => value === right[index]);
  function validatePaginationParameters(first, next) {
    const keys = /* @__PURE__ */ new Set([
      ...first.searchParams.keys(),
      ...next.searchParams.keys()
    ]);
    for (const key of keys) {
      if (PAGINATION_PARAMETERS.has(key)) continue;
      if (!sameValues(sortedValues(first, key), sortedValues(next, key))) {
        throw new TypeError("Rejected pagination query");
      }
    }
    const pageValues = next.searchParams.getAll("page");
    const page = pageValues.length === 1 ? Number(pageValues[0]) : null;
    if (pageValues.length > 1 || pageValues.length === 1 && (!/^[1-9]\d*$/.test(pageValues[0]) || !Number.isSafeInteger(page) || page === null || page < 1)) {
      throw new TypeError("Rejected pagination query");
    }
    const perPageValues = next.searchParams.getAll("per_page");
    if (perPageValues.length > 1)
      throw new TypeError("Rejected pagination query");
    if (perPageValues.length === 1) {
      const perPage = Number(perPageValues[0]);
      if (!Number.isSafeInteger(perPage) || perPage < 1 || perPage > 100) {
        throw new TypeError("Rejected pagination query");
      }
    }
    const bookmarkValues = next.searchParams.getAll("bookmark");
    if (bookmarkValues.length > 1 || bookmarkValues.length === 1 && (!bookmarkValues[0] || bookmarkValues[0].length > 1e3)) {
      throw new TypeError("Rejected pagination query");
    }
  }
  function validateContinuation(first, next) {
    if (next.pathname !== first.pathname) {
      throw new TypeError("Rejected pagination path");
    }
    validatePaginationParameters(first, next);
  }
  async function fetchAllPages(request, first) {
    const seen = /* @__PURE__ */ new Set();
    const output = [];
    let next = first;
    while (next) {
      if (seen.has(next.href)) throw new TypeError("Pagination loop detected");
      seen.add(next.href);
      const page = await request(next);
      output.push(...page.value);
      next = parseNextLink(page.response.headers.get("link"));
      if (next) validateContinuation(first, next);
    }
    return output;
  }

  // src/canvas/http.ts
  var CanvasSessionError = class extends Error {
  };
  var CanvasResponseError = class extends Error {
  };
  var CanvasBodySizeError = class extends CanvasResponseError {
    name = "CanvasBodySizeError";
  };
  var CanvasTransientError = class extends CanvasResponseError {
    name = "CanvasTransientError";
  };
  var CanvasResourceUnavailableError = class extends CanvasResponseError {
    constructor(status2) {
      super("Canvas resource is unavailable");
      this.status = status2;
    }
    status;
    name = "CanvasResourceUnavailableError";
  };
  var CanvasCourseIndexUnavailableError = class extends CanvasResponseError {
    constructor(status2) {
      super("Canvas course index is unavailable");
      this.status = status2;
    }
    status;
    name = "CanvasCourseIndexUnavailableError";
  };
  var CanvasCourseModulesDisabledError = class extends CanvasResponseError {
    name = "CanvasCourseModulesDisabledError";
  };
  var isAbortError = (error) => error instanceof DOMException && error.name === "AbortError";
  var abortError = (signal) => isAbortError(signal.reason) ? signal.reason : new DOMException("Canvas request aborted", "AbortError");
  var abortableDelay = (milliseconds, signal) => new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(abortError(signal));
      return;
    }
    const timer = setTimeout(finish, milliseconds);
    const onAbort = () => {
      clearTimeout(timer);
      signal?.removeEventListener("abort", onAbort);
      reject(
        signal ? abortError(signal) : new DOMException("Aborted", "AbortError")
      );
    };
    function finish() {
      signal?.removeEventListener("abort", onAbort);
      resolve();
    }
    signal?.addEventListener("abort", onAbort, { once: true });
  });
  var isCanvasApiUrl = (url) => url.origin === CANVAS_ORIGIN && url.pathname.startsWith("/api/v1/") && url.username === "" && url.password === "" && url.hash === "";
  var isJsonContentType = (value) => {
    const mediaType = value.split(";", 1)[0]?.trim().toLowerCase();
    return mediaType === "application/json" || mediaType?.endsWith("+json") === true;
  };
  var isCourseCollectionIndex = (url) => /^\/api\/v1\/courses\/[1-9]\d*\/(?:files|folders|modules|pages)$/.test(
    url.pathname
  );
  var isCourseModulesIndex = (url) => /^\/api\/v1\/courses\/[1-9]\d*\/modules$/.test(url.pathname);
  var isCoursePagesIndex = (url) => /^\/api\/v1\/courses\/[1-9]\d*\/pages$/.test(url.pathname);
  var isRecord = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
  var missingDataValue = /* @__PURE__ */ Symbol("missingDataValue");
  var ownDataValue = (value, key) => {
    try {
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      return descriptor && "value" in descriptor ? descriptor.value : missingDataValue;
    } catch {
      return missingDataValue;
    }
  };
  var ownKeys2 = (value) => {
    try {
      return Reflect.ownKeys(value);
    } catch {
      return null;
    }
  };
  var hasConservativeCanvasErrorEntry = (value) => {
    if (!isRecord(value)) return false;
    const keys = ownKeys2(value);
    if (!keys || keys.some((key) => key !== "message" && key !== "error_code")) {
      return false;
    }
    const message = ownDataValue(value, "message");
    const errorCode = ownDataValue(value, "error_code");
    if (keys.includes("error_code") && errorCode === missingDataValue) {
      return false;
    }
    return typeof message === "string" && message.trim().length > 0 && message.length <= 1e3 && (errorCode === missingDataValue || typeof errorCode === "string" && errorCode.length <= 200);
  };
  var hasConservativeCanvasErrorShape = (value) => {
    if (!isRecord(value)) return false;
    const keys = ownKeys2(value);
    if (!keys || keys.length < 1 || keys.length > 2 || keys.some((key) => key !== "errors" && key !== "status")) {
      return false;
    }
    const errors = ownDataValue(value, "errors");
    if (!Array.isArray(errors) || errors.length === 0 || errors.length > 20) {
      return false;
    }
    const errorKeys = ownKeys2(errors);
    if (!errorKeys || errorKeys.length !== errors.length + 1) return false;
    if (!Array.from(
      { length: errors.length },
      (_, index) => hasConservativeCanvasErrorEntry(ownDataValue(errors, String(index)))
    ).every(Boolean)) {
      return false;
    }
    if (!keys.includes("status")) return true;
    const status2 = ownDataValue(value, "status");
    return typeof status2 === "string" && /^[a-z][a-z0-9_-]{0,99}$/u.test(status2);
  };
  var hasConservativeDisabledCourseShape = (value) => {
    if (!isRecord(value)) return false;
    let prototype;
    try {
      prototype = Object.getPrototypeOf(value);
    } catch {
      return false;
    }
    if (prototype !== Object.prototype && prototype !== null) return false;
    const keys = ownKeys2(value);
    if (!keys || keys.length !== 1 || keys[0] !== "message") return false;
    return ownDataValue(value, "message") === "That page has been disabled for this course";
  };
  var sameSearch = (left, right) => {
    const leftEntries = [...left.searchParams.entries()].sort();
    const rightEntries = [...right.searchParams.entries()].sort();
    return leftEntries.length === rightEntries.length && leftEntries.every(
      ([key, value], index) => key === rightEntries[index]?.[0] && value === rightEntries[index]?.[1]
    );
  };
  var CanvasHttp = class {
    constructor(fetcher = fetch, signal, sleep = abortableDelay) {
      this.fetcher = fetcher;
      this.signal = signal;
      this.sleep = sleep;
    }
    fetcher;
    signal;
    sleep;
    throwIfAborted() {
      if (this.signal?.aborted) throw abortError(this.signal);
    }
    async waitBeforeRetry(milliseconds) {
      const signal = this.signal;
      await this.sleep(milliseconds, signal);
      this.throwIfAborted();
    }
    async requestJson(url, context) {
      if (!isCanvasApiUrl(url)) {
        throw new CanvasResponseError("Rejected Canvas URL");
      }
      for (let attempt = 0; attempt <= MAX_RETRIES; attempt += 1) {
        this.throwIfAborted();
        let response;
        try {
          response = await this.fetcher(url, {
            method: "GET",
            credentials: "include",
            redirect: "follow",
            headers: { Accept: "application/json" },
            ...this.signal ? { signal: this.signal } : {}
          });
        } catch (error) {
          if (isAbortError(error)) throw error;
          if (!(error instanceof TypeError)) {
            throw new CanvasResponseError("Canvas request failed");
          }
          if (attempt === MAX_RETRIES) {
            throw context.boundedResourceBytes === void 0 ? new CanvasResponseError(
              "Canvas request failed after bounded retries"
            ) : new CanvasTransientError(
              "Canvas request failed after bounded retries"
            );
          }
          await this.waitBeforeRetry(250 * 2 ** attempt);
          continue;
        }
        let finalUrl;
        const discardBoundedBody = async () => {
          if (context.boundedResourceBytes === void 0) return;
          await response.body?.cancel().catch(() => {
          });
        };
        try {
          finalUrl = new URL(response.url || url);
        } catch {
          await discardBoundedBody();
          throw new CanvasResponseError("Rejected final Canvas URL");
        }
        const contentType = response.headers.get("content-type") ?? "";
        if (finalUrl.origin !== CANVAS_ORIGIN || finalUrl.username !== "" || finalUrl.password !== "" || /\/login(?:\/|$)/.test(finalUrl.pathname)) {
          await discardBoundedBody();
          throw new CanvasSessionError("Canvas session is unavailable");
        }
        if (!isCanvasApiUrl(finalUrl)) {
          await discardBoundedBody();
          throw new CanvasResponseError("Rejected final Canvas URL");
        }
        if (finalUrl.pathname !== url.pathname) {
          await discardBoundedBody();
          throw new CanvasResponseError("Rejected Canvas response path");
        }
        if (!sameSearch(finalUrl, url)) {
          await discardBoundedBody();
          throw new CanvasResponseError("Rejected Canvas response query");
        }
        if (response.status === 408 || response.status === 429 || response.status >= 500) {
          await response.body?.cancel().catch(() => {
          });
          if (attempt === MAX_RETRIES) {
            throw context.boundedResourceBytes === void 0 ? new CanvasResponseError(
              "Canvas request failed after bounded retries"
            ) : new CanvasTransientError(
              "Canvas request failed after bounded retries"
            );
          }
          await this.waitBeforeRetry(250 * 2 ** attempt);
          continue;
        }
        if (contentType.toLowerCase().includes("text/html")) {
          await discardBoundedBody();
          throw new CanvasSessionError("Canvas session is unavailable");
        }
        if (response.status === 401) {
          await discardBoundedBody();
          throw new CanvasSessionError("Canvas session is unavailable");
        }
        if ((response.status === 403 || response.status === 404) && isJsonContentType(contentType) && context.optionalCourseIndexInitial && isCourseCollectionIndex(url) && isCourseCollectionIndex(finalUrl) && url.pathname === finalUrl.pathname) {
          let errorValue;
          try {
            errorValue = await response.json();
          } catch (error) {
            if (isAbortError(error)) throw error;
            throw new CanvasResponseError("Canvas returned invalid JSON");
          }
          if (isCourseModulesIndex(url) && hasConservativeDisabledCourseShape(errorValue)) {
            throw new CanvasCourseModulesDisabledError(
              "Canvas course Modules are disabled"
            );
          }
          if (!hasConservativeCanvasErrorShape(errorValue) && !(isCoursePagesIndex(url) && hasConservativeDisabledCourseShape(errorValue))) {
            throw new CanvasResponseError(
              "Canvas returned an invalid error response"
            );
          }
          throw new CanvasCourseIndexUnavailableError(response.status);
        }
        if (response.status === 403) {
          if (context.boundedResourceBytes !== void 0) {
            await response.body?.cancel().catch(() => {
            });
            throw new CanvasResourceUnavailableError(403);
          }
          if (context.continuation) {
            throw new CanvasResponseError(
              "Unexpected Canvas continuation response"
            );
          }
          throw new CanvasSessionError("Canvas session is unavailable");
        }
        if (response.status === 404 && context.boundedResourceBytes !== void 0) {
          await response.body?.cancel().catch(() => {
          });
          throw new CanvasResourceUnavailableError(404);
        }
        if (!response.ok) {
          await discardBoundedBody();
          throw new CanvasResponseError(
            `Unexpected Canvas response: ${response.status}`
          );
        }
        if (!isJsonContentType(contentType)) {
          await discardBoundedBody();
          throw new CanvasResponseError("Canvas returned a non-JSON response");
        }
        try {
          if (context.boundedResourceBytes !== void 0) {
            return {
              value: await this.readBoundedJson(
                response,
                context.boundedResourceBytes
              ),
              response
            };
          }
          return { value: await response.json(), response };
        } catch (error) {
          if (isAbortError(error)) throw error;
          if (error instanceof CanvasResponseError) throw error;
          throw new CanvasResponseError("Canvas returned invalid JSON");
        }
      }
      throw new CanvasResponseError(
        "Canvas request failed after bounded retries"
      );
    }
    async readBoundedJson(response, maximumBytes) {
      if (!Number.isSafeInteger(maximumBytes) || maximumBytes < 1) {
        throw new CanvasResponseError("Invalid JSON body limit");
      }
      const rawLength = response.headers.get("content-length");
      if (rawLength !== null) {
        if (!/^(?:0|[1-9]\d*)$/u.test(rawLength)) {
          await response.body?.cancel().catch(() => {
          });
          throw new CanvasResponseError("Invalid Canvas JSON content length");
        }
        if (Number(rawLength) > maximumBytes) {
          await response.body?.cancel().catch(() => {
          });
          throw new CanvasBodySizeError("Canvas JSON body is too large");
        }
      }
      if (!response.body)
        throw new CanvasResponseError("Canvas returned an empty JSON body");
      const reader = response.body.getReader();
      const chunks = [];
      let total = 0;
      try {
        for (; ; ) {
          this.throwIfAborted();
          const result = await reader.read();
          if (this.signal?.aborted) {
            if (!result.done) result.value.fill(0);
            this.throwIfAborted();
          }
          if (result.done) break;
          total += result.value.byteLength;
          if (!Number.isSafeInteger(total) || total > maximumBytes) {
            result.value.fill(0);
            throw new CanvasBodySizeError("Canvas JSON body is too large");
          }
          chunks.push(result.value);
        }
        const bytes = new Uint8Array(total);
        let offset = 0;
        for (const chunk of chunks) {
          bytes.set(chunk, offset);
          offset += chunk.byteLength;
        }
        reader.releaseLock();
        try {
          return JSON.parse(
            new TextDecoder("utf-8", { fatal: true }).decode(bytes)
          );
        } finally {
          bytes.fill(0);
          chunks.forEach((chunk) => chunk.fill(0));
          chunks.length = 0;
        }
      } catch (error) {
        try {
          await reader.cancel();
        } catch {
        }
        chunks.forEach((chunk) => chunk.fill(0));
        chunks.length = 0;
        throw error;
      }
    }
    json(url) {
      return this.requestJson(url, {
        optionalCourseIndexInitial: false,
        continuation: false
      });
    }
    jsonBoundedResource(url, maximumBytes) {
      return this.requestJson(url, {
        optionalCourseIndexInitial: false,
        continuation: false,
        boundedResourceBytes: maximumBytes
      });
    }
    fetchAll(url) {
      let initial = true;
      return fetchAllPages(async (next) => {
        const isInitial = initial;
        initial = false;
        const page = await this.requestJson(next, {
          optionalCourseIndexInitial: isInitial && isCourseCollectionIndex(url),
          continuation: !isInitial
        });
        if (isInitial && isCourseModulesIndex(url) && hasConservativeDisabledCourseShape(page.value)) {
          throw new CanvasCourseModulesDisabledError(
            "Canvas course Modules are disabled"
          );
        }
        return page;
      }, url);
    }
  };

  // src/canvas/page-links.ts
  var PAGE_TITLE_MAX_CHARACTERS = 500;
  var ENCODED_SEPARATOR = /%(?:2f|5c)/iu;
  var hasAsciiUrlWhitespaceOrControl = (value) => Array.from(value).some((character) => {
    const code = character.codePointAt(0) ?? 0;
    return code <= 32 || code === 127;
  });
  var invalidPage = () => {
    throw new CanvasResponseError("Canvas returned an invalid page");
  };
  var exactCanvasPage = (value) => {
    if (typeof value !== "object" || value === null || Array.isArray(value)) {
      return invalidPage();
    }
    let title;
    let body;
    try {
      title = Object.getOwnPropertyDescriptor(value, "title");
      body = Object.getOwnPropertyDescriptor(value, "body");
    } catch {
      return invalidPage();
    }
    if (!title || !("value" in title) || typeof title.value !== "string" || title.value.length > PAGE_TITLE_MAX_CHARACTERS || !body || !("value" in body) || typeof body.value !== "string") {
      return invalidPage();
    }
    return { title: title.value, body: body.value };
  };
  var exactPositiveId = (value) => {
    if (!Number.isSafeInteger(value) || value < 1) {
      throw new TypeError("Invalid Canvas course ID");
    }
    return value;
  };
  var pageLinkedFileIds = (body, courseId) => {
    const selectedCourseId = exactPositiveId(courseId);
    const ids = /* @__PURE__ */ new Set();
    const expectedPath = new RegExp(
      `^/courses/${selectedCourseId}/files/([1-9]\\d*)(?:/download)?$`,
      "u"
    );
    const document3 = new DOMParser().parseFromString(body, "text/html");
    for (const anchor of document3.querySelectorAll("a[href]")) {
      const href = anchor.getAttribute("href");
      if (href === null || href !== href.trim() || hasAsciiUrlWhitespaceOrControl(href) || href.includes("\\") || ENCODED_SEPARATOR.test(href) || !href.startsWith("/courses/") && !href.startsWith(`${CANVAS_ORIGIN}/`)) {
        continue;
      }
      const rawCanvasPath = href.startsWith("/") ? href : href.slice(CANVAS_ORIGIN.length);
      let url;
      try {
        url = new URL(href, CANVAS_ORIGIN);
      } catch {
        continue;
      }
      if (url.origin !== CANVAS_ORIGIN || url.username !== "" || url.password !== "" || url.hash !== "") {
        continue;
      }
      const match = expectedPath.exec(url.pathname);
      if (!match || rawCanvasPath !== (match[0].endsWith("/download") ? match[0] : `${match[0]}?wrap=1`) || (match[0].endsWith("/download") ? url.search !== "" : url.search !== "?wrap=1")) {
        continue;
      }
      const fileId = Number(match[1]);
      if (Number.isSafeInteger(fileId) && fileId > 0) ids.add(fileId);
    }
    return [...ids].sort((left, right) => left - right);
  };

  // src/canvas/discovery.ts
  var PilotSizeError = class extends Error {
  };
  var isRecord2 = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
  var own = (value, key) => Object.hasOwn(value, key) ? value[key] : void 0;
  var positiveId2 = (value, context = "ID") => {
    if (typeof value !== "number" || !Number.isSafeInteger(value) || value <= 0) {
      throw new TypeError(`Invalid ${context}`);
    }
    return value;
  };
  var position = (value) => {
    if (value === void 0) return 0;
    if (typeof value !== "number" || !Number.isSafeInteger(value)) {
      throw new TypeError("Invalid position");
    }
    return value;
  };
  var moduleIndent = (value) => {
    if (value === void 0) return 0;
    if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 0 || value > 5) {
      throw new TypeError("Invalid module item indent");
    }
    return value;
  };
  var optionalText = (value, fallback, context) => {
    if (value === void 0 || value === null) return fallback;
    if (typeof value !== "string") throw new TypeError(`Invalid ${context}`);
    const trimmed = value.trim();
    return trimmed ? trimmed.slice(0, 500) : fallback;
  };
  var requiredText = (value, context) => {
    if (typeof value !== "string" || !value.trim()) {
      throw new TypeError(`Invalid ${context}`);
    }
    return value.trim();
  };
  var pageToken = (value) => {
    if (typeof value !== "string" || !/^[a-zA-Z0-9_-]{1,255}$/.test(value)) {
      throw new TypeError("Invalid page token");
    }
    return value;
  };
  var lexicographic = (left, right) => left < right ? -1 : left > right ? 1 : 0;
  var strictCanvasFileUrl = (value, id) => {
    if (typeof value !== "string") throw new TypeError("Invalid file URL");
    let url;
    try {
      url = new URL(value);
    } catch {
      throw new TypeError("Invalid file URL");
    }
    if (url.origin !== CANVAS_ORIGIN || url.protocol !== "https:" || url.username !== "" || url.password !== "" || url.hash !== "" || url.pathname !== `/files/${id}/download`) {
      throw new TypeError("Rejected file URL");
    }
    return url.href;
  };
  var strictExternalUrl = (value) => {
    if (typeof value !== "string") throw new TypeError("Invalid external URL");
    let url;
    try {
      url = new URL(value);
    } catch {
      throw new TypeError("Invalid external URL");
    }
    if (url.protocol !== "https:" || url.username !== "" || url.password !== "") {
      throw new TypeError("Rejected external URL");
    }
    return url.href;
  };
  var normalizeFile = (value) => {
    if (!isRecord2(value)) throw new TypeError("Invalid file record");
    const id = positiveId2(own(value, "id"), "file ID");
    const displayName = own(value, "display_name");
    const filename = own(value, "filename");
    const fallbackName = optionalText(filename, `file-${id}`, "filename");
    const title = optionalText(displayName, fallbackName, "file display name");
    const rawFolderId = own(value, "folder_id");
    const folderId = rawFolderId === void 0 || rawFolderId === null ? null : positiveId2(rawFolderId, "folder ID");
    const rawSize = own(value, "size");
    if (typeof rawSize !== "number" || !Number.isSafeInteger(rawSize) || rawSize < 0) {
      throw new TypeError("Invalid file size");
    }
    const size2 = rawSize;
    return {
      id,
      folderId,
      title,
      size: size2,
      sourceUrl: strictCanvasFileUrl(own(value, "url"), id)
    };
  };
  var normalizePage = (value) => {
    if (!isRecord2(value)) throw new TypeError("Invalid page record");
    const token = pageToken(own(value, "url"));
    const rawPageId = own(value, "page_id");
    return {
      token,
      pageId: rawPageId === void 0 || rawPageId === null ? null : positiveId2(rawPageId, "page ID"),
      title: optionalText(own(value, "title"), token, "page title")
    };
  };
  var normalizeFolderMap = (values) => {
    const folders = /* @__PURE__ */ new Map();
    for (const value of values) {
      if (!isRecord2(value)) throw new TypeError("Invalid folder record");
      const id = positiveId2(own(value, "id"), "folder ID");
      const rawFullName = own(value, "full_name");
      if (typeof rawFullName !== "string" || !rawFullName.trim()) {
        throw new TypeError("Invalid folder path");
      }
      const fullName = rawFullName.trim();
      const segments = fullName.split("/");
      if (segments.some((segment) => !segment.trim())) {
        throw new TypeError("Invalid folder path");
      }
      const relative = segments.slice(1);
      const prior = folders.get(id);
      if (prior && prior.join("/") !== relative.join("/")) {
        throw new TypeError("Conflicting folder record");
      }
      folders.set(id, relative);
    }
    return folders;
  };
  var SharedRequestScheduler = class {
    active = 0;
    queue = [];
    schedule(owner, operation) {
      if (owner.failure) return Promise.reject(owner.failure.error);
      return new Promise((resolve, reject) => {
        this.queue.push({
          owner,
          operation,
          resolve: (value) => resolve(value),
          reject
        });
        this.drain();
      });
    }
    latch(owner, error) {
      if (!owner.failure) {
        owner.failure = {
          error: error instanceof Error || error instanceof DOMException ? error : new TypeError("Canvas discovery failed")
        };
        owner.abort?.(owner.failure.error);
      }
      const failure = owner.failure.error;
      const pending = [];
      for (const job of this.queue) {
        if (job.owner === owner) job.reject(failure);
        else pending.push(job);
      }
      this.queue = pending;
      return failure;
    }
    drain() {
      while (this.active < MAX_CONCURRENCY && this.queue.length > 0) {
        const job = this.queue.shift();
        if (job.owner.failure) {
          job.reject(job.owner.failure.error);
          continue;
        }
        this.active += 1;
        void Promise.resolve().then(job.operation).then(job.resolve, (error) => {
          job.reject(this.latch(job.owner, error));
        }).finally(() => {
          this.active -= 1;
          this.drain();
        });
      }
    }
  };
  var sharedRequestScheduler = new SharedRequestScheduler();
  var DiscoveryRun = class {
    owner;
    constructor(abort) {
      this.owner = { ...abort ? { abort } : {} };
    }
    one(operation) {
      return sharedRequestScheduler.schedule(this.owner, operation);
    }
    async all(operations) {
      const settled = await Promise.allSettled(
        operations.map((operation) => this.one(operation))
      );
      if (this.owner.failure) throw this.owner.failure.error;
      return settled.map((result) => {
        if (result.status === "rejected") throw result.reason;
        return result.value;
      });
    }
  };
  var fetchOptionalIndex = async (operation) => {
    try {
      return await operation();
    } catch (error) {
      if (error instanceof CanvasCourseIndexUnavailableError) return null;
      throw error;
    }
  };
  var normalizeItem = (value) => {
    if (!isRecord2(value)) throw new TypeError("Invalid module item");
    const id = positiveId2(own(value, "id"), "module item ID");
    const type = requiredText(own(value, "type"), "module item type");
    let resourceKey;
    if (type === "File") {
      resourceKey = `file:${positiveId2(own(value, "content_id"), "file ID")}`;
    } else if (type === "Page") {
      resourceKey = `page:${pageToken(own(value, "page_url"))}`;
    } else if (type === "ExternalUrl") {
      strictExternalUrl(own(value, "external_url"));
      resourceKey = `external:${id}`;
    } else {
      resourceKey = `unsupported:${id}`;
    }
    return {
      item: {
        id,
        title: optionalText(own(value, "title"), `Item ${id}`, "item title"),
        position: position(own(value, "position")),
        indent: moduleIndent(own(value, "indent")),
        resourceKey,
        type
      },
      raw: value
    };
  };
  var loadModules = async (http, run, courseId) => {
    const initial = await run.one(async () => {
      try {
        return {
          moduleDiscovery: "available",
          rawModules: await http.fetchAll(
            canvasEndpoint({ type: "courseModules", courseId })
          )
        };
      } catch (error) {
        if (error instanceof CanvasCourseModulesDisabledError) {
          return { moduleDiscovery: "disabled", rawModules: [] };
        }
        throw error;
      }
    });
    if (initial.moduleDiscovery === "disabled") {
      return { moduleDiscovery: "disabled", parsedModules: [] };
    }
    const descriptors = initial.rawModules.map((value) => {
      if (!isRecord2(value)) throw new TypeError("Invalid module record");
      const id = positiveId2(own(value, "id"), "module ID");
      const inline = own(value, "items");
      if (inline !== void 0 && inline !== null && !Array.isArray(inline)) {
        throw new TypeError("Invalid inline module items");
      }
      return { value, id, inline: Array.isArray(inline) ? inline : null };
    });
    const loaded = await run.all(
      descriptors.map(({ value, id, inline }) => async () => {
        const rawItems = inline ?? await http.fetchAll(
          canvasEndpoint({ type: "moduleItems", courseId, moduleId: id })
        );
        const normalized = rawItems.map(normalizeItem);
        normalized.sort(
          (left, right) => left.item.position - right.item.position || left.item.id - right.item.id
        );
        return {
          module: {
            id,
            name: optionalText(own(value, "name"), `Module ${id}`, "module name"),
            position: position(own(value, "position")),
            items: normalized.map(({ item }) => item)
          },
          rawItems: normalized.map(({ raw }) => raw)
        };
      })
    );
    loaded.sort(
      (left, right) => left.module.position - right.module.position || left.module.id - right.module.id
    );
    const ids = /* @__PURE__ */ new Set();
    for (const { module } of loaded) {
      if (ids.has(module.id)) throw new TypeError("Duplicate module ID");
      ids.add(module.id);
    }
    return { moduleDiscovery: "available", parsedModules: loaded };
  };
  var sameFile = (left, right) => left.folderId === right.folderId && left.title === right.title && left.size === right.size && left.sourceUrl === right.sourceUrl;
  var samePage = (left, right) => left.pageId === right.pageId && left.title === right.title;
  var addFile = (files, value) => {
    const normalized = normalizeFile(value);
    const prior = files.get(normalized.id);
    if (prior && !sameFile(prior, normalized)) {
      throw new TypeError("Conflicting file record");
    }
    files.set(normalized.id, prior ?? normalized);
  };
  var addPage = (pages, value) => {
    const normalized = normalizePage(value);
    const prior = pages.get(normalized.token);
    if (prior && !samePage(prior, normalized)) {
      throw new TypeError("Conflicting page record");
    }
    pages.set(normalized.token, prior ?? normalized);
  };
  var insertSuffixAt = (path, segmentIndex, suffix) => {
    const segments = path.split("/");
    const value = segments[segmentIndex];
    if (value === void 0) throw new TypeError("Unsafe archive path");
    const dot = value.lastIndexOf(".");
    const isFilename = segmentIndex === segments.length - 1;
    const hasExtension = isFilename && dot > 0 && value.length - dot <= 16;
    const stem = hasExtension ? value.slice(0, dot) : value;
    const extension = hasExtension ? value.slice(dot) : "";
    const marker2 = `--${suffix}`;
    const stemBudget = Math.max(1, 100 - marker2.length - extension.length);
    const boundedStem = Array.from(stem).slice(0, stemBudget).join("");
    segments[segmentIndex] = `${boundedStem}${marker2}${extension}`;
    return safeArchivePath(...segments);
  };
  var conflictSegment = (candidate, other) => {
    const candidateCanonical = canonicalArchivePath(candidate);
    const otherCanonical = canonicalArchivePath(other);
    if (candidateCanonical === otherCanonical) {
      return candidate.split("/").length - 1;
    }
    if (candidateCanonical.startsWith(`${otherCanonical}/`)) {
      return other.split("/").length - 1;
    }
    if (otherCanonical.startsWith(`${candidateCanonical}/`)) {
      return candidate.split("/").length - 1;
    }
    return null;
  };
  var allocatePaths = (drafts) => {
    const ordered = [...drafts].sort(
      (left, right) => lexicographic(left.key, right.key)
    );
    const assigned = [];
    return ordered.map(({ preferredPath, disambiguator, ...resource }, index) => {
      if (preferredPath === null) return { ...resource, archivePath: null };
      let archivePath = preferredPath;
      let attempt = 1;
      for (; ; ) {
        let segment = null;
        for (const other of assigned) {
          segment = conflictSegment(archivePath, other);
          if (segment !== null) break;
        }
        if (segment === null) {
          for (const future of ordered.slice(index + 1)) {
            if (future.preferredPath === null) continue;
            segment = conflictSegment(archivePath, future.preferredPath);
            if (segment !== null) break;
          }
        }
        if (segment === null) break;
        archivePath = insertSuffixAt(
          archivePath,
          segment,
          attempt === 1 ? disambiguator : `${disambiguator}-${attempt}`
        );
        attempt += 1;
      }
      assigned.push(archivePath);
      return { ...resource, archivePath };
    });
  };
  var digestToken = (value) => {
    let hash = 2166136261;
    for (const character of value) {
      hash ^= character.codePointAt(0) ?? 0;
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
  };
  var validateCourse2 = (course) => {
    if (!isRecord2(course)) throw new TypeError("Invalid course");
    const id = positiveId2(own(course, "id"), "course ID");
    const name = requiredText(own(course, "name"), "course name");
    const courseCode = own(course, "courseCode");
    const workflowState = own(course, "workflowState");
    const concluded = own(course, "concluded");
    if (typeof courseCode !== "string" || typeof workflowState !== "string" || typeof concluded !== "boolean") {
      throw new TypeError("Invalid course");
    }
    return { id, name, courseCode, workflowState, concluded };
  };
  var freezePlan2 = (plan) => {
    const fallbackKeys = new Set(plan.folderPathFallbackKeys);
    if (fallbackKeys.size !== plan.folderPathFallbackKeys.length) {
      throw new TypeError("Invalid folder fallback keys");
    }
    for (const key of fallbackKeys) {
      const resource = plan.resources.find((candidate) => candidate.key === key);
      if (resource?.kind !== "file" || resource.archivePath === null || !resource.archivePath.startsWith("files/unfiled/")) {
        throw new TypeError("Invalid folder fallback keys");
      }
    }
    Object.freeze(plan.course);
    for (const module of plan.modules) {
      for (const item of module.items) Object.freeze(item);
      Object.freeze(module.items);
      Object.freeze(module);
    }
    for (const resource of plan.resources) Object.freeze(resource);
    Object.freeze(plan.modules);
    Object.freeze(plan.resources);
    Object.freeze(plan.folderPathFallbackKeys);
    return Object.freeze(plan);
  };
  function assertCoursePlanSizes(plan) {
    if (!isRecord2(plan) || !Array.isArray(own(plan, "resources"))) {
      throw new PilotSizeError("The plan contains an invalid resource");
    }
    let total = 0;
    for (const resource of plan.resources) {
      if (!isRecord2(resource)) {
        throw new PilotSizeError("The plan contains an invalid resource");
      }
      const kind = own(resource, "kind");
      if (kind !== "file" && kind !== "page" && kind !== "external" && kind !== "unsupported") {
        throw new PilotSizeError("The plan contains an invalid resource");
      }
      if (kind !== "file") continue;
      if (!Object.hasOwn(resource, "advertisedBytes")) {
        throw new PilotSizeError("The plan contains an invalid resource");
      }
      const size2 = own(resource, "advertisedBytes");
      if (size2 === null) continue;
      if (typeof size2 !== "number" || !Number.isSafeInteger(size2) || size2 < 0) {
        throw new PilotSizeError("A file has invalid size");
      }
      if (size2 > Number.MAX_SAFE_INTEGER - total) {
        throw new PilotSizeError("Advertised size total overflow");
      }
      total += size2;
    }
    const declaredTotal = own(plan, "advertisedBytes");
    if (typeof declaredTotal !== "number" || !Number.isSafeInteger(declaredTotal) || declaredTotal !== total) {
      throw new PilotSizeError("Advertised size total does not match the plan");
    }
  }
  async function discoverCoursePlan(http, selectedCourse, options = {}) {
    const course = validateCourse2(selectedCourse);
    const run = new DiscoveryRun(options.abort);
    const { moduleDiscovery: moduleDiscovery3, parsedModules } = await loadModules(
      http,
      run,
      course.id
    );
    const indexes = await run.all([
      () => fetchOptionalIndex(
        () => http.fetchAll(
          canvasEndpoint({ type: "courseFiles", courseId: course.id })
        )
      ),
      () => fetchOptionalIndex(
        () => http.fetchAll(
          canvasEndpoint({ type: "courseFolders", courseId: course.id })
        )
      ),
      () => fetchOptionalIndex(
        () => http.fetchAll(
          canvasEndpoint({ type: "coursePages", courseId: course.id })
        )
      )
    ]);
    const rawFiles = indexes[0];
    const rawFolders = indexes[1];
    const rawPages = indexes[2];
    const folders = rawFolders === null ? /* @__PURE__ */ new Map() : normalizeFolderMap(rawFolders);
    const files = /* @__PURE__ */ new Map();
    for (const value of rawFiles ?? []) addFile(files, value);
    const pages = /* @__PURE__ */ new Map();
    for (const value of rawPages ?? []) addPage(pages, value);
    const linkedFileIds = /* @__PURE__ */ new Set();
    const linkedPages = /* @__PURE__ */ new Map();
    const extraDrafts = /* @__PURE__ */ new Map();
    for (const { module, rawItems } of parsedModules) {
      for (let index = 0; index < module.items.length; index += 1) {
        const item = module.items[index];
        const raw = rawItems[index];
        if (item.type === "File") {
          linkedFileIds.add(positiveId2(own(raw, "content_id"), "file ID"));
        } else if (item.type === "Page") {
          const token = pageToken(own(raw, "page_url"));
          linkedPages.set(
            token,
            optionalText(own(raw, "title"), token, "item title")
          );
        } else if (item.type === "ExternalUrl") {
          const sourceUrl = strictExternalUrl(own(raw, "external_url"));
          const draft = {
            key: item.resourceKey,
            kind: "external",
            title: item.title,
            sourceId: String(item.id),
            archivePath: null,
            advertisedBytes: 0,
            sourceUrl,
            preferredPath: null,
            disambiguator: `external-${item.id}`
          };
          const prior = extraDrafts.get(draft.key);
          if (prior && prior.sourceUrl !== sourceUrl) {
            throw new TypeError("Conflicting external resource");
          }
          extraDrafts.set(draft.key, prior ?? draft);
        } else {
          const draft = {
            key: item.resourceKey,
            kind: "unsupported",
            title: item.title,
            sourceId: String(item.id),
            archivePath: null,
            advertisedBytes: 0,
            sourceUrl: null,
            preferredPath: null,
            disambiguator: `unsupported-${item.id}`
          };
          extraDrafts.set(draft.key, extraDrafts.get(draft.key) ?? draft);
        }
      }
    }
    for (const [token, title] of linkedPages) {
      if (!pages.has(token)) pages.set(token, { token, pageId: null, title });
    }
    const pageFileIds = await run.all(
      [...pages.keys()].map((token) => async () => {
        try {
          const detail = await http.jsonBoundedResource(
            canvasEndpoint({
              type: "coursePage",
              courseId: course.id,
              pageUrl: token
            }),
            CANVAS_PAGE_JSON_MAX_BYTES
          );
          const page = exactCanvasPage(detail.value);
          return pageLinkedFileIds(page.body, course.id);
        } catch (error) {
          if (error instanceof CanvasBodySizeError || error instanceof CanvasResourceUnavailableError && (error.status === 403 || error.status === 404)) {
            return [];
          }
          throw error;
        }
      })
    );
    for (const ids of pageFileIds) {
      for (const id of ids) linkedFileIds.add(id);
    }
    await run.all(
      [...linkedFileIds].filter((id) => !files.has(id)).map((id) => async () => {
        let detail;
        try {
          detail = await http.jsonBoundedResource(
            canvasEndpoint({
              type: "courseFile",
              courseId: course.id,
              fileId: id
            }),
            CANVAS_PAGE_JSON_MAX_BYTES
          );
        } catch (error) {
          if (error instanceof CanvasResourceUnavailableError && (error.status === 403 || error.status === 404)) {
            files.set(id, {
              id,
              folderId: null,
              title: `file-${id}`,
              size: null,
              sourceUrl: new URL(
                `/courses/${course.id}/files/${id}/download`,
                CANVAS_ORIGIN
              ).href
            });
            return;
          }
          throw error;
        }
        if (!isRecord2(detail.value) || positiveId2(own(detail.value, "id"), "file ID") !== id) {
          throw new TypeError("Mismatched file metadata");
        }
        addFile(files, detail.value);
      })
    );
    const drafts = [...extraDrafts.values()];
    const folderFallbackDraftKeys = /* @__PURE__ */ new Set();
    for (const file of files.values()) {
      const key = `file:${file.id}`;
      let folderSegments;
      if (rawFolders === null) {
        folderSegments = ["unfiled"];
        folderFallbackDraftKeys.add(key);
      } else if (file.folderId === null) {
        folderSegments = [];
      } else {
        const resolved = folders.get(file.folderId);
        if (resolved === void 0) {
          folderSegments = ["unfiled"];
          folderFallbackDraftKeys.add(key);
        } else {
          folderSegments = resolved;
        }
      }
      drafts.push({
        key,
        kind: "file",
        title: file.title,
        sourceId: String(file.id),
        archivePath: null,
        advertisedBytes: file.size,
        sourceUrl: file.sourceUrl,
        preferredPath: safeArchivePath("files", ...folderSegments, file.title),
        disambiguator: `file-${file.id}`
      });
    }
    for (const page of pages.values()) {
      drafts.push({
        key: `page:${page.token}`,
        kind: "page",
        title: page.title,
        sourceId: page.token,
        archivePath: null,
        advertisedBytes: 0,
        sourceUrl: null,
        preferredPath: safeArchivePath("pages", `${page.token}.html`),
        disambiguator: `page-${page.pageId ?? digestToken(page.token)}`
      });
    }
    const resources = allocatePaths(drafts);
    const folderPathFallbackKeys = resources.filter((resource) => folderFallbackDraftKeys.has(resource.key)).map((resource) => resource.key);
    let advertisedBytes = 0;
    for (const resource of resources) {
      if (resource.kind !== "file" || resource.advertisedBytes === null) continue;
      if (!Number.isSafeInteger(resource.advertisedBytes) || resource.advertisedBytes < 0) {
        continue;
      }
      if (resource.advertisedBytes > Number.MAX_SAFE_INTEGER - advertisedBytes) {
        throw new PilotSizeError("Advertised size total overflow");
      }
      advertisedBytes += resource.advertisedBytes;
    }
    const plan = {
      course,
      moduleDiscovery: moduleDiscovery3,
      modules: parsedModules.map(({ module }) => module),
      resources,
      folderPathFallbackKeys,
      advertisedBytes
    };
    assertCoursePlanSizes(plan);
    return freezePlan2(plan);
  }

  // src/canvas/session.ts
  async function assertCurrentUser(http) {
    await http.json(canvasEndpoint({ type: "currentUser" }));
  }
  var isRecord3 = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
  function normalizeAccessibleCourses(active, completed) {
    const byId = /* @__PURE__ */ new Map();
    for (const value of [...active, ...completed]) {
      if (!isRecord3(value)) continue;
      const id = value.id;
      if (typeof id !== "number" || !Number.isSafeInteger(id) || id <= 0) {
        continue;
      }
      byId.set(id, {
        id,
        name: typeof value.name === "string" && value.name.trim() || `Course ${id}`,
        courseCode: typeof value.course_code === "string" && value.course_code.trim() || "",
        workflowState: typeof value.workflow_state === "string" ? value.workflow_state : "unknown",
        concluded: value.concluded === true
      });
    }
    return [...byId.values()].sort((a, b) => a.name.localeCompare(b.name));
  }
  async function listAccessibleCourses(http, options = {}) {
    let firstError;
    const request = (enrollmentState) => http.fetchAll(canvasEndpoint({ type: "courses", enrollmentState })).catch((error) => {
      firstError ??= error instanceof Error || error instanceof DOMException ? error : new TypeError("Canvas course listing failed");
      options.abort?.(firstError);
      throw firstError;
    });
    const settled = await Promise.allSettled([
      request("active"),
      request("completed")
    ]);
    if (firstError) throw firstError;
    const values = settled.map((result) => {
      if (result.status === "rejected") throw result.reason;
      return result.value;
    });
    return normalizeAccessibleCourses(values[0], values[1]);
  }

  // src/archive/course-pages.ts
  var status = (resource) => `<span class="resource-status status-${resource.status}">${escapeHtml(resource.status)}</span>`;
  var compare = (left, right) => left < right ? -1 : left > right ? 1 : 0;
  var references = (resource) => resource.moduleReferences.length === 0 ? "" : ` <span>Modules: ${resource.moduleReferences.map(escapeHtml).join(", ")}</span>`;
  var size = (resource) => {
    const bytes = resource.actualBytes ?? resource.advertisedBytes;
    return bytes === null ? "" : ` <span>${bytes} bytes</span>`;
  };
  var availability = (resource) => resource.availableInPart === null ? "" : ` <span class="resource-part">Available in Part ${resource.availableInPart}</span>`;
  var row = (pagePath, resource, title = resource.title, indent = 0, details = "") => {
    let label = `<span>${escapeHtml(title)}</span>`;
    if (resource.status === "success" && resource.archivePath !== null)
      label = `<a href="${relativeArchiveHref(pagePath, resource.archivePath)}">${escapeHtml(title)}</a>`;
    else if (resource.status === "external" && resource.externalHref !== null)
      label = `<a href="${escapeHtml(resource.externalHref)}" rel="noopener noreferrer">${escapeHtml(title)} (external)</a>`;
    return `<li class="module-indent-${indent}">${label} ${status(resource)}${availability(resource)}${details}</li>`;
  };
  var shell = (model, path, kind, title, contentHtml, combinedHomeHref) => renderArchiveShell({
    pagePath: path,
    pageKind: kind,
    title,
    course: model.manifest.course,
    combinedHomeHref,
    contentHtml: `<p class="archive-part">Part ${model.manifest.part.index} of ${model.manifest.part.total}</p>${contentHtml}`
  });
  var renderCoursePages = (model, options = {}) => {
    const combined = options.combinedHomeHref ?? null;
    const modules = model.modules.map(
      (module) => `<section class="module"><h2>${escapeHtml(module.name)}</h2><ol>${module.items.map((item) => item.resource === null ? `<li class="module-indent-${item.indent}"><span>${escapeHtml(item.title)}</span> <span class="resource-status">unsupported</span></li>` : row("modules.html", item.resource, item.title, item.indent)).join("")}</ol></section>`
    ).join("");
    const pages = model.resources.filter((resource) => resource.kind === "page").sort(
      (left, right) => compare(left.title.toLowerCase(), right.title.toLowerCase()) || compare(left.archivePath ?? "", right.archivePath ?? "")
    ).map(
      (resource) => row("pages.html", resource, resource.title, 0, references(resource))
    ).join("");
    const files = model.resources.filter((resource) => resource.kind === "file").sort(
      (left, right) => compare(left.archivePath ?? left.title, right.archivePath ?? right.title)
    ).map(
      (resource) => row(
        "files.html",
        resource,
        resource.title,
        0,
        `${size(resource)}${references(resource)}`
      )
    ).join("");
    const totals = model.manifest.totals;
    const modulesUnavailable = model.manifest.moduleDiscovery === "disabled";
    const modulesNotice = '<aside class="panel modules-unavailable"><h2>Module navigation unavailable</h2><p>Module navigation is unavailable; GradPack archived accessible pages and files instead.</p></aside>';
    const unfiledNotice = model.manifest.courseTotals.folderPathFallbackCount === 0 ? "" : `<aside class="panel unfiled-notice"><h2>Canvas folder placement unavailable</h2><p>${model.manifest.courseTotals.folderPathFallbackCount} file(s) were saved under <code>files/unfiled/</code> because Canvas did not provide their folder placement.</p></aside>`;
    const home = `<header class="archive-header"><p class="eyebrow">GradPack offline archive</p><h1>${escapeHtml(model.manifest.course.name)}</h1><p>Browse this saved course without Canvas.</p></header><section class="panel"><h2>Course content</h2><p><a href="modules.html">View modules</a>, <a href="pages.html">pages</a>, <a href="files.html">files</a>, or <a href="status.html">archive status</a>.</p></section>${modulesUnavailable ? modulesNotice : ""}${unfiledNotice}`;
    const outcomes = model.resources.map((resource) => row("status.html", resource, resource.title)).join("");
    const statusPage = `<h1>Archive status</h1><h2>This part</h2><section class="status-grid"><div class="panel"><strong>${totals.success}</strong><br>Saved</div><div class="panel"><strong>${totals.failed}</strong><br>Failed</div><div class="panel"><strong>${totals.unavailable}</strong><br>Unavailable</div><div class="panel"><strong>${totals.unsupported}</strong><br>Unsupported</div><div class="panel"><strong>${totals.external}</strong><br>External</div></section><section class="panel"><h2>Complete course resources</h2><p>${model.manifest.courseTotals.resourceCount} resource(s) across ${model.manifest.part.total} part(s); ${model.manifest.courseTotals.advertisedBytes} advertised byte(s).</p></section>${modulesUnavailable ? modulesNotice : ""}${unfiledNotice}<h2>Resource outcomes</h2><ul class="resource-list">${outcomes || "<li>No resources were listed.</li>"}</ul><p><a href="manifest.json">View technical manifest</a></p><aside class="responsibility-notice"><h2>Course-material responsibility</h2><p>You are responsible for applicable copyright, licensing, confidentiality, and course-material restrictions.</p></aside>`;
    return /* @__PURE__ */ new Map([
      [
        "files.html",
        shell(
          model,
          "files.html",
          "files",
          "Files",
          `<h1>Files</h1><ul class="resource-list">${files || "<li>No files were listed.</li>"}</ul>`,
          combined
        )
      ],
      [
        "index.html",
        shell(
          model,
          "index.html",
          "home",
          model.manifest.course.name,
          home,
          combined
        )
      ],
      [
        "modules.html",
        shell(
          model,
          "modules.html",
          "modules",
          "Modules",
          `<h1>Modules</h1>${modulesUnavailable ? modulesNotice : modules || "<p>No modules were listed.</p>"}`,
          combined
        )
      ],
      [
        "pages.html",
        shell(
          model,
          "pages.html",
          "pages",
          "Pages",
          `<h1>Pages</h1><ul class="resource-list">${pages || "<li>No pages were listed.</li>"}</ul>`,
          combined
        )
      ],
      [
        "status.html",
        shell(
          model,
          "status.html",
          "status",
          "Archive status",
          statusPage,
          combined
        )
      ]
    ]);
  };

  // src/archive/navigation-model.ts
  var safeExternalHref2 = (value) => {
    if (value === null) return null;
    let url;
    try {
      url = new URL(value);
    } catch {
      return null;
    }
    return url.protocol === "https:" && url.username === "" && url.password === "" && url.search === "" && url.hash === "" ? url.href : null;
  };
  function buildArchiveNavigationModel(plan, outcomes, createdAt, partPlan) {
    const snapshot = snapshotArchiveData(plan, outcomes, createdAt, partPlan);
    const manifest = buildManifestFromSnapshot(snapshot);
    const sourceByKey = new Map(
      snapshot.plan.resources.map((resource) => [
        resource.key,
        resource.sourceUrl
      ])
    );
    const references2 = /* @__PURE__ */ new Map();
    for (const module of snapshot.plan.modules) {
      for (const item of module.items) {
        if (item.resourceKey === null) continue;
        const current = references2.get(item.resourceKey) ?? [];
        if (!current.includes(module.name)) current.push(module.name);
        references2.set(item.resourceKey, current);
      }
    }
    const localByKey = new Map(
      manifest.resources.map((resource) => [resource.key, resource])
    );
    const resources = manifest.resourceCatalog.map((catalog) => {
      const resource = localByKey.get(catalog.key);
      return Object.freeze({
        key: catalog.key,
        title: catalog.title,
        kind: catalog.kind,
        status: resource?.status ?? "other-part",
        archivePath: resource?.archivePath ?? null,
        availableInPart: resource ? null : catalog.partIndex,
        folderPathFallback: catalog.folderPathFallback,
        externalHref: resource?.status === "external" ? safeExternalHref2(sourceByKey.get(resource.key) ?? null) : null,
        advertisedBytes: resource?.advertisedBytes ?? null,
        actualBytes: resource?.actualBytes ?? null,
        failureCategory: resource?.failureCategory ?? null,
        moduleReferences: Object.freeze([...references2.get(catalog.key) ?? []])
      });
    });
    const lookup = new Map(resources.map((resource) => [resource.key, resource]));
    const modules = snapshot.plan.modules.map(
      (module) => Object.freeze({
        id: module.id,
        name: module.name,
        position: module.position,
        items: Object.freeze(
          module.items.map(
            (item) => Object.freeze({
              id: item.id,
              title: item.title,
              position: item.position,
              indent: item.indent,
              resource: item.resourceKey === null ? null : lookup.get(item.resourceKey) ?? null
            })
          )
        )
      })
    );
    return Object.freeze({
      manifest,
      modules: Object.freeze(modules),
      resources: Object.freeze(resources),
      resourceByKey: (key) => lookup.get(key) ?? null
    });
  }

  // node_modules/.pnpm/dompurify@3.4.13/node_modules/dompurify/dist/purify.es.mjs
  function _arrayLikeToArray(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
    return n;
  }
  function _arrayWithHoles(r) {
    if (Array.isArray(r)) return r;
  }
  function _iterableToArrayLimit(r, l) {
    var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
    if (null != t) {
      var e, n, i2, u, a = [], f = true, o = false;
      try {
        if (i2 = (t = t.call(r)).next, 0 === l) ;
        else for (; !(f = (e = i2.call(t)).done) && (a.push(e.value), a.length !== l); f = true) ;
      } catch (r2) {
        o = true, n = r2;
      } finally {
        try {
          if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return;
        } finally {
          if (o) throw n;
        }
      }
      return a;
    }
  }
  function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  function _slicedToArray(r, e) {
    return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest();
  }
  function _unsupportedIterableToArray(r, a) {
    if (r) {
      if ("string" == typeof r) return _arrayLikeToArray(r, a);
      var t = {}.toString.call(r).slice(8, -1);
      return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
    }
  }
  var entries = Object.entries;
  var setPrototypeOf = Object.setPrototypeOf;
  var isFrozen = Object.isFrozen;
  var getPrototypeOf = Object.getPrototypeOf;
  var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
  var freeze = Object.freeze;
  var seal = Object.seal;
  var create = Object.create;
  var _ref = typeof Reflect !== "undefined" && Reflect;
  var apply = _ref.apply;
  var construct = _ref.construct;
  if (!freeze) {
    freeze = function freeze2(x2) {
      return x2;
    };
  }
  if (!seal) {
    seal = function seal2(x2) {
      return x2;
    };
  }
  if (!apply) {
    apply = function apply2(func, thisArg) {
      for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
        args[_key - 2] = arguments[_key];
      }
      return func.apply(thisArg, args);
    };
  }
  if (!construct) {
    construct = function construct2(Func) {
      for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
        args[_key2 - 1] = arguments[_key2];
      }
      return new Func(...args);
    };
  }
  var arrayForEach = unapply(Array.prototype.forEach);
  var arrayLastIndexOf = unapply(Array.prototype.lastIndexOf);
  var arrayPop = unapply(Array.prototype.pop);
  var arrayPush = unapply(Array.prototype.push);
  var arraySplice = unapply(Array.prototype.splice);
  var arrayIsArray = Array.isArray;
  var stringToLowerCase = unapply(String.prototype.toLowerCase);
  var stringToString = unapply(String.prototype.toString);
  var stringMatch = unapply(String.prototype.match);
  var stringReplace = unapply(String.prototype.replace);
  var stringIndexOf = unapply(String.prototype.indexOf);
  var stringTrim = unapply(String.prototype.trim);
  var numberToString = unapply(Number.prototype.toString);
  var booleanToString = unapply(Boolean.prototype.toString);
  var bigintToString = typeof BigInt === "undefined" ? null : unapply(BigInt.prototype.toString);
  var symbolToString = typeof Symbol === "undefined" ? null : unapply(Symbol.prototype.toString);
  var objectHasOwnProperty = unapply(Object.prototype.hasOwnProperty);
  var objectToString = unapply(Object.prototype.toString);
  var regExpTest = unapply(RegExp.prototype.test);
  var typeErrorCreate = unconstruct(TypeError);
  function unapply(func) {
    return function(thisArg) {
      if (thisArg instanceof RegExp) {
        thisArg.lastIndex = 0;
      }
      for (var _len3 = arguments.length, args = new Array(_len3 > 1 ? _len3 - 1 : 0), _key3 = 1; _key3 < _len3; _key3++) {
        args[_key3 - 1] = arguments[_key3];
      }
      return apply(func, thisArg, args);
    };
  }
  function unconstruct(Func) {
    return function() {
      for (var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
        args[_key4] = arguments[_key4];
      }
      return construct(Func, args);
    };
  }
  function addToSet(set, array) {
    let transformCaseFunc = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : stringToLowerCase;
    if (setPrototypeOf) {
      setPrototypeOf(set, null);
    }
    if (!arrayIsArray(array)) {
      return set;
    }
    let l = array.length;
    while (l--) {
      let element = array[l];
      if (typeof element === "string") {
        const lcElement = transformCaseFunc(element);
        if (lcElement !== element) {
          if (!isFrozen(array)) {
            array[l] = lcElement;
          }
          element = lcElement;
        }
      }
      set[element] = true;
    }
    return set;
  }
  function cleanArray(array) {
    for (let index = 0; index < array.length; index++) {
      const isPropertyExist = objectHasOwnProperty(array, index);
      if (!isPropertyExist) {
        array[index] = null;
      }
    }
    return array;
  }
  function clone(object) {
    const newObject = create(null);
    for (const _ref2 of entries(object)) {
      var _ref3 = _slicedToArray(_ref2, 2);
      const property = _ref3[0];
      const value = _ref3[1];
      const isPropertyExist = objectHasOwnProperty(object, property);
      if (isPropertyExist) {
        if (arrayIsArray(value)) {
          newObject[property] = cleanArray(value);
        } else if (value && typeof value === "object" && value.constructor === Object) {
          newObject[property] = clone(value);
        } else {
          newObject[property] = value;
        }
      }
    }
    return newObject;
  }
  function stringifyValue(value) {
    switch (typeof value) {
      case "string": {
        return value;
      }
      case "number": {
        return numberToString(value);
      }
      case "boolean": {
        return booleanToString(value);
      }
      case "bigint": {
        return bigintToString ? bigintToString(value) : "0";
      }
      case "symbol": {
        return symbolToString ? symbolToString(value) : "Symbol()";
      }
      case "undefined": {
        return objectToString(value);
      }
      case "function":
      case "object": {
        if (value === null) {
          return objectToString(value);
        }
        const valueAsRecord = value;
        const valueToString = lookupGetter(valueAsRecord, "toString");
        if (typeof valueToString === "function") {
          const stringified = valueToString(valueAsRecord);
          return typeof stringified === "string" ? stringified : objectToString(stringified);
        }
        return objectToString(value);
      }
      default: {
        return objectToString(value);
      }
    }
  }
  function lookupGetter(object, prop) {
    while (object !== null) {
      const desc = getOwnPropertyDescriptor(object, prop);
      if (desc) {
        if (desc.get) {
          return unapply(desc.get);
        }
        if (typeof desc.value === "function") {
          return unapply(desc.value);
        }
      }
      object = getPrototypeOf(object);
    }
    function fallbackValue() {
      return null;
    }
    return fallbackValue;
  }
  function isRegex(value) {
    try {
      regExpTest(value, "");
      return true;
    } catch (_unused) {
      return false;
    }
  }
  var html$1 = freeze(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "search", "section", "select", "shadow", "slot", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]);
  var svg$1 = freeze(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "enterkeyhint", "exportparts", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "inputmode", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "part", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]);
  var svgFilters = freeze(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]);
  var svgDisallowed = freeze(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]);
  var mathMl$1 = freeze(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]);
  var mathMlDisallowed = freeze(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]);
  var text2 = freeze(["#text"]);
  var html = freeze(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "command", "commandfor", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "exportparts", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inert", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "part", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "slot", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns"]);
  var svg = freeze(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dominant-baseline", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "mask-type", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-orientation", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]);
  var mathMl = freeze(["accent", "accentunder", "align", "bevelled", "close", "columnalign", "columnlines", "columnspacing", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lquote", "lspace", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]);
  var xml = freeze(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]);
  var MUSTACHE_EXPR = seal(/{{[\w\W]*|^[\w\W]*}}/g);
  var ERB_EXPR = seal(/<%[\w\W]*|^[\w\W]*%>/g);
  var TMPLIT_EXPR = seal(/\${[\w\W]*/g);
  var DATA_ATTR = seal(/^data-[\-\w.\u00B7-\uFFFF]+$/);
  var ARIA_ATTR = seal(/^aria-[\-\w]+$/);
  var IS_ALLOWED_URI = seal(
    /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
    // eslint-disable-line no-useless-escape
  );
  var IS_SCRIPT_OR_DATA = seal(/^(?:\w+script|data):/i);
  var ATTR_WHITESPACE = seal(
    /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
    // eslint-disable-line no-control-regex
  );
  var DOCTYPE_NAME = seal(/^html$/i);
  var CUSTOM_ELEMENT = seal(/^[a-z][.\w]*(-[.\w]+)+$/i);
  var ELEMENT_MARKUP_PROBE = seal(/<[/\w!]/g);
  var COMMENT_MARKUP_PROBE = seal(/<[/\w]/g);
  var FALLBACK_TAG_CLOSE = seal(/<\/no(script|embed|frames)/i);
  var SELF_CLOSING_TAG = seal(/\/>/i);
  var NODE_TYPE = {
    element: 1,
    attribute: 2,
    text: 3,
    cdataSection: 4,
    entityReference: 5,
    // Deprecated
    entityNode: 6,
    // Deprecated
    processingInstruction: 7,
    comment: 8,
    document: 9,
    documentType: 10,
    documentFragment: 11,
    notation: 12
    // Deprecated
  };
  var getGlobal = function getGlobal2() {
    return typeof window === "undefined" ? null : window;
  };
  var _createTrustedTypesPolicy = function _createTrustedTypesPolicy2(trustedTypes, purifyHostElement) {
    if (typeof trustedTypes !== "object" || typeof trustedTypes.createPolicy !== "function") {
      return null;
    }
    let suffix = null;
    const ATTR_NAME = "data-tt-policy-suffix";
    if (purifyHostElement && purifyHostElement.hasAttribute(ATTR_NAME)) {
      suffix = purifyHostElement.getAttribute(ATTR_NAME);
    }
    const policyName = "dompurify" + (suffix ? "#" + suffix : "");
    try {
      return trustedTypes.createPolicy(policyName, {
        createHTML(html2) {
          return html2;
        },
        createScriptURL(scriptUrl) {
          return scriptUrl;
        }
      });
    } catch (_) {
      console.warn("TrustedTypes policy " + policyName + " could not be created.");
      return null;
    }
  };
  var _createHooksMap = function _createHooksMap2() {
    return {
      afterSanitizeAttributes: [],
      afterSanitizeElements: [],
      afterSanitizeShadowDOM: [],
      beforeSanitizeAttributes: [],
      beforeSanitizeElements: [],
      beforeSanitizeShadowDOM: [],
      uponSanitizeAttribute: [],
      uponSanitizeElement: [],
      uponSanitizeShadowNode: []
    };
  };
  var _resolveSetOption = function _resolveSetOption2(cfg, key, fallback, options) {
    return objectHasOwnProperty(cfg, key) && arrayIsArray(cfg[key]) ? addToSet(options.base ? clone(options.base) : {}, cfg[key], options.transform) : fallback;
  };
  function createDOMPurify() {
    let window2 = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : getGlobal();
    const DOMPurify = (root) => createDOMPurify(root);
    DOMPurify.version = "3.4.13";
    DOMPurify.removed = [];
    if (!window2 || !window2.document || window2.document.nodeType !== NODE_TYPE.document || !window2.Element) {
      DOMPurify.isSupported = false;
      return DOMPurify;
    }
    let document3 = window2.document;
    const originalDocument = document3;
    const currentScript = originalDocument.currentScript;
    window2.DocumentFragment;
    const HTMLTemplateElement = window2.HTMLTemplateElement, Node = window2.Node, Element = window2.Element, NodeFilter2 = window2.NodeFilter, _window$NamedNodeMap = window2.NamedNodeMap;
    _window$NamedNodeMap === void 0 ? window2.NamedNodeMap || window2.MozNamedAttrMap : _window$NamedNodeMap;
    window2.HTMLFormElement;
    const DOMParser2 = window2.DOMParser, trustedTypes = window2.trustedTypes;
    const ElementPrototype = Element.prototype;
    const cloneNode = lookupGetter(ElementPrototype, "cloneNode");
    const remove = lookupGetter(ElementPrototype, "remove");
    const getNextSibling = lookupGetter(ElementPrototype, "nextSibling");
    const getChildNodes = lookupGetter(ElementPrototype, "childNodes");
    const getParentNode = lookupGetter(ElementPrototype, "parentNode");
    const getShadowRoot = lookupGetter(ElementPrototype, "shadowRoot");
    const getAttributes = lookupGetter(ElementPrototype, "attributes");
    const getNodeType = Node && Node.prototype ? lookupGetter(Node.prototype, "nodeType") : null;
    const getNodeName = Node && Node.prototype ? lookupGetter(Node.prototype, "nodeName") : null;
    const getOwnerDocument = Node && Node.prototype ? lookupGetter(Node.prototype, "ownerDocument") : null;
    if (typeof HTMLTemplateElement === "function") {
      const template = document3.createElement("template");
      if (template.content && template.content.ownerDocument) {
        document3 = template.content.ownerDocument;
      }
    }
    let trustedTypesPolicy;
    let emptyHTML = "";
    let defaultTrustedTypesPolicy;
    let defaultTrustedTypesPolicyResolved = false;
    let IN_TRUSTED_TYPES_POLICY = 0;
    const _assertNotInTrustedTypesPolicy = function _assertNotInTrustedTypesPolicy2() {
      if (IN_TRUSTED_TYPES_POLICY > 0) {
        throw typeErrorCreate('A configured TRUSTED_TYPES_POLICY callback (createHTML or createScriptURL) must not call DOMPurify.sanitize, as that causes infinite recursion. Do not pass a policy whose callbacks wrap DOMPurify as TRUSTED_TYPES_POLICY; see the "DOMPurify and Trusted Types" section of the README.');
      }
    };
    const _createTrustedHTML = function _createTrustedHTML2(html2) {
      _assertNotInTrustedTypesPolicy();
      IN_TRUSTED_TYPES_POLICY++;
      try {
        return trustedTypesPolicy.createHTML(html2);
      } finally {
        IN_TRUSTED_TYPES_POLICY--;
      }
    };
    const _createTrustedScriptURL = function _createTrustedScriptURL2(scriptUrl) {
      _assertNotInTrustedTypesPolicy();
      IN_TRUSTED_TYPES_POLICY++;
      try {
        return trustedTypesPolicy.createScriptURL(scriptUrl);
      } finally {
        IN_TRUSTED_TYPES_POLICY--;
      }
    };
    const _getDefaultTrustedTypesPolicy = function _getDefaultTrustedTypesPolicy2() {
      if (!defaultTrustedTypesPolicyResolved) {
        defaultTrustedTypesPolicy = _createTrustedTypesPolicy(trustedTypes, currentScript);
        defaultTrustedTypesPolicyResolved = true;
      }
      return defaultTrustedTypesPolicy;
    };
    const _document = document3, implementation = _document.implementation, createNodeIterator = _document.createNodeIterator, createDocumentFragment = _document.createDocumentFragment, getElementsByTagName = _document.getElementsByTagName;
    const importNode = originalDocument.importNode;
    let hooks = _createHooksMap();
    DOMPurify.isSupported = typeof entries === "function" && typeof getParentNode === "function" && implementation && implementation.createHTMLDocument !== void 0;
    const MUSTACHE_EXPR$1 = MUSTACHE_EXPR, ERB_EXPR$1 = ERB_EXPR, TMPLIT_EXPR$1 = TMPLIT_EXPR, DATA_ATTR$1 = DATA_ATTR, ARIA_ATTR$1 = ARIA_ATTR, IS_SCRIPT_OR_DATA$1 = IS_SCRIPT_OR_DATA, ATTR_WHITESPACE$1 = ATTR_WHITESPACE, CUSTOM_ELEMENT$1 = CUSTOM_ELEMENT;
    let IS_ALLOWED_URI$1 = IS_ALLOWED_URI;
    let ALLOWED_TAGS2 = null;
    const DEFAULT_ALLOWED_TAGS = addToSet({}, [...html$1, ...svg$1, ...svgFilters, ...mathMl$1, ...text2]);
    let ALLOWED_ATTR = null;
    const DEFAULT_ALLOWED_ATTR = addToSet({}, [...html, ...svg, ...mathMl, ...xml]);
    let CUSTOM_ELEMENT_HANDLING = Object.seal(create(null, {
      tagNameCheck: {
        writable: true,
        configurable: false,
        enumerable: true,
        value: null
      },
      attributeNameCheck: {
        writable: true,
        configurable: false,
        enumerable: true,
        value: null
      },
      allowCustomizedBuiltInElements: {
        writable: true,
        configurable: false,
        enumerable: true,
        value: false
      }
    }));
    let FORBID_TAGS = null;
    let FORBID_ATTR = null;
    const EXTRA_ELEMENT_HANDLING = Object.seal(create(null, {
      tagCheck: {
        writable: true,
        configurable: false,
        enumerable: true,
        value: null
      },
      attributeCheck: {
        writable: true,
        configurable: false,
        enumerable: true,
        value: null
      }
    }));
    let ALLOW_ARIA_ATTR = true;
    let ALLOW_DATA_ATTR = true;
    let ALLOW_UNKNOWN_PROTOCOLS = false;
    let ALLOW_SELF_CLOSE_IN_ATTR = true;
    let SAFE_FOR_TEMPLATES = false;
    let SAFE_FOR_XML = true;
    let WHOLE_DOCUMENT = false;
    let SET_CONFIG = false;
    let SET_CONFIG_ALLOWED_TAGS = null;
    let SET_CONFIG_ALLOWED_ATTR = null;
    let FORCE_BODY = false;
    let RETURN_DOM = false;
    let RETURN_DOM_FRAGMENT = false;
    let RETURN_TRUSTED_TYPE = false;
    let SANITIZE_DOM = true;
    let SANITIZE_NAMED_PROPS = false;
    const SANITIZE_NAMED_PROPS_PREFIX = "user-content-";
    let KEEP_CONTENT = true;
    let IN_PLACE = false;
    let USE_PROFILES = {};
    let FORBID_CONTENTS = null;
    const DEFAULT_FORBID_CONTENTS = addToSet({}, [
      "annotation-xml",
      "audio",
      "colgroup",
      "desc",
      "foreignobject",
      "head",
      "iframe",
      "math",
      "mi",
      "mn",
      "mo",
      "ms",
      "mtext",
      "noembed",
      "noframes",
      "noscript",
      "plaintext",
      "script",
      // <selectedcontent> mirrors the selected <option>'s subtree, cloned by
      // the UA (customizable <select>) — including any on* handlers — and the
      // engine re-mirrors synchronously whenever a removal changes which
      // option/selectedcontent is current, even inside DOMPurify's inert
      // DOMParser document. Hoisting its children on removal re-inserts a fresh
      // mirror target ahead of the walk, which the engine refills, looping
      // forever (DoS) and amplifying output. Dropping its content on removal
      // (rather than hoisting) breaks that cascade; the content is a duplicate
      // of the option, which is sanitized on its own. See campaign-3 F1/F6.
      "selectedcontent",
      "style",
      "svg",
      "template",
      "thead",
      "title",
      "video",
      "xmp"
    ]);
    let DATA_URI_TAGS = null;
    const DEFAULT_DATA_URI_TAGS = addToSet({}, ["audio", "video", "img", "source", "image", "track"]);
    let URI_SAFE_ATTRIBUTES = null;
    const DEFAULT_URI_SAFE_ATTRIBUTES = addToSet({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]);
    const MATHML_NAMESPACE = "http://www.w3.org/1998/Math/MathML";
    const SVG_NAMESPACE = "http://www.w3.org/2000/svg";
    const HTML_NAMESPACE3 = "http://www.w3.org/1999/xhtml";
    let NAMESPACE = HTML_NAMESPACE3;
    let IS_EMPTY_INPUT = false;
    let ALLOWED_NAMESPACES = null;
    const DEFAULT_ALLOWED_NAMESPACES = addToSet({}, [MATHML_NAMESPACE, SVG_NAMESPACE, HTML_NAMESPACE3], stringToString);
    const DEFAULT_MATHML_TEXT_INTEGRATION_POINTS = freeze(["mi", "mo", "mn", "ms", "mtext"]);
    let MATHML_TEXT_INTEGRATION_POINTS = addToSet({}, DEFAULT_MATHML_TEXT_INTEGRATION_POINTS);
    const DEFAULT_HTML_INTEGRATION_POINTS = freeze(["annotation-xml"]);
    let HTML_INTEGRATION_POINTS = addToSet({}, DEFAULT_HTML_INTEGRATION_POINTS);
    const COMMON_SVG_AND_HTML_ELEMENTS = addToSet({}, ["title", "style", "font", "a", "script"]);
    let PARSER_MEDIA_TYPE = null;
    const SUPPORTED_PARSER_MEDIA_TYPES = ["application/xhtml+xml", "text/html"];
    const DEFAULT_PARSER_MEDIA_TYPE = "text/html";
    let transformCaseFunc = null;
    let CONFIG = null;
    const formElement = document3.createElement("form");
    const isRegexOrFunction = function isRegexOrFunction2(testValue) {
      return testValue instanceof RegExp || testValue instanceof Function;
    };
    const _parseConfig = function _parseConfig2() {
      let cfg = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
      if (CONFIG && CONFIG === cfg) {
        return;
      }
      if (!cfg || typeof cfg !== "object") {
        cfg = {};
      }
      cfg = clone(cfg);
      PARSER_MEDIA_TYPE = // eslint-disable-next-line unicorn/prefer-includes
      SUPPORTED_PARSER_MEDIA_TYPES.indexOf(cfg.PARSER_MEDIA_TYPE) === -1 ? DEFAULT_PARSER_MEDIA_TYPE : cfg.PARSER_MEDIA_TYPE;
      transformCaseFunc = PARSER_MEDIA_TYPE === "application/xhtml+xml" ? stringToString : stringToLowerCase;
      ALLOWED_TAGS2 = _resolveSetOption(cfg, "ALLOWED_TAGS", DEFAULT_ALLOWED_TAGS, {
        transform: transformCaseFunc
      });
      ALLOWED_ATTR = _resolveSetOption(cfg, "ALLOWED_ATTR", DEFAULT_ALLOWED_ATTR, {
        transform: transformCaseFunc
      });
      ALLOWED_NAMESPACES = _resolveSetOption(cfg, "ALLOWED_NAMESPACES", DEFAULT_ALLOWED_NAMESPACES, {
        transform: stringToString
      });
      URI_SAFE_ATTRIBUTES = _resolveSetOption(cfg, "ADD_URI_SAFE_ATTR", DEFAULT_URI_SAFE_ATTRIBUTES, {
        transform: transformCaseFunc,
        base: DEFAULT_URI_SAFE_ATTRIBUTES
      });
      DATA_URI_TAGS = _resolveSetOption(cfg, "ADD_DATA_URI_TAGS", DEFAULT_DATA_URI_TAGS, {
        transform: transformCaseFunc,
        base: DEFAULT_DATA_URI_TAGS
      });
      FORBID_CONTENTS = _resolveSetOption(cfg, "FORBID_CONTENTS", DEFAULT_FORBID_CONTENTS, {
        transform: transformCaseFunc
      });
      FORBID_TAGS = _resolveSetOption(cfg, "FORBID_TAGS", clone({}), {
        transform: transformCaseFunc
      });
      FORBID_ATTR = _resolveSetOption(cfg, "FORBID_ATTR", clone({}), {
        transform: transformCaseFunc
      });
      USE_PROFILES = objectHasOwnProperty(cfg, "USE_PROFILES") ? cfg.USE_PROFILES && typeof cfg.USE_PROFILES === "object" ? clone(cfg.USE_PROFILES) : cfg.USE_PROFILES : false;
      ALLOW_ARIA_ATTR = cfg.ALLOW_ARIA_ATTR !== false;
      ALLOW_DATA_ATTR = cfg.ALLOW_DATA_ATTR !== false;
      ALLOW_UNKNOWN_PROTOCOLS = cfg.ALLOW_UNKNOWN_PROTOCOLS || false;
      ALLOW_SELF_CLOSE_IN_ATTR = cfg.ALLOW_SELF_CLOSE_IN_ATTR !== false;
      SAFE_FOR_TEMPLATES = cfg.SAFE_FOR_TEMPLATES || false;
      SAFE_FOR_XML = cfg.SAFE_FOR_XML !== false;
      WHOLE_DOCUMENT = cfg.WHOLE_DOCUMENT || false;
      RETURN_DOM = cfg.RETURN_DOM || false;
      RETURN_DOM_FRAGMENT = cfg.RETURN_DOM_FRAGMENT || false;
      RETURN_TRUSTED_TYPE = cfg.RETURN_TRUSTED_TYPE || false;
      FORCE_BODY = cfg.FORCE_BODY || false;
      SANITIZE_DOM = cfg.SANITIZE_DOM !== false;
      SANITIZE_NAMED_PROPS = cfg.SANITIZE_NAMED_PROPS || false;
      KEEP_CONTENT = cfg.KEEP_CONTENT !== false;
      IN_PLACE = cfg.IN_PLACE || false;
      IS_ALLOWED_URI$1 = isRegex(cfg.ALLOWED_URI_REGEXP) ? cfg.ALLOWED_URI_REGEXP : IS_ALLOWED_URI;
      NAMESPACE = typeof cfg.NAMESPACE === "string" ? cfg.NAMESPACE : HTML_NAMESPACE3;
      MATHML_TEXT_INTEGRATION_POINTS = objectHasOwnProperty(cfg, "MATHML_TEXT_INTEGRATION_POINTS") && cfg.MATHML_TEXT_INTEGRATION_POINTS && typeof cfg.MATHML_TEXT_INTEGRATION_POINTS === "object" ? clone(cfg.MATHML_TEXT_INTEGRATION_POINTS) : addToSet({}, DEFAULT_MATHML_TEXT_INTEGRATION_POINTS);
      HTML_INTEGRATION_POINTS = objectHasOwnProperty(cfg, "HTML_INTEGRATION_POINTS") && cfg.HTML_INTEGRATION_POINTS && typeof cfg.HTML_INTEGRATION_POINTS === "object" ? clone(cfg.HTML_INTEGRATION_POINTS) : addToSet({}, DEFAULT_HTML_INTEGRATION_POINTS);
      const customElementHandling = objectHasOwnProperty(cfg, "CUSTOM_ELEMENT_HANDLING") && cfg.CUSTOM_ELEMENT_HANDLING && typeof cfg.CUSTOM_ELEMENT_HANDLING === "object" ? clone(cfg.CUSTOM_ELEMENT_HANDLING) : create(null);
      CUSTOM_ELEMENT_HANDLING = create(null);
      if (objectHasOwnProperty(customElementHandling, "tagNameCheck") && isRegexOrFunction(customElementHandling.tagNameCheck)) {
        CUSTOM_ELEMENT_HANDLING.tagNameCheck = customElementHandling.tagNameCheck;
      }
      if (objectHasOwnProperty(customElementHandling, "attributeNameCheck") && isRegexOrFunction(customElementHandling.attributeNameCheck)) {
        CUSTOM_ELEMENT_HANDLING.attributeNameCheck = customElementHandling.attributeNameCheck;
      }
      if (objectHasOwnProperty(customElementHandling, "allowCustomizedBuiltInElements") && typeof customElementHandling.allowCustomizedBuiltInElements === "boolean") {
        CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements = customElementHandling.allowCustomizedBuiltInElements;
      }
      seal(CUSTOM_ELEMENT_HANDLING);
      if (SAFE_FOR_TEMPLATES) {
        ALLOW_DATA_ATTR = false;
      }
      if (RETURN_DOM_FRAGMENT) {
        RETURN_DOM = true;
      }
      if (USE_PROFILES) {
        ALLOWED_TAGS2 = addToSet({}, text2);
        ALLOWED_ATTR = create(null);
        if (USE_PROFILES.html === true) {
          addToSet(ALLOWED_TAGS2, html$1);
          addToSet(ALLOWED_ATTR, html);
        }
        if (USE_PROFILES.svg === true) {
          addToSet(ALLOWED_TAGS2, svg$1);
          addToSet(ALLOWED_ATTR, svg);
          addToSet(ALLOWED_ATTR, xml);
        }
        if (USE_PROFILES.svgFilters === true) {
          addToSet(ALLOWED_TAGS2, svgFilters);
          addToSet(ALLOWED_ATTR, svg);
          addToSet(ALLOWED_ATTR, xml);
        }
        if (USE_PROFILES.mathMl === true) {
          addToSet(ALLOWED_TAGS2, mathMl$1);
          addToSet(ALLOWED_ATTR, mathMl);
          addToSet(ALLOWED_ATTR, xml);
        }
      }
      EXTRA_ELEMENT_HANDLING.tagCheck = null;
      EXTRA_ELEMENT_HANDLING.attributeCheck = null;
      if (objectHasOwnProperty(cfg, "ADD_TAGS")) {
        if (typeof cfg.ADD_TAGS === "function") {
          EXTRA_ELEMENT_HANDLING.tagCheck = cfg.ADD_TAGS;
        } else if (arrayIsArray(cfg.ADD_TAGS)) {
          if (ALLOWED_TAGS2 === DEFAULT_ALLOWED_TAGS) {
            ALLOWED_TAGS2 = clone(ALLOWED_TAGS2);
          }
          addToSet(ALLOWED_TAGS2, cfg.ADD_TAGS, transformCaseFunc);
        }
      }
      if (objectHasOwnProperty(cfg, "ADD_ATTR")) {
        if (typeof cfg.ADD_ATTR === "function") {
          EXTRA_ELEMENT_HANDLING.attributeCheck = cfg.ADD_ATTR;
        } else if (arrayIsArray(cfg.ADD_ATTR)) {
          if (ALLOWED_ATTR === DEFAULT_ALLOWED_ATTR) {
            ALLOWED_ATTR = clone(ALLOWED_ATTR);
          }
          addToSet(ALLOWED_ATTR, cfg.ADD_ATTR, transformCaseFunc);
        }
      }
      if (objectHasOwnProperty(cfg, "ADD_URI_SAFE_ATTR") && arrayIsArray(cfg.ADD_URI_SAFE_ATTR)) {
        addToSet(URI_SAFE_ATTRIBUTES, cfg.ADD_URI_SAFE_ATTR, transformCaseFunc);
      }
      if (objectHasOwnProperty(cfg, "FORBID_CONTENTS") && arrayIsArray(cfg.FORBID_CONTENTS)) {
        if (FORBID_CONTENTS === DEFAULT_FORBID_CONTENTS) {
          FORBID_CONTENTS = clone(FORBID_CONTENTS);
        }
        addToSet(FORBID_CONTENTS, cfg.FORBID_CONTENTS, transformCaseFunc);
      }
      if (objectHasOwnProperty(cfg, "ADD_FORBID_CONTENTS") && arrayIsArray(cfg.ADD_FORBID_CONTENTS)) {
        if (FORBID_CONTENTS === DEFAULT_FORBID_CONTENTS) {
          FORBID_CONTENTS = clone(FORBID_CONTENTS);
        }
        addToSet(FORBID_CONTENTS, cfg.ADD_FORBID_CONTENTS, transformCaseFunc);
      }
      if (KEEP_CONTENT) {
        ALLOWED_TAGS2["#text"] = true;
      }
      if (WHOLE_DOCUMENT) {
        addToSet(ALLOWED_TAGS2, ["html", "head", "body"]);
      }
      if (ALLOWED_TAGS2.table) {
        addToSet(ALLOWED_TAGS2, ["tbody"]);
        delete FORBID_TAGS.tbody;
      }
      if (cfg.TRUSTED_TYPES_POLICY) {
        if (typeof cfg.TRUSTED_TYPES_POLICY.createHTML !== "function") {
          throw typeErrorCreate('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        }
        if (typeof cfg.TRUSTED_TYPES_POLICY.createScriptURL !== "function") {
          throw typeErrorCreate('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        }
        const previousTrustedTypesPolicy = trustedTypesPolicy;
        trustedTypesPolicy = cfg.TRUSTED_TYPES_POLICY;
        try {
          emptyHTML = _createTrustedHTML("");
        } catch (error) {
          trustedTypesPolicy = previousTrustedTypesPolicy;
          throw error;
        }
      } else if (cfg.TRUSTED_TYPES_POLICY === null) {
        trustedTypesPolicy = void 0;
        emptyHTML = "";
      } else {
        if (trustedTypesPolicy === void 0) {
          trustedTypesPolicy = _getDefaultTrustedTypesPolicy();
        }
        if (trustedTypesPolicy && typeof emptyHTML === "string") {
          emptyHTML = _createTrustedHTML("");
        }
      }
      if (freeze) {
        freeze(cfg);
      }
      CONFIG = cfg;
    };
    const ALL_SVG_TAGS = addToSet({}, [...svg$1, ...svgFilters, ...svgDisallowed]);
    const ALL_MATHML_TAGS = addToSet({}, [...mathMl$1, ...mathMlDisallowed]);
    const _checkSvgNamespace = function _checkSvgNamespace2(tagName, parent, parentTagName) {
      if (parent.namespaceURI === HTML_NAMESPACE3) {
        return tagName === "svg";
      }
      if (parent.namespaceURI === MATHML_NAMESPACE) {
        return tagName === "svg" && (parentTagName === "annotation-xml" || MATHML_TEXT_INTEGRATION_POINTS[parentTagName]);
      }
      return Boolean(ALL_SVG_TAGS[tagName]);
    };
    const _checkMathMlNamespace = function _checkMathMlNamespace2(tagName, parent, parentTagName) {
      if (parent.namespaceURI === HTML_NAMESPACE3) {
        return tagName === "math";
      }
      if (parent.namespaceURI === SVG_NAMESPACE) {
        return tagName === "math" && HTML_INTEGRATION_POINTS[parentTagName];
      }
      return Boolean(ALL_MATHML_TAGS[tagName]);
    };
    const _checkHtmlNamespace = function _checkHtmlNamespace2(tagName, parent, parentTagName) {
      if (parent.namespaceURI === SVG_NAMESPACE && !HTML_INTEGRATION_POINTS[parentTagName]) {
        return false;
      }
      if (parent.namespaceURI === MATHML_NAMESPACE && !MATHML_TEXT_INTEGRATION_POINTS[parentTagName]) {
        return false;
      }
      return !ALL_MATHML_TAGS[tagName] && (COMMON_SVG_AND_HTML_ELEMENTS[tagName] || !ALL_SVG_TAGS[tagName]);
    };
    const _checkValidNamespace = function _checkValidNamespace2(element) {
      let parent = getParentNode(element);
      if (!parent || !parent.tagName) {
        parent = {
          namespaceURI: NAMESPACE,
          tagName: "template"
        };
      }
      const tagName = stringToLowerCase(element.tagName);
      const parentTagName = stringToLowerCase(parent.tagName);
      if (!ALLOWED_NAMESPACES[element.namespaceURI]) {
        return false;
      }
      if (element.namespaceURI === SVG_NAMESPACE) {
        return _checkSvgNamespace(tagName, parent, parentTagName);
      }
      if (element.namespaceURI === MATHML_NAMESPACE) {
        return _checkMathMlNamespace(tagName, parent, parentTagName);
      }
      if (element.namespaceURI === HTML_NAMESPACE3) {
        return _checkHtmlNamespace(tagName, parent, parentTagName);
      }
      if (PARSER_MEDIA_TYPE === "application/xhtml+xml" && ALLOWED_NAMESPACES[element.namespaceURI]) {
        return true;
      }
      return false;
    };
    const _forceRemove = function _forceRemove2(node) {
      arrayPush(DOMPurify.removed, {
        element: node
      });
      try {
        getParentNode(node).removeChild(node);
      } catch (_) {
        remove(node);
        if (!getParentNode(node)) {
          throw typeErrorCreate("a node selected for removal could not be detached from its tree and cannot be safely returned; refusing to sanitize in place");
        }
      }
    };
    const _neutralizeRoot = function _neutralizeRoot2(root) {
      _neutralizeSubtree(root);
      const childNodes = getChildNodes(root);
      if (childNodes) {
        const snapshot = [];
        arrayForEach(childNodes, (child) => {
          arrayPush(snapshot, child);
        });
        arrayForEach(snapshot, (child) => {
          try {
            remove(child);
          } catch (_) {
          }
        });
      }
      const attributes = getAttributes(root);
      if (attributes) {
        for (let i2 = attributes.length - 1; i2 >= 0; --i2) {
          const attribute = attributes[i2];
          const name = attribute && attribute.name;
          if (typeof name === "string") {
            try {
              root.removeAttribute(name);
            } catch (_) {
            }
          }
        }
      }
    };
    const _removeAttribute = function _removeAttribute2(name, element) {
      try {
        arrayPush(DOMPurify.removed, {
          attribute: element.getAttributeNode(name),
          from: element
        });
      } catch (_) {
        arrayPush(DOMPurify.removed, {
          attribute: null,
          from: element
        });
      }
      element.removeAttribute(name);
      if (name === "is") {
        if (RETURN_DOM || RETURN_DOM_FRAGMENT) {
          try {
            _forceRemove(element);
          } catch (_) {
          }
        } else {
          try {
            element.setAttribute(name, "");
          } catch (_) {
          }
        }
      }
    };
    const _stripDisallowedAttributes = function _stripDisallowedAttributes2(element) {
      const attributes = getAttributes(element);
      if (!attributes) {
        return;
      }
      for (let i2 = attributes.length - 1; i2 >= 0; --i2) {
        const attribute = attributes[i2];
        const name = attribute && attribute.name;
        if (typeof name !== "string" || ALLOWED_ATTR[transformCaseFunc(name)]) {
          continue;
        }
        try {
          element.removeAttribute(name);
        } catch (_) {
        }
      }
    };
    const _neutralizeSubtree = function _neutralizeSubtree2(root) {
      const stack = [root];
      while (stack.length > 0) {
        const node = stack.pop();
        const nodeType = getNodeType ? getNodeType(node) : node.nodeType;
        if (nodeType === NODE_TYPE.element) {
          _stripDisallowedAttributes(node);
        }
        const childNodes = getChildNodes(node);
        if (childNodes) {
          for (let i2 = childNodes.length - 1; i2 >= 0; --i2) {
            stack.push(childNodes[i2]);
          }
        }
      }
    };
    const _neutralizePatchLinkage = function _neutralizePatchLinkage2(root) {
      if (!SAFE_FOR_XML) {
        return;
      }
      const stack = [root];
      while (stack.length > 0) {
        const node = stack.pop();
        const nodeType = getNodeType ? getNodeType(node) : node.nodeType;
        if (nodeType === NODE_TYPE.processingInstruction || nodeType === NODE_TYPE.comment && regExpTest(COMMENT_MARKUP_PROBE, node.data)) {
          try {
            remove(node);
          } catch (_) {
          }
          continue;
        }
        if (nodeType === NODE_TYPE.element) {
          const element = node;
          const lcTag = transformCaseFunc(getNodeName ? getNodeName(node) : node.nodeName);
          try {
            if (element.hasAttribute && element.hasAttribute("patchsrc")) {
              element.removeAttribute("patchsrc");
            }
            if (element.hasAttribute && element.hasAttribute("for") && lcTag !== "label" && lcTag !== "output") {
              element.removeAttribute("for");
            }
          } catch (_) {
          }
        }
        const childNodes = getChildNodes(node);
        if (childNodes) {
          for (let i2 = childNodes.length - 1; i2 >= 0; --i2) {
            stack.push(childNodes[i2]);
          }
        }
      }
    };
    const _initDocument = function _initDocument2(dirty) {
      let doc = null;
      let leadingWhitespace = null;
      if (FORCE_BODY) {
        dirty = "<remove></remove>" + dirty;
      } else {
        const matches = stringMatch(dirty, /^[\r\n\t ]+/);
        leadingWhitespace = matches && matches[0];
      }
      if (PARSER_MEDIA_TYPE === "application/xhtml+xml" && NAMESPACE === HTML_NAMESPACE3) {
        dirty = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + dirty + "</body></html>";
      }
      const dirtyPayload = trustedTypesPolicy ? _createTrustedHTML(dirty) : dirty;
      if (NAMESPACE === HTML_NAMESPACE3) {
        try {
          doc = new DOMParser2().parseFromString(dirtyPayload, PARSER_MEDIA_TYPE);
        } catch (_) {
        }
      }
      if (!doc || !doc.documentElement) {
        doc = implementation.createDocument(NAMESPACE, "template", null);
        try {
          doc.documentElement.innerHTML = IS_EMPTY_INPUT ? emptyHTML : dirtyPayload;
        } catch (_) {
        }
      }
      const body = doc.body || doc.documentElement;
      if (dirty && leadingWhitespace) {
        body.insertBefore(document3.createTextNode(leadingWhitespace), body.childNodes[0] || null);
      }
      if (NAMESPACE === HTML_NAMESPACE3) {
        return getElementsByTagName.call(doc, WHOLE_DOCUMENT ? "html" : "body")[0];
      }
      return WHOLE_DOCUMENT ? doc.documentElement : body;
    };
    const _createNodeIterator = function _createNodeIterator2(root) {
      const doc = getOwnerDocument ? getOwnerDocument(root) : root.ownerDocument;
      return createNodeIterator.call(
        doc || root,
        root,
        // eslint-disable-next-line no-bitwise
        NodeFilter2.SHOW_ELEMENT | NodeFilter2.SHOW_COMMENT | NodeFilter2.SHOW_TEXT | NodeFilter2.SHOW_PROCESSING_INSTRUCTION | NodeFilter2.SHOW_CDATA_SECTION,
        null
      );
    };
    const _stripTemplateExpressions = function _stripTemplateExpressions2(value) {
      value = stringReplace(value, MUSTACHE_EXPR$1, " ");
      value = stringReplace(value, ERB_EXPR$1, " ");
      value = stringReplace(value, TMPLIT_EXPR$1, " ");
      return value;
    };
    const _scrubTemplateExpressions2 = function _scrubTemplateExpressions(node) {
      var _node$querySelectorAl;
      node.normalize();
      const doc = getOwnerDocument ? getOwnerDocument(node) : node.ownerDocument;
      const walker = createNodeIterator.call(
        doc || node,
        node,
        // eslint-disable-next-line no-bitwise
        NodeFilter2.SHOW_TEXT | NodeFilter2.SHOW_COMMENT | NodeFilter2.SHOW_CDATA_SECTION | NodeFilter2.SHOW_PROCESSING_INSTRUCTION,
        null
      );
      let currentNode = walker.nextNode();
      while (currentNode) {
        currentNode.data = _stripTemplateExpressions(currentNode.data);
        currentNode = walker.nextNode();
      }
      const templates = (_node$querySelectorAl = node.querySelectorAll) === null || _node$querySelectorAl === void 0 ? void 0 : _node$querySelectorAl.call(node, "template");
      if (templates) {
        arrayForEach(templates, (tmpl) => {
          if (_isDocumentFragment(tmpl.content)) {
            _scrubTemplateExpressions2(tmpl.content);
          }
        });
      }
    };
    const _isClobbered = function _isClobbered2(element) {
      const realTagName = getNodeName ? getNodeName(element) : null;
      if (typeof realTagName !== "string") {
        return false;
      }
      if (transformCaseFunc(realTagName) !== "form") {
        return false;
      }
      return typeof element.nodeName !== "string" || typeof element.textContent !== "string" || typeof element.removeChild !== "function" || // Realm-safe NamedNodeMap detection: equality against the cached
      // prototype getter. Clobbered .attributes (e.g. <input name="attributes">)
      // makes the direct read diverge from the cached read; a clean form
      // (same-realm OR foreign-realm) has both reads pointing at the same
      // canonical NamedNodeMap.
      element.attributes !== getAttributes(element) || typeof element.removeAttribute !== "function" || typeof element.setAttribute !== "function" || typeof element.namespaceURI !== "string" || typeof element.insertBefore !== "function" || typeof element.hasChildNodes !== "function" || // NodeType clobbering probe. Cached Node.prototype.nodeType getter
      // returns the integer 1 for any Element regardless of realm; direct
      // read on a clobbered form (e.g. <input name="nodeType">) returns
      // the named child element. Cheap addition — nodeType is read from
      // an internal slot, no serialization cost — and removes a residual
      // clobbering surface used by several mXSS / PI / comment branches
      // in _sanitizeElements that compare currentNode.nodeType directly.
      element.nodeType !== getNodeType(element) || // HTMLFormElement has [LegacyOverrideBuiltIns]: a descendant named
      // "childNodes" shadows the prototype getter. Direct reads of
      // form.childNodes from a clobbered form return the named child
      // instead of the real NodeList, so any walk that reads it directly
      // skips the form's real children. Compare the direct read to the
      // cached Node.prototype getter — when the form's named-property
      // getter intercepts the read, the two values differ and we flag
      // the form. This catches every clobbering child type (input,
      // select, etc.) regardless of whether the named child happens to
      // carry a numeric .length, which a typeof-based probe would miss
      // (e.g. HTMLSelectElement.length is a defined unsigned-long).
      element.childNodes !== getChildNodes(element);
    };
    const _isDocumentFragment = function _isDocumentFragment2(value) {
      if (!getNodeType || typeof value !== "object" || value === null) {
        return false;
      }
      try {
        return getNodeType(value) === NODE_TYPE.documentFragment;
      } catch (_) {
        return false;
      }
    };
    const _isNode = function _isNode2(value) {
      if (!getNodeType || typeof value !== "object" || value === null) {
        return false;
      }
      try {
        return typeof getNodeType(value) === "number";
      } catch (_) {
        return false;
      }
    };
    function _executeHooks(hooks2, currentNode, data) {
      if (hooks2.length === 0) {
        return;
      }
      arrayForEach(hooks2, (hook) => {
        hook.call(DOMPurify, currentNode, data, CONFIG);
      });
    }
    const _isUnsafeNode = function _isUnsafeNode2(currentNode, tagName) {
      if (SAFE_FOR_XML && currentNode.hasChildNodes() && !_isNode(currentNode.firstElementChild) && regExpTest(ELEMENT_MARKUP_PROBE, currentNode.textContent) && regExpTest(ELEMENT_MARKUP_PROBE, currentNode.innerHTML)) {
        return true;
      }
      if (SAFE_FOR_XML && currentNode.namespaceURI === HTML_NAMESPACE3 && tagName === "style" && _isNode(currentNode.firstElementChild)) {
        return true;
      }
      if (currentNode.nodeType === NODE_TYPE.processingInstruction) {
        return true;
      }
      if (SAFE_FOR_XML && currentNode.nodeType === NODE_TYPE.comment && regExpTest(COMMENT_MARKUP_PROBE, currentNode.data)) {
        return true;
      }
      return false;
    };
    const _sanitizeDisallowedNode = function _sanitizeDisallowedNode2(currentNode, tagName, root) {
      if (!FORBID_TAGS[tagName] && _isBasicCustomElement(tagName)) {
        if (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.tagNameCheck, tagName)) {
          return false;
        }
        if (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.tagNameCheck(tagName)) {
          return false;
        }
      }
      if (KEEP_CONTENT && !FORBID_CONTENTS[tagName]) {
        const parentNode = getParentNode(currentNode);
        const childNodes = getChildNodes(currentNode);
        if (childNodes && parentNode) {
          const childCount = childNodes.length;
          for (let i2 = childCount - 1; i2 >= 0; --i2) {
            const hoisted = currentNode === root ? cloneNode(childNodes[i2], true) : childNodes[i2];
            parentNode.insertBefore(hoisted, getNextSibling(currentNode));
          }
        }
      }
      _forceRemove(currentNode);
      return true;
    };
    const _forkSharedAllowlist = function _forkSharedAllowlist2(hookList, set, defaultSet, setConfigSet) {
      if (hookList.length === 0) {
        return set;
      }
      return set === defaultSet || set === setConfigSet ? clone(set) : set;
    };
    const _sanitizeElements = function _sanitizeElements2(currentNode, root) {
      _executeHooks(hooks.beforeSanitizeElements, currentNode, null);
      if (currentNode !== root && getParentNode(currentNode) === null) {
        if (IN_PLACE) {
          _neutralizeSubtree(currentNode);
        }
        return true;
      }
      if (_isClobbered(currentNode)) {
        _forceRemove(currentNode);
        return true;
      }
      const tagName = transformCaseFunc(getNodeName ? getNodeName(currentNode) : currentNode.nodeName);
      ALLOWED_TAGS2 = _forkSharedAllowlist(hooks.uponSanitizeElement, ALLOWED_TAGS2, DEFAULT_ALLOWED_TAGS, SET_CONFIG_ALLOWED_TAGS);
      _executeHooks(hooks.uponSanitizeElement, currentNode, {
        tagName,
        allowedTags: ALLOWED_TAGS2
      });
      if (currentNode !== root && getParentNode(currentNode) === null) {
        if (IN_PLACE) {
          _neutralizeSubtree(currentNode);
        }
        return true;
      }
      if (_isUnsafeNode(currentNode, tagName)) {
        _forceRemove(currentNode);
        return true;
      }
      if (FORBID_TAGS[tagName] || !(EXTRA_ELEMENT_HANDLING.tagCheck instanceof Function && EXTRA_ELEMENT_HANDLING.tagCheck(tagName)) && !ALLOWED_TAGS2[tagName]) {
        const removed = _sanitizeDisallowedNode(currentNode, tagName, root);
        if (removed === false) {
          _executeHooks(hooks.afterSanitizeElements, currentNode, null);
        }
        return removed;
      }
      const nt = getNodeType ? getNodeType(currentNode) : currentNode.nodeType;
      if (nt === NODE_TYPE.element && !_checkValidNamespace(currentNode)) {
        _forceRemove(currentNode);
        return true;
      }
      if ((tagName === "noscript" || tagName === "noembed" || tagName === "noframes") && regExpTest(FALLBACK_TAG_CLOSE, currentNode.innerHTML)) {
        _forceRemove(currentNode);
        return true;
      }
      if (SAFE_FOR_TEMPLATES && currentNode.nodeType === NODE_TYPE.text) {
        const content = _stripTemplateExpressions(currentNode.textContent);
        if (currentNode.textContent !== content) {
          arrayPush(DOMPurify.removed, {
            element: currentNode.cloneNode()
          });
          currentNode.textContent = content;
        }
      }
      _executeHooks(hooks.afterSanitizeElements, currentNode, null);
      return false;
    };
    const _isValidAttribute = function _isValidAttribute2(lcTag, lcName, value) {
      if (FORBID_ATTR[lcName]) {
        return false;
      }
      if (SAFE_FOR_XML && lcName === "patchsrc") {
        return false;
      }
      if (SAFE_FOR_XML && lcName === "for" && lcTag !== "label" && lcTag !== "output") {
        return false;
      }
      if (SANITIZE_DOM && (lcName === "id" || lcName === "name") && (value in document3 || value in formElement)) {
        return false;
      }
      const nameIsPermitted = ALLOWED_ATTR[lcName] || EXTRA_ELEMENT_HANDLING.attributeCheck instanceof Function && EXTRA_ELEMENT_HANDLING.attributeCheck(lcName, lcTag);
      if (ALLOW_DATA_ATTR && regExpTest(DATA_ATTR$1, lcName)) ;
      else if (ALLOW_ARIA_ATTR && regExpTest(ARIA_ATTR$1, lcName)) ;
      else if (!nameIsPermitted) {
        if (
          // First condition does a very basic check if a) it's basically a valid custom element tagname AND
          // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
          // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
          _isBasicCustomElement(lcTag) && (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.tagNameCheck, lcTag) || CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.tagNameCheck(lcTag)) && (CUSTOM_ELEMENT_HANDLING.attributeNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.attributeNameCheck, lcName) || CUSTOM_ELEMENT_HANDLING.attributeNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.attributeNameCheck(lcName, lcTag)) || // Alternative, second condition checks if it's an `is`-attribute, AND
          // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
          lcName === "is" && CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements && (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.tagNameCheck, value) || CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.tagNameCheck(value))
        ) ;
        else {
          return false;
        }
      } else if (URI_SAFE_ATTRIBUTES[lcName]) ;
      else if (regExpTest(IS_ALLOWED_URI$1, stringReplace(value, ATTR_WHITESPACE$1, ""))) ;
      else if ((lcName === "src" || lcName === "xlink:href" || lcName === "href") && lcTag !== "script" && stringIndexOf(value, "data:") === 0 && DATA_URI_TAGS[lcTag]) ;
      else if (ALLOW_UNKNOWN_PROTOCOLS && !regExpTest(IS_SCRIPT_OR_DATA$1, stringReplace(value, ATTR_WHITESPACE$1, ""))) ;
      else if (value) {
        return false;
      } else ;
      return true;
    };
    const RESERVED_CUSTOM_ELEMENT_NAMES = addToSet({}, ["annotation-xml", "color-profile", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "missing-glyph"]);
    const _isBasicCustomElement = function _isBasicCustomElement2(tagName) {
      return !RESERVED_CUSTOM_ELEMENT_NAMES[stringToLowerCase(tagName)] && regExpTest(CUSTOM_ELEMENT$1, tagName);
    };
    const _applyTrustedTypesToAttribute = function _applyTrustedTypesToAttribute2(lcTag, lcName, namespaceURI, value) {
      if (trustedTypesPolicy && typeof trustedTypes === "object" && typeof trustedTypes.getAttributeType === "function" && !namespaceURI) {
        switch (trustedTypes.getAttributeType(lcTag, lcName)) {
          case "TrustedHTML": {
            return _createTrustedHTML(value);
          }
          case "TrustedScriptURL": {
            return _createTrustedScriptURL(value);
          }
        }
      }
      return value;
    };
    const _setAttributeValue = function _setAttributeValue2(currentNode, name, namespaceURI, value) {
      try {
        if (namespaceURI) {
          currentNode.setAttributeNS(namespaceURI, name, value);
        } else {
          currentNode.setAttribute(name, value);
        }
        if (_isClobbered(currentNode)) {
          _forceRemove(currentNode);
        } else {
          arrayPop(DOMPurify.removed);
        }
      } catch (_) {
        _removeAttribute(name, currentNode);
      }
    };
    const _sanitizeAttributes = function _sanitizeAttributes2(currentNode) {
      _executeHooks(hooks.beforeSanitizeAttributes, currentNode, null);
      const attributes = currentNode.attributes;
      if (!attributes || _isClobbered(currentNode)) {
        return;
      }
      ALLOWED_ATTR = _forkSharedAllowlist(hooks.uponSanitizeAttribute, ALLOWED_ATTR, DEFAULT_ALLOWED_ATTR, SET_CONFIG_ALLOWED_ATTR);
      const hookEvent = {
        attrName: "",
        attrValue: "",
        keepAttr: true,
        allowedAttributes: ALLOWED_ATTR,
        forceKeepAttr: void 0
      };
      let l = attributes.length;
      const lcTag = transformCaseFunc(currentNode.nodeName);
      while (l--) {
        const attr = attributes[l];
        const name = attr.name, namespaceURI = attr.namespaceURI, attrValue = attr.value;
        const lcName = transformCaseFunc(name);
        const initValue = attrValue;
        let value = name === "value" ? initValue : stringTrim(initValue);
        hookEvent.attrName = lcName;
        hookEvent.attrValue = value;
        hookEvent.keepAttr = true;
        hookEvent.forceKeepAttr = void 0;
        _executeHooks(hooks.uponSanitizeAttribute, currentNode, hookEvent);
        value = hookEvent.attrValue;
        if (SANITIZE_NAMED_PROPS && (lcName === "id" || lcName === "name") && stringIndexOf(value, SANITIZE_NAMED_PROPS_PREFIX) !== 0) {
          _removeAttribute(name, currentNode);
          value = SANITIZE_NAMED_PROPS_PREFIX + value;
        }
        if (SAFE_FOR_XML && regExpTest(/((--!?|])>)|<\/(style|script|title|xmp|textarea|noscript|iframe|noembed|noframes)/i, value)) {
          _removeAttribute(name, currentNode);
          continue;
        }
        if (lcName === "attributename" && stringMatch(value, "href")) {
          _removeAttribute(name, currentNode);
          continue;
        }
        if (hookEvent.forceKeepAttr) {
          continue;
        }
        if (!hookEvent.keepAttr) {
          _removeAttribute(name, currentNode);
          continue;
        }
        if (!ALLOW_SELF_CLOSE_IN_ATTR && regExpTest(SELF_CLOSING_TAG, value)) {
          _removeAttribute(name, currentNode);
          continue;
        }
        if (SAFE_FOR_TEMPLATES) {
          value = _stripTemplateExpressions(value);
        }
        if (!_isValidAttribute(lcTag, lcName, value)) {
          _removeAttribute(name, currentNode);
          continue;
        }
        value = _applyTrustedTypesToAttribute(lcTag, lcName, namespaceURI, value);
        if (value !== initValue) {
          _setAttributeValue(currentNode, name, namespaceURI, value);
        }
      }
      _executeHooks(hooks.afterSanitizeAttributes, currentNode, null);
    };
    const _sanitizeShadowDOM2 = function _sanitizeShadowDOM(fragment) {
      let shadowNode = null;
      const shadowIterator = _createNodeIterator(fragment);
      _executeHooks(hooks.beforeSanitizeShadowDOM, fragment, null);
      while (shadowNode = shadowIterator.nextNode()) {
        _executeHooks(hooks.uponSanitizeShadowNode, shadowNode, null);
        _sanitizeElements(shadowNode, fragment);
        _sanitizeAttributes(shadowNode);
        if (_isDocumentFragment(shadowNode.content)) {
          _sanitizeShadowDOM2(shadowNode.content);
        }
        const shadowNodeType = getNodeType ? getNodeType(shadowNode) : shadowNode.nodeType;
        if (shadowNodeType === NODE_TYPE.element) {
          const innerSr = getShadowRoot(shadowNode);
          if (_isDocumentFragment(innerSr)) {
            _sanitizeAttachedShadowRoots(innerSr);
            _sanitizeShadowDOM2(innerSr);
          }
        }
      }
      _executeHooks(hooks.afterSanitizeShadowDOM, fragment, null);
    };
    const _sanitizeAttachedShadowRoots = function _sanitizeAttachedShadowRoots2(root) {
      const stack = [{
        node: root,
        shadow: null
      }];
      while (stack.length > 0) {
        const item = stack.pop();
        if (item.shadow) {
          _sanitizeShadowDOM2(item.shadow);
          continue;
        }
        const node = item.node;
        const nodeType = getNodeType ? getNodeType(node) : node.nodeType;
        const isElement = nodeType === NODE_TYPE.element;
        const childNodes = getChildNodes(node);
        if (childNodes) {
          for (let i2 = childNodes.length - 1; i2 >= 0; --i2) {
            stack.push({
              node: childNodes[i2],
              shadow: null
            });
          }
        }
        if (isElement) {
          const rootName = getNodeName ? getNodeName(node) : null;
          if (typeof rootName === "string" && transformCaseFunc(rootName) === "template") {
            const content = node.content;
            if (_isDocumentFragment(content)) {
              stack.push({
                node: content,
                shadow: null
              });
            }
          }
        }
        if (isElement) {
          const sr = getShadowRoot(node);
          if (_isDocumentFragment(sr)) {
            stack.push({
              node: null,
              shadow: sr
            }, {
              node: sr,
              shadow: null
            });
          }
        }
      }
    };
    DOMPurify.sanitize = function(dirty) {
      let cfg = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
      let body = null;
      let importedNode = null;
      let currentNode = null;
      let returnNode = null;
      IS_EMPTY_INPUT = !dirty;
      if (IS_EMPTY_INPUT) {
        dirty = "<!-->";
      }
      if (typeof dirty !== "string" && !_isNode(dirty)) {
        dirty = stringifyValue(dirty);
        if (typeof dirty !== "string") {
          throw typeErrorCreate("dirty is not a string, aborting");
        }
      }
      if (!DOMPurify.isSupported) {
        return dirty;
      }
      if (SET_CONFIG) {
        ALLOWED_TAGS2 = SET_CONFIG_ALLOWED_TAGS;
        ALLOWED_ATTR = SET_CONFIG_ALLOWED_ATTR;
      } else {
        _parseConfig(cfg);
      }
      if (hooks.uponSanitizeElement.length > 0 || hooks.uponSanitizeAttribute.length > 0) {
        ALLOWED_TAGS2 = clone(ALLOWED_TAGS2);
      }
      if (hooks.uponSanitizeAttribute.length > 0) {
        ALLOWED_ATTR = clone(ALLOWED_ATTR);
      }
      DOMPurify.removed = [];
      const inPlace = IN_PLACE && typeof dirty !== "string" && _isNode(dirty);
      if (inPlace) {
        _neutralizePatchLinkage(dirty);
        const nn = getNodeName ? getNodeName(dirty) : dirty.nodeName;
        if (typeof nn === "string") {
          const tagName = transformCaseFunc(nn);
          if (!ALLOWED_TAGS2[tagName] || FORBID_TAGS[tagName]) {
            _neutralizeRoot(dirty);
            throw typeErrorCreate("root node is forbidden and cannot be sanitized in-place");
          }
        }
        if (_isClobbered(dirty)) {
          _neutralizeRoot(dirty);
          throw typeErrorCreate("root node is clobbered and cannot be sanitized in-place");
        }
        try {
          _sanitizeAttachedShadowRoots(dirty);
        } catch (error) {
          _neutralizeRoot(dirty);
          throw error;
        }
      } else if (_isNode(dirty)) {
        body = _initDocument("<!---->");
        importedNode = body.ownerDocument.importNode(dirty, true);
        if (importedNode.nodeType === NODE_TYPE.element && importedNode.nodeName === "BODY") {
          body = importedNode;
        } else if (importedNode.nodeName === "HTML") {
          body = importedNode;
        } else {
          body.appendChild(importedNode);
        }
        _sanitizeAttachedShadowRoots(importedNode);
      } else {
        if (!RETURN_DOM && !SAFE_FOR_TEMPLATES && !WHOLE_DOCUMENT && // eslint-disable-next-line unicorn/prefer-includes
        dirty.indexOf("<") === -1) {
          return trustedTypesPolicy && RETURN_TRUSTED_TYPE ? _createTrustedHTML(dirty) : dirty;
        }
        body = _initDocument(dirty);
        if (!body) {
          return RETURN_DOM ? null : RETURN_TRUSTED_TYPE ? emptyHTML : "";
        }
      }
      if (body && FORCE_BODY) {
        _forceRemove(body.firstChild);
      }
      const walkRoot = inPlace ? dirty : body;
      try {
        const nodeIterator = _createNodeIterator(walkRoot);
        while (currentNode = nodeIterator.nextNode()) {
          _sanitizeElements(currentNode, walkRoot);
          _sanitizeAttributes(currentNode);
          if (_isDocumentFragment(currentNode.content)) {
            _sanitizeShadowDOM2(currentNode.content);
          }
        }
      } catch (error) {
        if (inPlace) {
          _neutralizeRoot(dirty);
          arrayForEach(DOMPurify.removed, (entry) => {
            if (entry.element) {
              _neutralizeSubtree(entry.element);
            }
          });
        }
        throw error;
      }
      if (inPlace) {
        arrayForEach(DOMPurify.removed, (entry) => {
          if (entry.element) {
            _neutralizeSubtree(entry.element);
          }
        });
        if (SAFE_FOR_TEMPLATES) {
          _scrubTemplateExpressions2(dirty);
        }
        return dirty;
      }
      if (RETURN_DOM) {
        if (SAFE_FOR_TEMPLATES) {
          _scrubTemplateExpressions2(body);
        }
        if (RETURN_DOM_FRAGMENT) {
          returnNode = createDocumentFragment.call(body.ownerDocument);
          while (body.firstChild) {
            returnNode.appendChild(body.firstChild);
          }
        } else {
          returnNode = body;
        }
        if (ALLOWED_ATTR.shadowroot || ALLOWED_ATTR.shadowrootmode) {
          returnNode = importNode.call(originalDocument, returnNode, true);
        }
        return returnNode;
      }
      let serializedHTML = WHOLE_DOCUMENT ? body.outerHTML : body.innerHTML;
      if (WHOLE_DOCUMENT && ALLOWED_TAGS2["!doctype"] && body.ownerDocument && body.ownerDocument.doctype && body.ownerDocument.doctype.name && regExpTest(DOCTYPE_NAME, body.ownerDocument.doctype.name)) {
        serializedHTML = "<!DOCTYPE " + body.ownerDocument.doctype.name + ">\n" + serializedHTML;
      }
      if (SAFE_FOR_TEMPLATES) {
        serializedHTML = _stripTemplateExpressions(serializedHTML);
      }
      return trustedTypesPolicy && RETURN_TRUSTED_TYPE ? _createTrustedHTML(serializedHTML) : serializedHTML;
    };
    DOMPurify.setConfig = function() {
      let cfg = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
      _parseConfig(cfg);
      SET_CONFIG = true;
      SET_CONFIG_ALLOWED_TAGS = ALLOWED_TAGS2;
      SET_CONFIG_ALLOWED_ATTR = ALLOWED_ATTR;
    };
    DOMPurify.clearConfig = function() {
      CONFIG = null;
      SET_CONFIG = false;
      SET_CONFIG_ALLOWED_TAGS = null;
      SET_CONFIG_ALLOWED_ATTR = null;
      trustedTypesPolicy = defaultTrustedTypesPolicy;
      emptyHTML = "";
    };
    DOMPurify.isValidAttribute = function(tag, attr, value) {
      if (!CONFIG) {
        _parseConfig({});
      }
      const lcTag = transformCaseFunc(tag);
      const lcName = transformCaseFunc(attr);
      return _isValidAttribute(lcTag, lcName, value);
    };
    DOMPurify.addHook = function(entryPoint, hookFunction) {
      if (typeof hookFunction !== "function") {
        return;
      }
      if (!objectHasOwnProperty(hooks, entryPoint)) {
        return;
      }
      arrayPush(hooks[entryPoint], hookFunction);
    };
    DOMPurify.removeHook = function(entryPoint, hookFunction) {
      if (!objectHasOwnProperty(hooks, entryPoint)) {
        return void 0;
      }
      if (hookFunction !== void 0) {
        const index = arrayLastIndexOf(hooks[entryPoint], hookFunction);
        return index === -1 ? void 0 : arraySplice(hooks[entryPoint], index, 1)[0];
      }
      return arrayPop(hooks[entryPoint]);
    };
    DOMPurify.removeHooks = function(entryPoint) {
      if (!objectHasOwnProperty(hooks, entryPoint)) {
        return;
      }
      hooks[entryPoint] = [];
    };
    DOMPurify.removeAllHooks = function() {
      hooks = _createHooksMap();
    };
    return DOMPurify;
  }
  var purify = createDOMPurify();

  // src/archive/sanitize.ts
  var HTML_NAMESPACE2 = "http://www.w3.org/1999/xhtml";
  var ARCHIVE_BASE = "https://archive.invalid/pages/current.html";
  var CANVAS_HOSTNAME = new URL(CANVAS_ORIGIN).hostname;
  var CONTROL3 = /[\p{Cc}\p{Cf}\p{Cs}]/u;
  var ENCODED_CONTROL3 = /%(?:0[0-9a-f]|1[0-9a-f]|7f)/iu;
  var SAFE_FRAGMENT = /^#[a-z0-9][a-z0-9_.:-]*$/iu;
  var LOCAL_PREFIX = /^\.\.\/(?:files|pages)\//u;
  var ENCODED_SEPARATOR2 = /%(?:2f|5c)/iu;
  var ARIA_ATTRIBUTE = /^aria-[a-z][a-z0-9-]*$/u;
  var ALLOWED_TAGS = [
    "a",
    "abbr",
    "article",
    "aside",
    "b",
    "blockquote",
    "br",
    "caption",
    "cite",
    "code",
    "col",
    "colgroup",
    "dd",
    "del",
    "details",
    "dfn",
    "div",
    "dl",
    "dt",
    "em",
    "figcaption",
    "figure",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "hr",
    "i",
    "img",
    "kbd",
    "li",
    "mark",
    "ol",
    "p",
    "pre",
    "q",
    "s",
    "samp",
    "section",
    "small",
    "span",
    "strong",
    "sub",
    "summary",
    "sup",
    "table",
    "tbody",
    "td",
    "tfoot",
    "th",
    "thead",
    "time",
    "tr",
    "u",
    "ul",
    "var"
  ];
  var ALLOWED_ATTRIBUTES = [
    "abbr",
    "alt",
    "aria-describedby",
    "aria-label",
    "class",
    "colspan",
    "datetime",
    "dir",
    "headers",
    "height",
    "href",
    "id",
    "lang",
    "rel",
    "reversed",
    "role",
    "rowspan",
    "scope",
    "span",
    "start",
    "title",
    "type",
    "value",
    "width"
  ];
  var GLOBAL_ATTRIBUTES = /* @__PURE__ */ new Set([
    "class",
    "dir",
    "id",
    "lang",
    "role",
    "title"
  ]);
  var ELEMENT_ATTRIBUTES = {
    a: /* @__PURE__ */ new Set(["href", "rel"]),
    col: /* @__PURE__ */ new Set(["span", "width"]),
    colgroup: /* @__PURE__ */ new Set(["span", "width"]),
    del: /* @__PURE__ */ new Set(["datetime"]),
    img: /* @__PURE__ */ new Set(["alt", "height", "width"]),
    li: /* @__PURE__ */ new Set(["value"]),
    ol: /* @__PURE__ */ new Set(["reversed", "start", "type"]),
    td: /* @__PURE__ */ new Set(["abbr", "colspan", "headers", "rowspan"]),
    th: /* @__PURE__ */ new Set(["abbr", "colspan", "headers", "rowspan", "scope"]),
    time: /* @__PURE__ */ new Set(["datetime"])
  };
  var descriptorValue = (input, key) => {
    let descriptor;
    try {
      descriptor = Object.getOwnPropertyDescriptor(input, key);
    } catch {
      throw new TypeError("Invalid page input");
    }
    if (!descriptor || !("value" in descriptor)) {
      throw new TypeError("Invalid page input");
    }
    return descriptor.value;
  };
  var validateInput = (input) => {
    if (typeof input !== "object" || input === null || Array.isArray(input)) {
      throw new TypeError("Invalid page input");
    }
    const title = descriptorValue(input, "title");
    const body = descriptorValue(input, "body");
    const resolveLocalHref2 = descriptorValue(input, "resolveLocalHref");
    if (typeof title !== "string" || typeof body !== "string" || typeof resolveLocalHref2 !== "function") {
      throw new TypeError("Invalid page input");
    }
    return {
      title,
      body,
      resolveLocalHref: resolveLocalHref2
    };
  };
  var isAllowedAttribute = (element, name) => {
    if (ARIA_ATTRIBUTE.test(name)) return true;
    if (GLOBAL_ATTRIBUTES.has(name)) return true;
    return ELEMENT_ATTRIBUTES[element.localName]?.has(name) ?? false;
  };
  var auditAttributes = (root) => {
    for (const element of root.querySelectorAll("*")) {
      if (element.namespaceURI !== HTML_NAMESPACE2) {
        element.remove();
        continue;
      }
      const retained = [...element.attributes].filter((attribute) => {
        const name = attribute.name.toLowerCase();
        return attribute.namespaceURI === null && !name.includes(":") && !name.startsWith("on") && name !== "style" && isAllowedAttribute(element, name);
      }).sort(
        (left, right) => left.name < right.name ? -1 : left.name > right.name ? 1 : 0
      );
      for (const attribute of [...element.attributes]) {
        element.removeAttributeNode(attribute);
      }
      for (const attribute of retained) {
        element.setAttribute(attribute.name.toLowerCase(), attribute.value);
      }
    }
  };
  var stripShellIdentity = (root) => {
    for (const element of root.querySelectorAll("*")) {
      element.removeAttribute("class");
      element.removeAttribute("id");
      element.removeAttribute("role");
      element.removeAttribute("aria-describedby");
      if (element.localName === "a" && element.getAttribute("href")?.startsWith("#")) {
        element.removeAttribute("href");
        element.removeAttribute("rel");
      }
    }
  };
  var normalizeFragmentHeadings = (root) => {
    for (const heading of root.querySelectorAll("h1")) {
      const replacement = document.createElement("h2");
      for (const child of [...heading.childNodes]) replacement.append(child);
      heading.replaceWith(replacement);
    }
  };
  var isSafeLocalHref = (value) => {
    if (!LOCAL_PREFIX.test(value) || CONTROL3.test(value) || value.includes("\\") || value.includes(":") || value.includes("?") || value.includes("#") || value.includes("//")) {
      return false;
    }
    if (ENCODED_SEPARATOR2.test(value)) {
      return false;
    }
    const encodedPath2 = value.slice(3);
    let decodedPath;
    try {
      decodedPath = decodeURIComponent(
        encodedPath2.replace(/%(?![0-9a-f]{2})/giu, "%25")
      );
    } catch {
      return false;
    }
    if (!decodedPath.startsWith("files/") && !decodedPath.startsWith("pages/") || !isCanonicalArchivePath(decodedPath)) {
      return false;
    }
    let url;
    try {
      url = new URL(value, ARCHIVE_BASE);
    } catch {
      return false;
    }
    return url.origin === "https://archive.invalid" && url.username === "" && url.password === "" && url.search === "" && url.hash === "" && (/^\/(?:files|pages)\/[^/]/u.test(url.pathname) || /^\/(?:files|pages)\/.+\/[^/]/u.test(url.pathname));
  };
  var canonicalDnsHostname = (hostname) => hostname.toLowerCase().replace(/\.+$/u, "");
  var unresolvedHref = (raw) => {
    let decoded;
    try {
      decoded = decodeURI(raw);
    } catch {
      return null;
    }
    if (raw !== raw.trim() || CONTROL3.test(raw) || CONTROL3.test(decoded) || ENCODED_CONTROL3.test(raw) || raw.includes("\\")) {
      return null;
    }
    if (SAFE_FRAGMENT.test(raw)) return raw;
    if (raw.startsWith("#") || raw.startsWith("//")) return null;
    if (!/^https:\/\/[^/?#]+(?:[/?#]|$)/iu.test(raw) && !/^mailto:[^/\s]/iu.test(raw)) {
      return null;
    }
    let url;
    try {
      url = new URL(raw);
    } catch {
      return null;
    }
    if (url.protocol !== "https:" && url.protocol !== "mailto:" || url.username !== "" || url.password !== "" || url.protocol === "https:" && canonicalDnsHostname(url.hostname) === canonicalDnsHostname(CANVAS_HOSTNAME)) {
      return null;
    }
    return url.href;
  };
  var rewriteAnchors = (root, resolveLocalHref2) => {
    for (const anchor of root.querySelectorAll("a[href]")) {
      const raw = anchor.getAttribute("href");
      if (raw === null) continue;
      anchor.removeAttribute("rel");
      let resolved;
      try {
        resolved = Reflect.apply(resolveLocalHref2, void 0, [raw]);
      } catch {
        anchor.removeAttribute("href");
        continue;
      }
      if (resolved !== null) {
        if (typeof resolved === "string" && isSafeLocalHref(resolved)) {
          anchor.setAttribute("href", resolved);
        } else {
          anchor.removeAttribute("href");
        }
        continue;
      }
      const retained = unresolvedHref(raw);
      if (retained === null) {
        anchor.removeAttribute("href");
        continue;
      }
      anchor.setAttribute("href", retained);
      if (!retained.startsWith("#")) {
        anchor.setAttribute("rel", "noopener noreferrer");
      }
    }
  };
  function sanitizePageFragment(input) {
    const { body, resolveLocalHref: resolveLocalHref2 } = validateInput(input);
    const sanitized = purify.sanitize(body, {
      ALLOWED_TAGS: [...ALLOWED_TAGS],
      ALLOWED_ATTR: [...ALLOWED_ATTRIBUTES],
      ALLOWED_NAMESPACES: [HTML_NAMESPACE2],
      ALLOWED_URI_REGEXP: /^[\s\S]*$/u,
      ALLOW_ARIA_ATTR: true,
      ALLOW_DATA_ATTR: false,
      ALLOW_UNKNOWN_PROTOCOLS: false,
      CUSTOM_ELEMENT_HANDLING: {
        tagNameCheck: null,
        attributeNameCheck: null,
        allowCustomizedBuiltInElements: false
      },
      FORBID_TAGS: [
        "base",
        "button",
        "embed",
        "form",
        "iframe",
        "input",
        "link",
        "math",
        "meta",
        "object",
        "script",
        "select",
        "style",
        "svg",
        "template",
        "textarea"
      ],
      KEEP_CONTENT: true,
      RETURN_DOM_FRAGMENT: true,
      SANITIZE_DOM: true,
      SAFE_FOR_XML: true
    });
    const container = document.createElement("div");
    container.append(sanitized);
    normalizeFragmentHeadings(container);
    stripShellIdentity(container);
    auditAttributes(container);
    rewriteAnchors(container, resolveLocalHref2);
    auditAttributes(container);
    return container.innerHTML;
  }
  var renderSavedPageHtml = (input) => renderArchiveShell({
    pagePath: input.pagePath,
    pageKind: "saved-page",
    title: input.title,
    course: input.model.manifest.course,
    combinedHomeHref: input.combinedHomeHref,
    contentHtml: `<article class="saved-page-content"><h1>${escapeHtml(input.title)}</h1>${input.sanitizedFragment}</article>`
  });

  // src/page/course-parts.ts
  var resourceWeight = (resource) => {
    if (resource.kind === "page") return MAX_ARCHIVED_PAGE_BYTES;
    if (resource.kind !== "file") return 0;
    return resource.advertisedBytes;
  };
  var freezeParts = (groups, resources) => {
    const total = groups.length;
    const partByKey = /* @__PURE__ */ new Map();
    for (const [groupIndex, keys] of groups.entries()) {
      for (const key of keys) {
        if (partByKey.has(key)) throw new TypeError("Duplicate part resource");
        partByKey.set(key, groupIndex + 1);
      }
    }
    if (partByKey.size !== resources.length || resources.some((resource) => !partByKey.has(resource.key))) {
      throw new TypeError("Incomplete part resources");
    }
    const resourceParts = resources.map((resource) => ({
      resourceKey: resource.key,
      partIndex: partByKey.get(resource.key)
    }));
    resourceParts.forEach(Object.freeze);
    Object.freeze(resourceParts);
    const parts = groups.map((resourceKeys2, index) => {
      const keys = [...resourceKeys2];
      Object.freeze(keys);
      return Object.freeze({
        index: index + 1,
        total,
        resourceKeys: keys,
        resourceParts
      });
    });
    return Object.freeze(parts);
  };
  var partitionCoursePlan = (plan) => {
    assertCoursePlanSizes(plan);
    if (plan.resources.length > MAX_ARCHIVE_RESOURCES) {
      throw new TypeError("Archive resource limit exceeded");
    }
    const resourceKeys2 = new Set(plan.resources.map((resource) => resource.key));
    if (resourceKeys2.size !== plan.resources.length) {
      throw new TypeError("Duplicate planned resource");
    }
    const terminalKeys = plan.resources.filter(
      (resource) => resource.kind === "external" || resource.kind === "unsupported"
    ).map((resource) => resource.key);
    const terminalKeySet = new Set(terminalKeys);
    const groups = [];
    let current = [];
    let bytes = 0;
    let entryLimit = MAX_ARCHIVE_RESOURCES - terminalKeys.length;
    const flush = () => {
      if (current.length === 0) return;
      groups.push(current);
      current = [];
      bytes = 0;
      entryLimit = MAX_ARCHIVE_RESOURCES;
    };
    for (const resource of plan.resources) {
      if (terminalKeySet.has(resource.key)) continue;
      const weight = resourceWeight(resource);
      const isolated = resource.kind === "file" && weight === null || typeof weight === "number" && weight > MAX_ARCHIVE_BYTES;
      if (isolated) {
        flush();
        groups.push([resource.key]);
        entryLimit = MAX_ARCHIVE_RESOURCES;
        continue;
      }
      const nextBytes = bytes + (weight ?? 0);
      if (current.length > 0 && (nextBytes > MAX_ARCHIVE_BYTES || current.length + 1 > entryLimit)) {
        flush();
      }
      current.push(resource.key);
      bytes += weight ?? 0;
    }
    flush();
    if (groups.length === 0) groups.push([]);
    const firstPayloadKeys = new Set(groups[0]);
    groups[0] = plan.resources.filter(
      (resource) => terminalKeySet.has(resource.key) || firstPayloadKeys.has(resource.key)
    ).map((resource) => resource.key);
    return freezeParts(groups, plan.resources);
  };
  var partFileName = (baseName, part) => {
    if (typeof baseName !== "string" || !baseName.endsWith(".zip") || !Number.isSafeInteger(part.index) || !Number.isSafeInteger(part.total) || part.index < 1 || part.total < 1 || part.index > part.total) {
      throw new TypeError("Invalid archive part filename");
    }
    if (part.total === 1) return baseName;
    const width = Math.max(2, String(part.total).length);
    const index = String(part.index).padStart(width, "0");
    const total = String(part.total).padStart(width, "0");
    return `${baseName.slice(0, -4)}-part-${index}-of-${total}.zip`;
  };

  // src/page/run-course.ts
  var RunSafetyError = class extends TypeError {
    name = "RunSafetyError";
  };
  var abortError2 = (signal) => signal.reason instanceof DOMException && signal.reason.name === "AbortError" ? signal.reason : new DOMException("Packing was cancelled", "AbortError");
  var throwIfAborted = (signal) => {
    if (signal.aborted) throw abortError2(signal);
  };
  var freezeCoursePlan = (plan) => {
    const clone2 = {
      course: { ...plan.course },
      moduleDiscovery: plan.moduleDiscovery,
      modules: plan.modules.map((module) => ({
        ...module,
        items: module.items.map((item) => ({ ...item }))
      })),
      resources: plan.resources.map((resource) => ({ ...resource })),
      folderPathFallbackKeys: [...plan.folderPathFallbackKeys],
      advertisedBytes: plan.advertisedBytes
    };
    assertCoursePlanSizes(clone2);
    if (clone2.resources.length > MAX_ARCHIVE_RESOURCES2) {
      throw new RunSafetyError("Archive resource limit exceeded");
    }
    const fallbackKeys = new Set(clone2.folderPathFallbackKeys);
    if (fallbackKeys.size !== clone2.folderPathFallbackKeys.length) {
      throw new RunSafetyError("Invalid folder fallback keys");
    }
    for (const key of fallbackKeys) {
      const resource = clone2.resources.find((candidate) => candidate.key === key);
      if (resource?.kind !== "file" || resource.archivePath === null || !isCanonicalArchivePath(resource.archivePath) || !resource.archivePath.startsWith("files/unfiled/")) {
        throw new RunSafetyError("Invalid folder fallback keys");
      }
    }
    Object.freeze(clone2.course);
    clone2.modules.forEach((module) => {
      module.items.forEach(Object.freeze);
      Object.freeze(module.items);
      Object.freeze(module);
    });
    clone2.resources.forEach(Object.freeze);
    Object.freeze(clone2.modules);
    Object.freeze(clone2.resources);
    Object.freeze(clone2.folderPathFallbackKeys);
    return Object.freeze(clone2);
  };
  var terminalOutcome = (resource, status2) => ({
    ...resource,
    status: status2,
    actualBytes: 0,
    failureCategory: null
  });
  var removeUnavailableLocalLinks = (fragment, pagePath, entries2) => {
    const document3 = new DOMParser().parseFromString(
      `<body>${fragment}</body>`,
      "text/html"
    );
    const base = `https://archive.invalid/${pagePath.split("/").map(encodeURIComponent).join("/")}`;
    for (const anchor of document3.body.querySelectorAll("a[href]")) {
      const href = anchor.getAttribute("href");
      if (href === null || href.startsWith("#") || /^[a-z][a-z0-9+.-]*:/iu.test(href))
        continue;
      let target;
      try {
        target = decodeURIComponent(new URL(href, base).pathname.slice(1));
      } catch {
        anchor.removeAttribute("href");
        anchor.removeAttribute("rel");
        continue;
      }
      if (!entries2.has(target)) {
        anchor.removeAttribute("href");
        anchor.removeAttribute("rel");
      }
    }
    return document3.body.innerHTML;
  };
  async function buildCourseArchive(options) {
    const {
      course,
      plan,
      partPlan,
      combinedRoot,
      signal,
      progress,
      dependencies
    } = options;
    if (combinedRoot !== null && !isCanonicalArchivePath(combinedRoot)) {
      throw new RunSafetyError("Invalid combined course root");
    }
    const controller = new AbortController();
    const onCallerAbort = () => controller.abort(abortError2(signal));
    signal.addEventListener("abort", onCallerAbort, { once: true });
    if (signal.aborted) onCallerAbort();
    const entries2 = /* @__PURE__ */ new Map();
    const retained = /* @__PURE__ */ new Set();
    let terminalCause;
    let zipBytes;
    let succeeded = false;
    try {
      let drainRetrievalWaiters2 = function() {
        if (controller.signal.aborted || exclusiveRetrievalActive) return;
        const first = retrievalWaiters[0];
        if (!first) return;
        if (first.exclusive) {
          if (activeSharedRetrievals > 0) return;
          retrievalWaiters.shift();
          admitRetrievalWaiter2(first);
          return;
        }
        while (retrievalWaiters[0] && !retrievalWaiters[0].exclusive) {
          admitRetrievalWaiter2(retrievalWaiters.shift());
        }
      }, createRetrievalRelease2 = function(exclusive) {
        let released = false;
        return () => {
          if (released) return;
          released = true;
          if (exclusive) exclusiveRetrievalActive = false;
          else activeSharedRetrievals -= 1;
          drainRetrievalWaiters2();
        };
      }, admitRetrieval2 = function(exclusive) {
        if (exclusive) exclusiveRetrievalActive = true;
        else activeSharedRetrievals += 1;
        return createRetrievalRelease2(exclusive);
      }, admitRetrievalWaiter2 = function(waiter) {
        if (waiter.settled) return;
        waiter.settled = true;
        controller.signal.removeEventListener("abort", waiter.onAbort);
        waiter.resolve(admitRetrieval2(waiter.exclusive));
      };
      var drainRetrievalWaiters = drainRetrievalWaiters2, createRetrievalRelease = createRetrievalRelease2, admitRetrieval = admitRetrieval2, admitRetrievalWaiter = admitRetrievalWaiter2;
      throwIfAborted(controller.signal);
      const immutablePlan = freezeCoursePlan(plan);
      if (immutablePlan.course.id !== course.id) {
        throw new RunSafetyError("Discovered course does not match selection");
      }
      const activePart = partPlan;
      if (activePart) {
        const canonicalParts = partitionCoursePlan(immutablePlan);
        const canonicalPart = canonicalParts[activePart.index - 1];
        if (!canonicalPart || activePart.total !== canonicalPart.total || activePart.resourceKeys.length !== canonicalPart.resourceKeys.length || activePart.resourceKeys.some(
          (key, index) => key !== canonicalPart.resourceKeys[index]
        ) || activePart.resourceParts.length !== canonicalPart.resourceParts.length || activePart.resourceParts.some((assignment, index) => {
          const canonical = canonicalPart.resourceParts[index];
          return assignment.resourceKey !== canonical?.resourceKey || assignment.partIndex !== canonical.partIndex;
        })) {
          throw new RunSafetyError("Invalid course archive part");
        }
      }
      const resourcesByKey = new Map(
        immutablePlan.resources.map((resource) => [resource.key, resource])
      );
      const localResources = (activePart?.resourceKeys ?? immutablePlan.resources.map((resource) => resource.key)).map((key) => {
        const resource = resourcesByKey.get(key);
        if (!resource) throw new RunSafetyError("Invalid course archive part");
        return resource;
      });
      throwIfAborted(controller.signal);
      const outcomes = new Array(localResources.length);
      let cursor = 0;
      let completed = 0;
      let failed = 0;
      let successfulBytes = 0;
      const byteLimit = dependencies.maxArchiveBytes ?? MAX_ARCHIVE_BYTES;
      const pageByteLimit = dependencies.maxArchivedPageBytes ?? MAX_ARCHIVED_PAGE_BYTES;
      if (!Number.isSafeInteger(byteLimit) || byteLimit < 0 || byteLimit > MAX_ARCHIVE_BYTES) {
        throw new RunSafetyError("Invalid archive byte limit");
      }
      if (!Number.isSafeInteger(pageByteLimit) || pageByteLimit < 1 || pageByteLimit > MAX_ARCHIVED_PAGE_BYTES) {
        throw new RunSafetyError("Invalid archived page byte limit");
      }
      const latchTerminalCause = (error) => {
        const cause = error instanceof Error || error instanceof DOMException ? error : new RunSafetyError("Retrieval failed");
        terminalCause ??= cause;
        controller.abort(terminalCause);
        return cause;
      };
      let activeSharedRetrievals = 0;
      let exclusiveRetrievalActive = false;
      const retrievalWaiters = [];
      const acquireRetrieval = (exclusive) => {
        throwIfAborted(controller.signal);
        if (retrievalWaiters.length === 0 && !exclusiveRetrievalActive && (!exclusive || activeSharedRetrievals === 0)) {
          return admitRetrieval2(exclusive);
        }
        return new Promise((resolve, reject) => {
          const waiter = {
            exclusive,
            settled: false,
            resolve,
            reject,
            onAbort: () => void 0
          };
          waiter.onAbort = () => {
            if (waiter.settled) return;
            waiter.settled = true;
            const index = retrievalWaiters.indexOf(waiter);
            if (index >= 0) retrievalWaiters.splice(index, 1);
            controller.signal.removeEventListener("abort", waiter.onAbort);
            waiter.reject(abortError2(controller.signal));
            drainRetrievalWaiters2();
          };
          retrievalWaiters.push(waiter);
          controller.signal.addEventListener("abort", waiter.onAbort, {
            once: true
          });
          if (controller.signal.aborted) waiter.onAbort();
        });
      };
      const work = async () => {
        for (; ; ) {
          if (terminalCause !== void 0 || controller.signal.aborted) return;
          const index = cursor;
          if (index >= localResources.length) return;
          cursor += 1;
          const resource = localResources[index];
          try {
            let outcome;
            if (resource.kind === "external" || resource.kind === "unsupported") {
              outcome = terminalOutcome(resource, resource.kind);
            } else {
              progress({
                stage: resource.kind === "page" ? "sanitize" : "download",
                completed,
                total: localResources.length,
                failed
              });
              if (resource.kind === "file" && resource.advertisedBytes !== null && resource.advertisedBytes > MAX_ARCHIVE_BYTES) {
                failed += 1;
                outcome = {
                  ...resource,
                  status: "unavailable",
                  actualBytes: null,
                  failureCategory: "individual-size-limit"
                };
              } else {
                if (resource.kind === "file") {
                  validatedFileUrl(resource, immutablePlan.course.id);
                }
                let releaseRetrieval;
                try {
                  const exclusive = resource.kind === "file" && resource.advertisedBytes === null;
                  const admission = acquireRetrieval(exclusive);
                  releaseRetrieval = typeof admission === "function" ? admission : await admission;
                  const remainingBytes = byteLimit - successfulBytes;
                  if (!Number.isSafeInteger(remainingBytes) || remainingBytes < 0 || remainingBytes > MAX_ARCHIVE_BYTES) {
                    throw new RunSafetyError(
                      "Invalid remaining archive byte limit"
                    );
                  }
                  const result = await dependencies.retrieve(
                    resource,
                    immutablePlan,
                    controller.signal,
                    remainingBytes
                  );
                  if (controller.signal.aborted && result.status === "success") {
                    result.bytes.fill(0);
                  }
                  throwIfAborted(controller.signal);
                  if (result.status === "success") {
                    if (!resource.archivePath || !isCanonicalArchivePath(resource.archivePath)) {
                      result.bytes.fill(0);
                      throw new RunSafetyError("Invalid planned archive path");
                    }
                    successfulBytes += result.bytes.byteLength;
                    if (!Number.isSafeInteger(successfulBytes) || successfulBytes > byteLimit) {
                      result.bytes.fill(0);
                      throw new RunSafetyError("Archive byte limit exceeded");
                    }
                    retained.add(result.bytes);
                    entries2.set(resource.archivePath, result.bytes);
                    outcome = {
                      ...resource,
                      status: "success",
                      actualBytes: result.bytes.byteLength,
                      failureCategory: null
                    };
                  } else {
                    failed += 1;
                    outcome = {
                      ...resource,
                      status: result.status,
                      actualBytes: null,
                      failureCategory: result.failureCategory
                    };
                  }
                } catch (error) {
                  if (releaseRetrieval !== void 0) {
                    latchTerminalCause(error);
                  }
                  throw error;
                } finally {
                  releaseRetrieval?.();
                }
              }
            }
            outcomes[index] = outcome;
            completed += 1;
            progress({
              stage: resource.kind === "page" ? "sanitize" : "download",
              completed,
              total: localResources.length,
              failed
            });
          } catch (error) {
            latchTerminalCause(error);
            return;
          }
        }
      };
      await Promise.allSettled(
        Array.from(
          { length: Math.min(MAX_CONCURRENCY, localResources.length) },
          work
        )
      );
      if (terminalCause !== void 0) {
        if (terminalCause instanceof Error || terminalCause instanceof DOMException) {
          throw terminalCause;
        }
        throw new RunSafetyError("Retrieval failed");
      }
      throwIfAborted(controller.signal);
      if (outcomes.some((outcome) => outcome === void 0)) {
        throw new RunSafetyError("Incomplete resource outcomes");
      }
      progress({
        stage: "package",
        completed,
        total: localResources.length,
        failed
      });
      dependencies.beforePackage?.();
      throwIfAborted(controller.signal);
      const createdAt = dependencies.now();
      const pageFragments = /* @__PURE__ */ new Map();
      for (const [index, resource] of localResources.entries()) {
        if (resource.kind !== "page" || outcomes[index]?.status !== "success" || resource.archivePath === null)
          continue;
        const fragmentBytes = entries2.get(resource.archivePath);
        if (!fragmentBytes)
          throw new RunSafetyError("Missing sanitized page fragment");
        pageFragments.set(resource.archivePath, fragmentBytes);
      }
      let model = buildArchiveNavigationModel(
        immutablePlan,
        outcomes,
        createdAt,
        activePart
      );
      let removedOversizedPage;
      do {
        removedOversizedPage = false;
        for (const [index, resource] of localResources.entries()) {
          if (resource.kind !== "page" || outcomes[index]?.status !== "success" || resource.archivePath === null)
            continue;
          const fragmentBytes = pageFragments.get(resource.archivePath);
          const currentBytes = entries2.get(resource.archivePath);
          if (!fragmentBytes || !currentBytes) {
            throw new RunSafetyError("Missing sanitized page fragment");
          }
          const wrapped = strToU8(
            renderSavedPageHtml({
              model,
              pagePath: resource.archivePath,
              title: resource.title,
              sanitizedFragment: removeUnavailableLocalLinks(
                strFromU8(fragmentBytes),
                resource.archivePath,
                entries2
              ),
              combinedHomeHref: combinedRoot === null ? null : relativeArchiveHref(
                `${combinedRoot}/${resource.archivePath}`,
                "index.html"
              )
            })
          );
          if (wrapped.byteLength > pageByteLimit) {
            wrapped.fill(0);
            successfulBytes -= currentBytes.byteLength;
            if (currentBytes !== fragmentBytes) currentBytes.fill(0);
            entries2.delete(resource.archivePath);
            outcomes[index] = {
              ...resource,
              status: "unavailable",
              actualBytes: null,
              failureCategory: "page-too-large"
            };
            failed += 1;
            removedOversizedPage = true;
            continue;
          }
          successfulBytes = successfulBytes - currentBytes.byteLength + wrapped.byteLength;
          if (!Number.isSafeInteger(successfulBytes) || successfulBytes > byteLimit) {
            wrapped.fill(0);
            throw new RunSafetyError("Archive byte limit exceeded");
          }
          if (currentBytes !== fragmentBytes) currentBytes.fill(0);
          retained.add(wrapped);
          entries2.set(resource.archivePath, wrapped);
          outcomes[index] = {
            ...outcomes[index],
            actualBytes: wrapped.byteLength
          };
        }
        model = buildArchiveNavigationModel(
          immutablePlan,
          outcomes,
          createdAt,
          activePart
        );
      } while (removedOversizedPage);
      const manifest = model.manifest;
      const pages = renderCoursePages(
        model,
        combinedRoot === null ? {} : {
          combinedHomeHref: relativeArchiveHref(
            `${combinedRoot}/index.html`,
            "index.html"
          )
        }
      );
      zipBytes = buildCourseZip({
        archiveRoot: combinedRoot,
        pages,
        archiveCss: dependencies.archiveCss,
        manifest,
        entries: entries2
      });
      throwIfAborted(controller.signal);
      succeeded = true;
      return { manifest, zipBytes };
    } finally {
      signal.removeEventListener("abort", onCallerAbort);
      entries2.clear();
      retained.forEach((bytes) => bytes.fill(0));
      if (!succeeded) zipBytes?.fill(0);
      retained.clear();
    }
  }
  var abortableDelay2 = (milliseconds, signal) => new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(abortError2(signal));
      return;
    }
    const timer = setTimeout(finish, milliseconds);
    const onAbort = () => {
      clearTimeout(timer);
      signal?.removeEventListener("abort", onAbort);
      reject(
        signal ? abortError2(signal) : new DOMException("Packing was cancelled", "AbortError")
      );
    };
    function finish() {
      signal?.removeEventListener("abort", onAbort);
      resolve();
    }
    signal?.addEventListener("abort", onAbort, { once: true });
  });
  var waitForRetry = async (milliseconds, signal, sleep) => {
    throwIfAborted(signal);
    await sleep(milliseconds, signal);
    throwIfAborted(signal);
  };
  var cancelBody = async (response) => {
    if (!response.body) return;
    try {
      await response.body.cancel();
    } catch {
    }
  };
  var validatedFileUrl = (resource, expectedCourseId) => {
    if (resource.kind !== "file" || resource.sourceUrl === null || resource.advertisedBytes !== null && (!Number.isSafeInteger(resource.advertisedBytes) || resource.advertisedBytes <= 0)) {
      throw new RunSafetyError("Invalid planned file");
    }
    let url;
    try {
      url = new URL(resource.sourceUrl);
    } catch {
      throw new RunSafetyError("Rejected planned file URL");
    }
    if (url.origin !== CANVAS_ORIGIN || url.protocol !== "https:" || url.username !== "" || url.password !== "" || url.hash !== "") {
      throw new RunSafetyError("Rejected planned file URL");
    }
    if (resource.advertisedBytes !== null) {
      if (url.pathname !== `/files/${resource.sourceId}/download`) {
        throw new RunSafetyError("Rejected planned file URL");
      }
      return url;
    }
    const match = /^\/courses\/([1-9]\d*)\/files\/([1-9]\d*)\/download$/u.exec(
      url.pathname
    );
    if (url.search !== "" || match === null || match[2] !== resource.sourceId || expectedCourseId !== void 0 && match[1] !== String(expectedCourseId)) {
      throw new RunSafetyError("Rejected planned file URL");
    }
    const courseId = expectedCourseId === void 0 ? match[1] : String(expectedCourseId);
    if (resource.sourceUrl !== `${CANVAS_ORIGIN}/courses/${courseId}/files/${resource.sourceId}/download`) {
      throw new RunSafetyError("Rejected planned file URL");
    }
    return url;
  };
  async function fetchFileResource(resource, callerSignal, transport = {}, remainingBytes) {
    const initial = validatedFileUrl(resource);
    const advertisedBytes = resource.advertisedBytes;
    if (advertisedBytes === null && (!Number.isSafeInteger(remainingBytes) || remainingBytes < 0 || remainingBytes > MAX_ARCHIVE_BYTES)) {
      throw new RunSafetyError("Invalid remaining archive byte limit");
    }
    const fetcher = transport.fetcher ?? fetch;
    const sleep = transport.sleep ?? abortableDelay2;
    const local = new AbortController();
    const onCallerAbort = () => local.abort(abortError2(callerSignal));
    callerSignal.addEventListener("abort", onCallerAbort, { once: true });
    if (callerSignal.aborted) onCallerAbort();
    try {
      for (let attempt = 0; attempt <= MAX_RETRIES; attempt += 1) {
        throwIfAborted(local.signal);
        let response;
        try {
          response = await fetcher(initial, {
            method: "GET",
            credentials: "include",
            redirect: "follow",
            signal: local.signal
          });
        } catch (error) {
          if (local.signal.aborted) throw abortError2(local.signal);
          if (!(error instanceof TypeError)) {
            throw new CanvasResponseError("File request failed");
          }
          if (attempt === MAX_RETRIES) {
            return { status: "failed", failureCategory: "network-exhausted" };
          }
          await waitForRetry(250 * 2 ** attempt, local.signal, sleep);
          continue;
        }
        let finalUrl;
        try {
          if (typeof response.url !== "string" || response.url.length === 0) {
            throw new TypeError("Missing final response URL");
          }
          finalUrl = new URL(response.url);
        } catch {
          await cancelBody(response);
          throw new RunSafetyError("Rejected file response URL");
        }
        if (finalUrl.protocol !== "https:" || finalUrl.username !== "" || finalUrl.password !== "" || finalUrl.hash !== "") {
          await cancelBody(response);
          throw new RunSafetyError("Rejected file response URL");
        }
        const contentType = (response.headers.get("content-type") ?? "").toLowerCase();
        if (response.status === 401 || /\/login(?:\/|$)/u.test(finalUrl.pathname) || contentType.includes("text/html")) {
          await cancelBody(response);
          throw new CanvasSessionError("Canvas session is unavailable");
        }
        if (response.status === 403 || response.status === 404) {
          await cancelBody(response);
          return {
            status: "unavailable",
            failureCategory: response.status === 403 ? "access-denied" : "not-found"
          };
        }
        if (response.status === 408 || response.status === 429 || response.status >= 500) {
          await cancelBody(response);
          if (attempt === MAX_RETRIES) {
            return { status: "failed", failureCategory: "transient-exhausted" };
          }
          await waitForRetry(250 * 2 ** attempt, local.signal, sleep);
          continue;
        }
        if (!response.ok) {
          await cancelBody(response);
          throw new RunSafetyError("Rejected file response");
        }
        const rawLength = response.headers.get("content-length");
        let declaredBytes = null;
        if (rawLength !== null) {
          const validLength = advertisedBytes === null ? /^[1-9]\d*$/u.test(rawLength) : /^(?:0|[1-9]\d*)$/u.test(rawLength);
          if (!validLength) {
            await cancelBody(response);
            throw new RunSafetyError("Invalid file content length");
          }
          const declared = Number(rawLength);
          if (!Number.isSafeInteger(declared)) {
            await cancelBody(response);
            throw new RunSafetyError("Invalid file content length");
          }
          if (advertisedBytes !== null && declared !== advertisedBytes) {
            await cancelBody(response);
            throw new RunSafetyError("File content length changed");
          }
          if (advertisedBytes === null && declared > remainingBytes) {
            await cancelBody(response);
            return {
              status: "unavailable",
              failureCategory: "individual-size-limit"
            };
          }
          declaredBytes = declared;
        }
        if (!response.body) {
          throw new RunSafetyError("File response body is unavailable");
        }
        const reader = response.body.getReader();
        let output;
        const chunks = [];
        let rejectReadAbort = () => {
        };
        const readAbort = new Promise((_resolve, reject) => {
          rejectReadAbort = reject;
        });
        const onReadAbort = () => rejectReadAbort(abortError2(local.signal));
        local.signal.addEventListener("abort", onReadAbort, { once: true });
        try {
          if (advertisedBytes === null) {
            let total = 0;
            for (; ; ) {
              throwIfAborted(local.signal);
              const value = await Promise.race([reader.read(), readAbort]);
              throwIfAborted(local.signal);
              if (value.done) break;
              chunks.push(value.value);
              if (value.value.byteLength === 0) {
                throw new RunSafetyError("Invalid file stream chunk");
              }
              if (value.value.byteLength > remainingBytes - total) {
                await reader.cancel();
                chunks.forEach((chunk) => chunk.fill(0));
                chunks.length = 0;
                reader.releaseLock();
                return {
                  status: "unavailable",
                  failureCategory: "individual-size-limit"
                };
              }
              if (declaredBytes !== null && value.value.byteLength > declaredBytes - total) {
                throw new RunSafetyError("File content length changed");
              }
              total += value.value.byteLength;
            }
            if (total === 0) {
              throw new RunSafetyError("File stream size changed");
            }
            if (declaredBytes !== null && total !== declaredBytes) {
              throw new RunSafetyError("File content length changed");
            }
            output = new Uint8Array(total);
            let offset = 0;
            for (const chunk of chunks) {
              output.set(chunk, offset);
              offset += chunk.byteLength;
            }
            chunks.forEach((chunk) => chunk.fill(0));
            chunks.length = 0;
          } else {
            output = new Uint8Array(advertisedBytes);
            let offset = 0;
            for (; ; ) {
              throwIfAborted(local.signal);
              const value = await Promise.race([reader.read(), readAbort]);
              throwIfAborted(local.signal);
              if (value.done) break;
              if (value.value.byteLength === 0) {
                throw new RunSafetyError("Invalid file stream chunk");
              }
              if (value.value.byteLength > advertisedBytes - offset) {
                throw new RunSafetyError("File stream exceeded advertised size");
              }
              output.set(value.value, offset);
              offset += value.value.byteLength;
            }
            if (offset === 0 || offset !== advertisedBytes) {
              throw new RunSafetyError("File stream size changed");
            }
          }
          reader.releaseLock();
          return { status: "success", bytes: output };
        } catch (error) {
          local.abort(error);
          try {
            await reader.cancel();
          } catch {
          }
          output?.fill(0);
          chunks.forEach((chunk) => chunk.fill(0));
          chunks.length = 0;
          if (local.signal.reason instanceof DOMException && local.signal.reason.name === "AbortError") {
            throw local.signal.reason;
          }
          throw error;
        } finally {
          local.signal.removeEventListener("abort", onReadAbort);
        }
      }
      return { status: "failed", failureCategory: "transient-exhausted" };
    } finally {
      callerSignal.removeEventListener("abort", onCallerAbort);
      local.abort();
    }
  }
  var encodeArchiveHref = (path) => `../${path.split("/").map((segment) => encodeURIComponent(segment)).join("/")}`;
  function resolveLocalHref(raw, plan) {
    if (typeof raw !== "string" || raw !== raw.trim() || raw.includes("\\"))
      return null;
    let url;
    try {
      url = new URL(raw, CANVAS_ORIGIN);
    } catch {
      return null;
    }
    if (url.origin !== CANVAS_ORIGIN || url.username !== "" || url.password !== "" || url.hash !== "")
      return null;
    const courseId = String(plan.course.id);
    const fileMatch = new RegExp(
      `^/courses/${courseId}/files/([1-9]\\d*)(/download)?$`,
      "u"
    ).exec(url.pathname);
    if (fileMatch) {
      const wrap = url.search === "?wrap=1";
      if (url.search !== "" && !wrap || fileMatch[2] === void 0 && !wrap) {
        return null;
      }
      const resource = plan.resources.find(
        (candidate) => candidate.kind === "file" && candidate.sourceId === fileMatch[1]
      );
      return resource?.archivePath ? encodeArchiveHref(resource.archivePath) : null;
    }
    const pageMatch = new RegExp(
      `^/courses/${courseId}/pages/([a-zA-Z0-9_-]{1,255})$`,
      "u"
    ).exec(url.pathname);
    if (pageMatch && url.search === "") {
      const resource = plan.resources.find(
        (candidate) => candidate.kind === "page" && candidate.sourceId === pageMatch[1]
      );
      return resource?.archivePath ? encodeArchiveHref(resource.archivePath) : null;
    }
    return null;
  }
  async function fetchPageResource(resource, plan, signal, http, maximumArchivedBytes = MAX_ARCHIVED_PAGE_BYTES) {
    throwIfAborted(signal);
    if (!Number.isSafeInteger(maximumArchivedBytes) || maximumArchivedBytes < 1 || maximumArchivedBytes > MAX_ARCHIVED_PAGE_BYTES) {
      throw new RunSafetyError("Invalid archived page byte limit");
    }
    if (resource.kind !== "page" || resource.archivePath === null) {
      throw new RunSafetyError("Invalid planned page");
    }
    try {
      const response = await http.jsonBoundedResource(
        canvasEndpoint({
          type: "coursePage",
          courseId: plan.course.id,
          pageUrl: resource.sourceId
        }),
        CANVAS_PAGE_JSON_MAX_BYTES
      );
      throwIfAborted(signal);
      const page = exactCanvasPage(response.value);
      const html2 = sanitizePageFragment({
        title: page.title,
        body: page.body,
        resolveLocalHref: (href) => resolveLocalHref(href, plan)
      });
      const bytes = strToU8(html2);
      if (bytes.byteLength > maximumArchivedBytes) {
        bytes.fill(0);
        return { status: "unavailable", failureCategory: "page-too-large" };
      }
      return { status: "success", bytes };
    } catch (error) {
      if (error instanceof CanvasBodySizeError || error instanceof Error && error.name === "CanvasBodySizeError") {
        return { status: "unavailable", failureCategory: "page-too-large" };
      }
      if (error instanceof CanvasResourceUnavailableError) {
        return {
          status: "unavailable",
          failureCategory: error.status === 403 ? "access-denied" : "not-found"
        };
      }
      if (error instanceof CanvasTransientError) {
        return { status: "failed", failureCategory: "transient-exhausted" };
      }
      throw error;
    }
  }

  // src/page/run-courses.ts
  var MultiCourseSafetyError = class extends RunSafetyError {
  };
  var abortError3 = (signal) => signal.reason instanceof DOMException && signal.reason.name === "AbortError" ? signal.reason : new DOMException("Packing was cancelled", "AbortError");
  var throwIfAborted2 = (signal) => {
    if (signal.aborted) throw abortError3(signal);
  };
  var isAbort = (error) => error instanceof CanvasSessionError || error instanceof DOMException && error.name === "AbortError";
  var emptyCounts = () => ({
    success: 0,
    failed: 0,
    unavailable: 0,
    unsupported: 0,
    external: 0
  });
  var addCounts = (target, source) => {
    target.success += source.success;
    target.failed += source.failed;
    target.unavailable += source.unavailable;
    target.unsupported += source.unsupported;
    target.external += source.external;
  };
  var progressForCourse = (progress, course, courseIndex, totalCourses, completedCourses, currentPartIndex, totalParts, totalArchiveParts, completedParts, failedParts) => (value) => progress({
    ...value,
    currentCourseId: course.id,
    currentCourseIndex: courseIndex,
    totalCourses,
    completedCourses,
    currentPartIndex,
    totalParts,
    totalArchiveParts,
    completedParts,
    failedParts
  });
  var planSummary = (courses, failures, requestedCourseCount, requestedPackaging, effectivePackaging, fallbackReason2) => {
    const selected = courses.map(
      ({
        plan: {
          course,
          moduleDiscovery: moduleDiscovery3,
          advertisedBytes: advertisedBytes2,
          resources,
          folderPathFallbackKeys
        },
        parts
      }) => ({
        courseId: course.id,
        moduleDiscovery: moduleDiscovery3,
        advertisedBytes: advertisedBytes2,
        unknownSizeCount: resources.filter(
          (resource) => resource.kind === "file" && resource.advertisedBytes === null
        ).length,
        resourceCount: resources.length,
        folderPathFallbackCount: folderPathFallbackKeys.length,
        archivePartCount: parts.length
      })
    );
    const advertisedBytes = selected.reduce(
      (total, item) => total + item.advertisedBytes,
      0
    );
    const resourceCount = selected.reduce(
      (total, item) => total + item.resourceCount,
      0
    );
    const unknownSizeCount = selected.reduce(
      (total, item) => total + item.unknownSizeCount,
      0
    );
    const totalPlannedParts = selected.reduce(
      (total, item) => total + item.archivePartCount,
      0
    );
    const expectedArchiveCount = effectivePackaging === "per-course" ? totalPlannedParts : selected.length > 0 ? 1 : 0;
    return {
      requestedCourseCount,
      selected,
      skipped: failures.map(({ course, category }) => ({
        courseId: course.id,
        category
      })),
      requestedPackaging,
      effectivePackaging,
      advertisedBytes,
      unknownSizeCount,
      resourceCount,
      totalPlannedParts,
      expectedArchiveCount,
      fallbackReason: fallbackReason2
    };
  };
  var classifyCoursePlanFailure = (error) => {
    if (error instanceof PilotSizeError) return "size-limit";
    if (error instanceof CanvasResponseError) return "canvas-unavailable";
    if (error instanceof RunSafetyError || error instanceof TypeError) {
      return "safety-validation";
    }
    return "unexpected-local";
  };
  async function createRunPlan(options) {
    const { courses, requestedPackaging, signal, dependencies, onProgress } = options;
    if (courses.length === 0)
      throw new MultiCourseSafetyError("No courses selected");
    const plannedCourses = [];
    const failures = [];
    for (let index = 0; index < courses.length; index += 1) {
      const course = courses[index];
      throwIfAborted2(signal);
      try {
        const discovered = await dependencies.discover({ ...course }, signal);
        if (discovered.course.id !== course.id) {
          throw new MultiCourseSafetyError(
            `Course ${course.id} discovery returned a different course`
          );
        }
        const plan = freezeCoursePlan(discovered);
        plannedCourses.push(
          Object.freeze({
            plan,
            parts: partitionCoursePlan(plan)
          })
        );
      } catch (error) {
        if (isAbort(error)) throw error;
        failures.push(
          Object.freeze({
            course: Object.freeze({ ...course }),
            category: classifyCoursePlanFailure(error)
          })
        );
      }
      onProgress?.({
        completed: index + 1,
        total: courses.length,
        currentCourseId: course.id
      });
    }
    const summaryBase = planSummary(
      plannedCourses,
      failures,
      courses.length,
      requestedPackaging,
      requestedPackaging,
      null
    );
    if (!Number.isSafeInteger(summaryBase.advertisedBytes) || !Number.isSafeInteger(summaryBase.unknownSizeCount) || !Number.isSafeInteger(summaryBase.resourceCount) || !Number.isSafeInteger(summaryBase.totalPlannedParts) || !Number.isSafeInteger(summaryBase.expectedArchiveCount)) {
      throw new MultiCourseSafetyError("Selected course totals overflow");
    }
    if (requestedPackaging === "combined" && plannedCourses.some(({ parts }) => parts.length > 1)) {
      const summary = planSummary(
        plannedCourses,
        failures,
        courses.length,
        requestedPackaging,
        "per-course",
        "multipart-course"
      );
      return Object.freeze({
        courses: Object.freeze(plannedCourses),
        failures: Object.freeze(failures),
        summary: Object.freeze(summary)
      });
    }
    if (requestedPackaging === "combined" && summaryBase.unknownSizeCount > 0) {
      const summary = planSummary(
        plannedCourses,
        failures,
        courses.length,
        requestedPackaging,
        "per-course",
        "unknown-size-files"
      );
      return Object.freeze({
        courses: Object.freeze(plannedCourses),
        failures: Object.freeze(failures),
        summary: Object.freeze(summary)
      });
    }
    const combinedEntryCount = COMBINED_CORE_ENTRY_COUNT + COURSE_CORE_ENTRY_COUNT * plannedCourses.length + summaryBase.resourceCount;
    if (requestedPackaging === "combined" && (summaryBase.resourceCount > MAX_ARCHIVE_RESOURCES || !Number.isSafeInteger(combinedEntryCount) || combinedEntryCount > CLASSIC_ZIP_ENTRY_LIMIT)) {
      const summary = planSummary(
        plannedCourses,
        failures,
        courses.length,
        requestedPackaging,
        "per-course",
        "combined-resource-limit-exceeded"
      );
      return Object.freeze({
        courses: Object.freeze(plannedCourses),
        failures: Object.freeze(failures),
        summary: Object.freeze(summary)
      });
    }
    if (requestedPackaging === "combined" && summaryBase.advertisedBytes > MAX_ARCHIVE_BYTES) {
      const summary = planSummary(
        plannedCourses,
        failures,
        courses.length,
        requestedPackaging,
        "per-course",
        "combined-size-exceeded"
      );
      return Object.freeze({
        courses: Object.freeze(plannedCourses),
        failures: Object.freeze(failures),
        summary: Object.freeze(summary)
      });
    }
    return Object.freeze({
      courses: Object.freeze(plannedCourses),
      failures: Object.freeze(failures),
      summary: Object.freeze(summaryBase)
    });
  }
  var clearBytes = (bytes) => {
    bytes.fill(0);
  };
  async function runCourses(options) {
    const { plan, signal, progress, dependencies } = options;
    const completed = [];
    const completedParts = [];
    const failedParts = [];
    const completedCourseIds = [];
    const failedCourseIds = [];
    const counts = emptyCounts();
    let combined = null;
    let outputCount = 0;
    const pendingCombined = [];
    const completedCourse = (coursePlan, result, fileName) => ({
      course: coursePlan.course,
      fileName,
      manifest: result.manifest,
      moduleCount: coursePlan.modules.length,
      itemCount: coursePlan.modules.reduce(
        (total, module) => total + module.items.length,
        0
      )
    });
    const handOffPendingCombined = () => {
      for (const archive of pendingCombined) {
        dependencies.download(archive.fileName, archive.zipBytes);
        outputCount += 1;
      }
    };
    try {
      for (let index = 0; index < plan.courses.length; index += 1) {
        throwIfAborted2(signal);
        const plannedCourse = plan.courses[index];
        const coursePlan = plannedCourse.plan;
        let courseComplete = true;
        let lastCompleted = null;
        for (const partPlan of plannedCourse.parts) {
          throwIfAborted2(signal);
          const courseProgress = progressForCourse(
            progress,
            coursePlan.course,
            index,
            plan.courses.length,
            completedCourseIds.length,
            partPlan.index,
            partPlan.total,
            plan.summary.totalPlannedParts,
            completedParts.length,
            failedParts.length
          );
          courseProgress({
            stage: "download",
            completed: 0,
            total: partPlan.resourceKeys.length,
            failed: 0
          });
          let partBytes = null;
          try {
            const result = await dependencies.buildCourseArchive({
              course: coursePlan.course,
              plan: coursePlan,
              partPlan,
              combinedRoot: null,
              signal,
              progress: courseProgress,
              dependencies
            });
            partBytes = result.zipBytes;
            const outputName = partFileName(
              dependencies.fileName(coursePlan.course),
              partPlan
            );
            addCounts(counts, result.manifest.totals);
            const descriptor = Object.freeze({
              courseId: coursePlan.course.id,
              partIndex: partPlan.index,
              totalParts: partPlan.total,
              fileName: outputName
            });
            if (plan.summary.effectivePackaging === "per-course") {
              dependencies.download(outputName, result.zipBytes);
              outputCount += 1;
            } else {
              pendingCombined.push({
                ...completedCourse(coursePlan, result, outputName),
                zipBytes: result.zipBytes
              });
            }
            completedParts.push(descriptor);
            lastCompleted = completedCourse(coursePlan, result, outputName);
          } catch (error) {
            if (isAbort(error)) throw error;
            courseComplete = false;
            failedParts.push(
              Object.freeze({
                courseId: coursePlan.course.id,
                partIndex: partPlan.index,
                totalParts: partPlan.total
              })
            );
          } finally {
            if (plan.summary.effectivePackaging === "per-course") {
              partBytes?.fill(0);
            }
          }
        }
        if (courseComplete && lastCompleted) {
          completedCourseIds.push(coursePlan.course.id);
          completed.push(lastCompleted);
        } else {
          failedCourseIds.push(coursePlan.course.id);
        }
      }
      throwIfAborted2(signal);
      if (plan.summary.effectivePackaging === "combined" && failedCourseIds.length === 0) {
        const result = dependencies.buildCombinedZip({
          archives: pendingCombined,
          archiveCss: dependencies.archiveCss,
          now: dependencies.now,
          fileName: dependencies.combinedFileName
        });
        const combinedBytes = result.zipBytes;
        const combinedFileName = dependencies.combinedFileName(
          plan.courses.map(({ plan: { course } }) => course)
        );
        combined = {
          fileName: combinedFileName,
          manifest: result.manifest
        };
        try {
          dependencies.download(combinedFileName, combinedBytes);
          outputCount = 1;
        } finally {
          combinedBytes.fill(0);
        }
      } else if (plan.summary.effectivePackaging === "combined") {
        handOffPendingCombined();
      }
    } catch (error) {
      if (plan.summary.effectivePackaging === "combined") {
        handOffPendingCombined();
      }
      throw error;
    } finally {
      for (const archive of pendingCombined) clearBytes(archive.zipBytes);
    }
    const effectivePackaging = plan.summary.effectivePackaging === "combined" && failedCourseIds.length > 0 ? "per-course" : plan.summary.effectivePackaging;
    return {
      effectivePackaging,
      combined,
      completed,
      completedParts: Object.freeze(completedParts),
      failedParts: Object.freeze(failedParts),
      completedCourseIds: Object.freeze(completedCourseIds),
      failedCourseIds,
      outputCount,
      counts
    };
  }

  // src/shared/messages.ts
  var RUNNER_TERMINAL_MESSAGES = Object.freeze({
    active: "Another GradPack operation is already active in this tab.",
    cancelled: "Packing was cancelled.",
    complete: "Your GradPack archives were downloaded.",
    noArchives: "No course archives were downloaded.",
    connection: "Open a signed-in Frankfurt School Canvas tab and try again.",
    navigation: "The Canvas tab navigated or closed. Reopen it and try again.",
    response: "Canvas returned an unavailable or invalid response.",
    safety: "GradPack stopped because a safety check failed.",
    session: "Your Canvas session ended. Sign in and try again.",
    size: "This course does not fit the 250 MB safety policy.",
    tab: "The connected Canvas tab is no longer available. Reopen it and try again.",
    unexpected: "GradPack stopped because of an unexpected local error.",
    unlisted: "The selected course is no longer available."
  });
  var record = (value) => {
    if (typeof value !== "object" || value === null || Array.isArray(value) || Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null) {
      throw new TypeError("Expected an object message");
    }
    for (const key of Reflect.ownKeys(value)) {
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (!descriptor || !("value" in descriptor)) {
        throw new TypeError("Unexpected message fields");
      }
    }
    return value;
  };
  var exactKeys = (value, allowed) => {
    const keys = Reflect.ownKeys(value);
    if (keys.length !== allowed.length || keys.some((key) => typeof key !== "string" || !allowed.includes(key))) {
      throw new TypeError("Unexpected message fields");
    }
  };
  var runId = (value) => {
    if (typeof value !== "string" || !/^run-[a-z0-9-]{8,64}$/.test(value)) {
      throw new TypeError("Invalid run identifier");
    }
    return value;
  };
  var nonNegativeInteger = (value) => {
    if (!Number.isSafeInteger(value) || Number(value) < 0) {
      throw new TypeError("Invalid count");
    }
    return Number(value);
  };
  var positiveInteger = (value, message) => {
    const result = nonNegativeInteger(value);
    if (result <= 0) throw new TypeError(message);
    return result;
  };
  var courseSummary = (value) => {
    const input = record(value);
    exactKeys(input, ["id", "name", "courseCode", "workflowState", "concluded"]);
    const id = positiveInteger(input.id, "Invalid course ID");
    if (typeof input.name !== "string" || typeof input.courseCode !== "string" || typeof input.workflowState !== "string" || typeof input.concluded !== "boolean") {
      throw new TypeError("Invalid course summary");
    }
    return {
      id,
      name: input.name.slice(0, 500),
      courseCode: input.courseCode.slice(0, 200),
      workflowState: input.workflowState.slice(0, 100),
      concluded: input.concluded
    };
  };
  var denseArray = (value, max2) => {
    if (!Array.isArray(value) || Object.getPrototypeOf(value) !== Array.prototype) {
      throw new TypeError("Invalid array");
    }
    const length = Object.getOwnPropertyDescriptor(value, "length")?.value;
    if (length === void 0 || !Number.isSafeInteger(length) || length < 0 || length > max2) {
      throw new TypeError("Invalid array");
    }
    const keys = Reflect.ownKeys(value);
    if (keys.some(
      (key) => typeof key !== "string" || key !== "length" && !/^(?:0|[1-9]\d*)$/u.test(key)
    )) {
      throw new TypeError("Invalid array");
    }
    const result = [];
    for (let index = 0; index < length; index += 1) {
      const descriptor = Object.getOwnPropertyDescriptor(value, String(index));
      if (!descriptor || !("value" in descriptor))
        throw new TypeError("Invalid array");
      result.push(descriptor.value);
    }
    return result;
  };
  var courseArray = (value) => denseArray(value, 1e4).map(courseSummary);
  var courseIds = (value) => {
    const values = denseArray(value, 1e4);
    if (values.length === 0)
      throw new TypeError("At least one course is required");
    const ids = values.map(
      (candidate) => positiveInteger(candidate, "Invalid course ID")
    );
    if (new Set(ids).size !== ids.length)
      throw new TypeError("Duplicate course ID");
    return ids;
  };
  var packaging = (value) => {
    if (value !== "combined" && value !== "per-course") {
      throw new TypeError("Invalid packaging mode");
    }
    return value;
  };
  var fallbackReason = (value) => {
    if (value !== null && value !== "combined-size-exceeded" && value !== "combined-resource-limit-exceeded" && value !== "unknown-size-files" && value !== "multipart-course") {
      throw new TypeError("Invalid fallback reason");
    }
    return value;
  };
  var moduleDiscovery2 = (value) => {
    if (value !== "available" && value !== "disabled") {
      throw new TypeError("Invalid module discovery state");
    }
    return value;
  };
  var planSummary2 = (value) => {
    const input = record(value);
    exactKeys(input, [
      "courseId",
      "moduleDiscovery",
      "advertisedBytes",
      "unknownSizeCount",
      "resourceCount",
      "folderPathFallbackCount",
      "archivePartCount"
    ]);
    return {
      courseId: positiveInteger(input.courseId, "Invalid course ID"),
      moduleDiscovery: moduleDiscovery2(input.moduleDiscovery),
      advertisedBytes: nonNegativeInteger(input.advertisedBytes),
      unknownSizeCount: nonNegativeInteger(input.unknownSizeCount),
      resourceCount: nonNegativeInteger(input.resourceCount),
      folderPathFallbackCount: nonNegativeInteger(input.folderPathFallbackCount),
      archivePartCount: positiveInteger(
        input.archivePartCount,
        "Invalid archive part count"
      )
    };
  };
  var coursePlanFailureCategory = (value) => {
    if (value !== "size-limit" && value !== "canvas-unavailable" && value !== "safety-validation" && value !== "unexpected-local") {
      throw new TypeError("Invalid course plan failure category");
    }
    return value;
  };
  var coursePlanFailure = (value) => {
    const input = record(value);
    exactKeys(input, ["courseId", "category"]);
    return {
      courseId: positiveInteger(input.courseId, "Invalid course ID"),
      category: coursePlanFailureCategory(input.category)
    };
  };
  var planEvent = (input, id) => {
    exactKeys(input, [
      "channel",
      "type",
      "runId",
      "requestedCourseCount",
      "selected",
      "skipped",
      "advertisedBytes",
      "unknownSizeCount",
      "resourceCount",
      "totalPlannedParts",
      "expectedArchiveCount",
      "requestedPackaging",
      "effectivePackaging",
      "fallbackReason"
    ]);
    const requestedCourseCount = positiveInteger(
      input.requestedCourseCount,
      "Invalid requested course count"
    );
    const selected = denseArray(input.selected, 1e4).map(planSummary2);
    const skipped = denseArray(input.skipped, 1e4).map(coursePlanFailure);
    const selectedIds = selected.map((item) => item.courseId);
    const skippedIds = skipped.map((item) => item.courseId);
    if (selected.length + skipped.length !== requestedCourseCount || selected.length + skipped.length === 0 || new Set(selectedIds).size !== selectedIds.length || new Set(skippedIds).size !== skippedIds.length || selectedIds.some((courseId) => skippedIds.includes(courseId))) {
      throw new TypeError("Invalid plan courses");
    }
    const advertisedBytes = nonNegativeInteger(input.advertisedBytes);
    const unknownSizeCount = nonNegativeInteger(input.unknownSizeCount);
    const resourceCount = nonNegativeInteger(input.resourceCount);
    const totalPlannedParts = nonNegativeInteger(input.totalPlannedParts);
    const expectedArchiveCount = nonNegativeInteger(input.expectedArchiveCount);
    if (unknownSizeCount > resourceCount || selected.some(
      (item) => item.resourceCount > MAX_ARCHIVE_RESOURCES || item.unknownSizeCount > item.resourceCount || item.folderPathFallbackCount > item.resourceCount
    )) {
      throw new TypeError("Invalid plan counts");
    }
    if (selected.reduce((total, item) => total + item.advertisedBytes, 0) !== advertisedBytes || selected.reduce((total, item) => total + item.unknownSizeCount, 0) !== unknownSizeCount || selected.reduce((total, item) => total + item.resourceCount, 0) !== resourceCount) {
      throw new TypeError("Invalid plan totals");
    }
    const selectedPartCount = selected.reduce(
      (total, item) => total + item.archivePartCount,
      0
    );
    if (!Number.isSafeInteger(selectedPartCount) || selectedPartCount !== totalPlannedParts) {
      throw new TypeError("Invalid plan part totals");
    }
    const requestedPackaging = packaging(input.requestedPackaging);
    const effectivePackaging = packaging(input.effectivePackaging);
    const reason = fallbackReason(input.fallbackReason);
    const hasMultipartCourse = selected.some(
      ({ archivePartCount }) => archivePartCount > 1
    );
    const requiredArchiveCount = effectivePackaging === "per-course" ? totalPlannedParts : selected.length > 0 ? 1 : 0;
    if (expectedArchiveCount !== requiredArchiveCount) {
      throw new TypeError("Invalid expected archive count");
    }
    const combinedEntryCount = COMBINED_CORE_ENTRY_COUNT + COURSE_CORE_ENTRY_COUNT * selected.length + resourceCount;
    if (effectivePackaging === "combined" && (resourceCount > MAX_ARCHIVE_RESOURCES || !Number.isSafeInteger(combinedEntryCount) || combinedEntryCount > CLASSIC_ZIP_ENTRY_LIMIT)) {
      throw new TypeError("Invalid plan");
    }
    if (requestedPackaging === effectivePackaging && reason !== null || requestedPackaging !== effectivePackaging && reason === null || effectivePackaging === "combined" && reason !== null || reason === "multipart-course" && (requestedPackaging !== "combined" || effectivePackaging !== "per-course" || !hasMultipartCourse) || requestedPackaging === "combined" && hasMultipartCourse && reason !== "multipart-course" || reason === "unknown-size-files" && unknownSizeCount === 0 || requestedPackaging === "combined" && unknownSizeCount > 0 && !hasMultipartCourse && reason !== "unknown-size-files") {
      throw new TypeError("Invalid packaging fallback");
    }
    return {
      channel: RUNNER_CHANNEL,
      type: "PLAN_READY",
      runId: id,
      requestedCourseCount,
      selected,
      skipped,
      advertisedBytes,
      unknownSizeCount,
      resourceCount,
      totalPlannedParts,
      expectedArchiveCount,
      requestedPackaging,
      effectivePackaging,
      fallbackReason: reason
    };
  };
  var discoveryProgress = (input, id) => {
    exactKeys(input, [
      "channel",
      "type",
      "runId",
      "completed",
      "total",
      "currentCourseId"
    ]);
    const completed = nonNegativeInteger(input.completed);
    const total = positiveInteger(input.total, "Invalid course count");
    if (completed > total) throw new TypeError("Invalid discovery progress");
    return {
      channel: RUNNER_CHANNEL,
      type: "DISCOVERY_PROGRESS",
      runId: id,
      completed,
      total,
      currentCourseId: positiveInteger(
        input.currentCourseId,
        "Invalid course ID"
      )
    };
  };
  var aggregateProgress = (input, id) => {
    exactKeys(input, [
      "channel",
      "type",
      "runId",
      "stage",
      "currentCourseId",
      "currentCourseIndex",
      "totalCourses",
      "completedCourses",
      "currentPartIndex",
      "totalParts",
      "totalArchiveParts",
      "completedParts",
      "failedParts",
      "completed",
      "total",
      "failed"
    ]);
    const stage = input.stage;
    if (typeof stage !== "string" || !["discovery", "download", "sanitize", "package"].includes(stage)) {
      throw new TypeError("Unsupported runner event");
    }
    const currentCourseId = positiveInteger(
      input.currentCourseId,
      "Invalid course ID"
    );
    const currentCourseIndex = nonNegativeInteger(input.currentCourseIndex);
    const totalCourses = positiveInteger(
      input.totalCourses,
      "Invalid course count"
    );
    const completedCourses = nonNegativeInteger(input.completedCourses);
    const currentPartIndex = positiveInteger(
      input.currentPartIndex,
      "Invalid current part index"
    );
    const totalParts = positiveInteger(input.totalParts, "Invalid part count");
    const totalArchiveParts = positiveInteger(
      input.totalArchiveParts,
      "Invalid total archive part count"
    );
    const completedParts = nonNegativeInteger(input.completedParts);
    const failedParts = nonNegativeInteger(input.failedParts);
    const completed = nonNegativeInteger(input.completed);
    const total = nonNegativeInteger(input.total);
    const failed = nonNegativeInteger(input.failed);
    if (currentCourseIndex >= totalCourses || completedCourses > currentCourseIndex || currentPartIndex > totalParts || completedParts + failedParts > totalArchiveParts || !Number.isSafeInteger(completedParts + failedParts) || total > MAX_ARCHIVE_RESOURCES || completed > total || failed > completed) {
      throw new TypeError("Invalid progress counts");
    }
    const value = {
      stage,
      currentCourseId,
      currentCourseIndex,
      totalCourses,
      completedCourses,
      currentPartIndex,
      totalParts,
      totalArchiveParts,
      completedParts,
      failedParts,
      completed,
      total,
      failed
    };
    return { channel: RUNNER_CHANNEL, type: "PROGRESS", runId: id, ...value };
  };
  var terminalMessage = (value, allowed) => {
    if (typeof value !== "string" || !allowed.includes(value)) {
      throw new TypeError("Unsupported runner event");
    }
    return value;
  };
  function parseExtensionCommand(value) {
    const input = record(value);
    if (input.channel !== EXTENSION_CHANNEL)
      throw new TypeError("Invalid channel");
    const id = runId(input.runId);
    if (input.type === "LIST_COURSES" || input.type === "CANCEL" || input.type === "CONFIRM_PLAN") {
      exactKeys(input, ["channel", "type", "runId"]);
      return { channel: EXTENSION_CHANNEL, type: input.type, runId: id };
    }
    if (input.type === "START_RUN") {
      exactKeys(input, ["channel", "type", "runId", "courseIds", "packaging"]);
      return {
        channel: EXTENSION_CHANNEL,
        type: "START_RUN",
        runId: id,
        courseIds: courseIds(input.courseIds),
        packaging: packaging(input.packaging)
      };
    }
    throw new TypeError("Unsupported command");
  }
  function parseRunnerEvent(value) {
    const input = record(value);
    if (input.channel !== RUNNER_CHANNEL) throw new TypeError("Invalid channel");
    const id = runId(input.runId);
    if (input.type === "COURSES" && Array.isArray(input.courses)) {
      exactKeys(input, ["channel", "type", "runId", "courses"]);
      return {
        channel: RUNNER_CHANNEL,
        type: "COURSES",
        runId: id,
        courses: courseArray(input.courses)
      };
    }
    if (input.type === "PLAN_READY") return planEvent(input, id);
    if (input.type === "DISCOVERY_PROGRESS") {
      return discoveryProgress(input, id);
    }
    if (input.type === "PROGRESS") return aggregateProgress(input, id);
    if (input.type === "COMPLETE") {
      exactKeys(input, [
        "channel",
        "type",
        "runId",
        "message",
        "packaging",
        "completedCourses",
        "completedCourseIds",
        "failedCourses",
        "outputCount",
        "completedParts",
        "failedParts",
        "success",
        "failed",
        "unavailable",
        "unsupported",
        "external"
      ]);
      const message = terminalMessage(input.message, [
        RUNNER_TERMINAL_MESSAGES.complete,
        RUNNER_TERMINAL_MESSAGES.noArchives
      ]);
      const packagingMode = packaging(input.packaging);
      const completedCourses = nonNegativeInteger(input.completedCourses);
      const completedCourseIds = denseArray(input.completedCourseIds, 1e4).map(
        (value2) => positiveInteger(value2, "Invalid completed course ID")
      );
      const failedCourses = nonNegativeInteger(input.failedCourses);
      const outputCount = nonNegativeInteger(input.outputCount);
      const completedParts = nonNegativeInteger(input.completedParts);
      const failedParts = nonNegativeInteger(input.failedParts);
      const zeroOutput = completedCourses === 0;
      const validZeroOutput = zeroOutput && message === RUNNER_TERMINAL_MESSAGES.noArchives && packagingMode === "per-course" && completedCourseIds.length === 0 && failedCourses > 0 && outputCount === 0 && completedParts === 0 && failedParts > 0;
      if (zeroOutput && !validZeroOutput || !zeroOutput && (message !== RUNNER_TERMINAL_MESSAGES.complete || completedCourseIds.length !== completedCourses || new Set(completedCourseIds).size !== completedCourseIds.length || completedParts < completedCourses || failedParts < failedCourses || outputCount === 0 || packagingMode === "combined" && outputCount !== 1 || packagingMode === "per-course" && outputCount !== completedParts)) {
        throw new TypeError("Invalid terminal course counts");
      }
      const counts = {
        success: nonNegativeInteger(input.success),
        failed: nonNegativeInteger(input.failed),
        unavailable: nonNegativeInteger(input.unavailable),
        unsupported: nonNegativeInteger(input.unsupported),
        external: nonNegativeInteger(input.external)
      };
      const total = Object.values(counts).reduce((sum, count) => sum + count, 0);
      const maximumTotal = completedParts * MAX_ARCHIVE_RESOURCES;
      if (!Number.isSafeInteger(maximumTotal) || !Number.isSafeInteger(total) || total > maximumTotal) {
        throw new TypeError("Invalid terminal counts");
      }
      if (validZeroOutput && total !== 0) {
        throw new TypeError("Invalid terminal counts");
      }
      return {
        channel: RUNNER_CHANNEL,
        type: "COMPLETE",
        runId: id,
        message,
        packaging: packagingMode,
        completedCourses,
        completedCourseIds,
        failedCourses,
        outputCount,
        completedParts,
        failedParts,
        ...counts
      };
    }
    if (input.type === "CANCELLED" || input.type === "FAILED") {
      exactKeys(input, ["channel", "type", "runId", "message"]);
      const message = terminalMessage(
        input.message,
        input.type === "CANCELLED" ? [
          RUNNER_TERMINAL_MESSAGES.cancelled,
          RUNNER_TERMINAL_MESSAGES.navigation
        ] : [
          RUNNER_TERMINAL_MESSAGES.active,
          RUNNER_TERMINAL_MESSAGES.response,
          RUNNER_TERMINAL_MESSAGES.safety,
          RUNNER_TERMINAL_MESSAGES.session,
          RUNNER_TERMINAL_MESSAGES.size,
          RUNNER_TERMINAL_MESSAGES.unexpected,
          RUNNER_TERMINAL_MESSAGES.unlisted
        ]
      );
      return { channel: RUNNER_CHANNEL, type: input.type, runId: id, message };
    }
    throw new TypeError("Unsupported runner event");
  }

  // src/page/runner.ts
  var marker = "__gradPackRunnerV1";
  var scope = window;
  var FIXED = RUNNER_TERMINAL_MESSAGES;
  function post(event) {
    window.postMessage(
      { source: "gradpack-runner", payload: parseRunnerEvent(event) },
      location.origin
    );
  }
  var fixedFailure = (error) => {
    if (error instanceof CanvasSessionError) return FIXED.session;
    if (error instanceof PilotSizeError) return FIXED.size;
    if (error instanceof RunSafetyError || error instanceof ArchiveSafetyError || error instanceof TypeError)
      return FIXED.safety;
    if (error instanceof CanvasResponseError) return FIXED.response;
    return FIXED.unexpected;
  };
  var productionDependencies = (signal) => {
    return {
      discover: async (course) => {
        const controller = new AbortController();
        const onAbort = () => controller.abort(signal.reason);
        signal.addEventListener("abort", onAbort, { once: true });
        if (signal.aborted) onAbort();
        const http = new CanvasHttp(fetch, controller.signal);
        try {
          await assertCurrentUser(http);
          return await discoverCoursePlan(http, course, {
            abort: (reason) => controller.abort(reason)
          });
        } finally {
          signal.removeEventListener("abort", onAbort);
        }
      },
      retrieve: async (resource, plan, activeSignal, remainingBytes) => {
        if (resource.kind === "file")
          return fetchFileResource(resource, activeSignal, {}, remainingBytes);
        if (resource.kind === "page")
          return fetchPageResource(
            resource,
            plan,
            activeSignal,
            new CanvasHttp(fetch, activeSignal)
          );
        throw new RunSafetyError("Unexpected retrieval kind");
      },
      archiveCss: ARCHIVE_CSS,
      now: () => (/* @__PURE__ */ new Date()).toISOString(),
      fileName: (course) => safeArchivePath(`gradpack-${course.name}.zip`),
      combinedFileName: () => safeArchivePath("gradpack-combined.zip"),
      buildCourseArchive,
      buildCombinedZip,
      download: downloadCourseZip
    };
  };
  if (scope[marker] !== true) {
    scope[marker] = true;
    let listed = null;
    let listing = null;
    let planning = null;
    let pendingPlan = null;
    let active = null;
    const terminalizedIds = /* @__PURE__ */ new Set();
    const markTerminal = (runId2) => {
      if (terminalizedIds.has(runId2)) return false;
      terminalizedIds.add(runId2);
      return true;
    };
    const postFailure = (runId2, message) => {
      if (!markTerminal(runId2)) return;
      post({ channel: RUNNER_CHANNEL, type: "FAILED", runId: runId2, message });
    };
    const abortOwned = (owned, cause) => {
      if (owned.terminal || owned.cause !== null) return;
      owned.cause = cause;
      owned.controller.abort(
        new DOMException(
          cause === "navigation" ? "Canvas navigation" : "Packing was cancelled",
          "AbortError"
        )
      );
    };
    const runSelectedCourses = async (runId2, plan, owned) => {
      active = owned;
      try {
        const result = await runCourses({
          plan,
          signal: owned.controller.signal,
          dependencies: productionDependencies(owned.controller.signal),
          progress: (value) => {
            if (active === owned && !owned.terminal && !owned.controller.signal.aborted) {
              post({
                channel: RUNNER_CHANNEL,
                type: "PROGRESS",
                runId: runId2,
                ...value
              });
            }
          }
        });
        if (active !== owned || owned.terminal || owned.controller.signal.aborted)
          return;
        owned.terminal = true;
        if (!markTerminal(runId2)) return;
        post({
          channel: RUNNER_CHANNEL,
          type: "COMPLETE",
          runId: runId2,
          message: result.outputCount === 0 ? FIXED.noArchives : FIXED.complete,
          packaging: result.effectivePackaging,
          completedCourses: result.completedCourseIds.length,
          completedCourseIds: [...result.completedCourseIds],
          failedCourses: result.failedCourseIds.length,
          outputCount: result.outputCount,
          completedParts: result.completedParts.length,
          failedParts: result.failedParts.length,
          ...result.counts
        });
      } catch (error) {
        if (owned.terminal) return;
        owned.terminal = true;
        if (!markTerminal(runId2)) return;
        if (error instanceof DOMException && error.name === "AbortError" && owned.cause !== null) {
          post({
            channel: RUNNER_CHANNEL,
            type: "CANCELLED",
            runId: runId2,
            message: owned.cause === "navigation" ? FIXED.navigation : FIXED.cancelled
          });
        } else {
          post({
            channel: RUNNER_CHANNEL,
            type: "FAILED",
            runId: runId2,
            message: fixedFailure(error)
          });
        }
      } finally {
        if (active === owned) active = null;
      }
    };
    const handleCommand = async (command) => {
      if (terminalizedIds.has(command.runId)) return;
      if (command.type === "CANCEL") {
        if (active?.runId === command.runId) abortOwned(active, "cancelled");
        else if (listing?.runId === command.runId)
          abortOwned(listing, "cancelled");
        else if (planning?.runId === command.runId)
          abortOwned(planning, "cancelled");
        else if (pendingPlan?.owned.runId === command.runId) {
          pendingPlan.owned.terminal = true;
          pendingPlan = null;
          if (markTerminal(command.runId)) {
            post({
              channel: RUNNER_CHANNEL,
              type: "CANCELLED",
              runId: command.runId,
              message: FIXED.cancelled
            });
          }
        }
        return;
      }
      if (command.type === "LIST_COURSES") {
        if (listing?.runId === command.runId || planning?.runId === command.runId || pendingPlan?.owned.runId === command.runId || active?.runId === command.runId || listed?.runId === command.runId) {
          return;
        }
        if (listing || planning || pendingPlan || active) {
          postFailure(command.runId, FIXED.active);
          return;
        }
        if (listed) {
          markTerminal(listed.runId);
          listed = null;
        }
        const controller = new AbortController();
        const owned = {
          runId: command.runId,
          controller,
          terminal: false,
          cause: null
        };
        listing = owned;
        try {
          const http = new CanvasHttp(fetch, controller.signal);
          await assertCurrentUser(http);
          const discovered = await listAccessibleCourses(http, {
            abort: (reason) => controller.abort(reason)
          });
          if (listing !== owned || owned.terminal || controller.signal.aborted)
            return;
          const courses = discovered.map(
            (course) => Object.freeze({ ...course })
          );
          listed = { runId: command.runId, courses };
          post({
            channel: RUNNER_CHANNEL,
            type: "COURSES",
            runId: command.runId,
            courses
          });
        } catch (error) {
          if (owned.terminal) return;
          owned.terminal = true;
          if (!markTerminal(command.runId)) return;
          if (error instanceof DOMException && error.name === "AbortError" && owned.cause !== null) {
            post({
              channel: RUNNER_CHANNEL,
              type: "CANCELLED",
              runId: command.runId,
              message: owned.cause === "navigation" ? FIXED.navigation : FIXED.cancelled
            });
          } else {
            post({
              channel: RUNNER_CHANNEL,
              type: "FAILED",
              runId: command.runId,
              message: fixedFailure(error)
            });
          }
        } finally {
          if (listing === owned) listing = null;
        }
        return;
      }
      if (listing?.runId === command.runId || planning?.runId === command.runId || active?.runId === command.runId) {
        return;
      }
      if (listing || planning || active) {
        postFailure(command.runId, FIXED.active);
        return;
      }
      if (command.type === "START_RUN") {
        if (pendingPlan) {
          postFailure(command.runId, FIXED.active);
          return;
        }
        if (command.runId !== listed?.runId) {
          postFailure(command.runId, FIXED.unlisted);
          return;
        }
        const listedCourses = listed.courses;
        const selected = command.courseIds.map(
          (id) => listedCourses.find((course) => course.id === id)
        );
        if (selected.some((course) => course === void 0)) {
          listed = null;
          postFailure(command.runId, FIXED.unlisted);
          return;
        }
        const selectedCourses = selected.filter(
          (course) => course !== void 0
        );
        listed = null;
        const controller = new AbortController();
        const owned = {
          runId: command.runId,
          controller,
          terminal: false,
          cause: null
        };
        planning = owned;
        try {
          const plan = await createRunPlan({
            courses: selectedCourses,
            requestedPackaging: command.packaging,
            signal: controller.signal,
            dependencies: productionDependencies(controller.signal),
            onProgress: (value) => {
              if (planning === owned && !owned.terminal && !controller.signal.aborted) {
                post({
                  channel: RUNNER_CHANNEL,
                  type: "DISCOVERY_PROGRESS",
                  runId: command.runId,
                  ...value
                });
              }
            }
          });
          if (planning !== owned || owned.terminal || controller.signal.aborted)
            return;
          pendingPlan = { owned, plan };
          post({
            channel: RUNNER_CHANNEL,
            type: "PLAN_READY",
            runId: command.runId,
            ...plan.summary
          });
        } catch (error) {
          if (owned.terminal) return;
          owned.terminal = true;
          if (!markTerminal(command.runId)) return;
          if (error instanceof DOMException && error.name === "AbortError" && owned.cause !== null) {
            post({
              channel: RUNNER_CHANNEL,
              type: "CANCELLED",
              runId: command.runId,
              message: owned.cause === "navigation" ? FIXED.navigation : FIXED.cancelled
            });
          } else {
            post({
              channel: RUNNER_CHANNEL,
              type: "FAILED",
              runId: command.runId,
              message: fixedFailure(error)
            });
          }
        } finally {
          if (planning === owned) planning = null;
        }
        return;
      }
      if (pendingPlan?.owned.runId !== command.runId) {
        postFailure(command.runId, FIXED.unlisted);
        return;
      }
      const pending = pendingPlan;
      pendingPlan = null;
      if (pending.plan.courses.length === 0) {
        pending.owned.terminal = true;
        postFailure(command.runId, FIXED.safety);
        return;
      }
      await runSelectedCourses(command.runId, pending.plan, pending.owned);
    };
    const stopForNavigation = () => {
      if (listing) abortOwned(listing, "navigation");
      if (planning) abortOwned(planning, "navigation");
      if (active) abortOwned(active, "navigation");
      if (pendingPlan) {
        pendingPlan.owned.terminal = true;
        pendingPlan = null;
      }
      if (listed) {
        markTerminal(listed.runId);
        listed = null;
      }
    };
    window.addEventListener("pagehide", stopForNavigation);
    window.addEventListener("beforeunload", stopForNavigation);
    window.addEventListener("message", (event) => {
      if (event.source !== window || event.origin !== location.origin) return;
      if (typeof event.data !== "object" || event.data === null) return;
      const envelope = event.data;
      if (envelope.source !== "gradpack-relay") return;
      try {
        void handleCommand(parseExtensionCommand(envelope.payload));
      } catch {
      }
    });
  }
})();
/*! Bundled license information:

dompurify/dist/purify.es.mjs:
  (*! @license DOMPurify 3.4.13 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.4.13/LICENSE *)
*/
